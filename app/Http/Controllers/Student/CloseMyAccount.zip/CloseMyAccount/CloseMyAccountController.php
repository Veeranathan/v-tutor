<?php

namespace App\Http\Controllers\Student\CloseMyAccount;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Auth;

class CloseMyAccountController extends Controller
{
    //
    public function studentCloseMyAccount(Request $request){
        // if(@$request->all()){
            if(@Auth::user()->platform_type != NULL){
                User::where(['id'=>@Auth::user()->id])->update(['status'=>'C']);
                session()->flash("success","You have successfully close your account!");
                Auth::logout();
                return redirect()->route('login');
            }else{
                
                $request->validate([
                    'mypassword'        => 'required'
                ]);
                $password = @$request->mypassword;
                if (\Hash::check($password,@Auth()->user()->password)) {
                    User::where(['id'=>@Auth::user()->id])->update(['status'=>'C']);
                    session()->flash("success","You have successfully close your account!");
                    Auth::logout();
                    return redirect()->route('login');
                }else{
                    session()->flash("error","Wrong Password !");
                    return redirect()->back();
                }    
            }
            
        // }
        
    }
}
