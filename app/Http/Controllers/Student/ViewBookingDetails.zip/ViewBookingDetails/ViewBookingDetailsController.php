<?php

namespace App\Http\Controllers\Student\ViewBookingDetails;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Models\Subject;
use App\Models\StudentClassBooking;
use App\Models\MyAvailability;
use App\Models\TutorshipPlan;
use App\Models\UserToFavourite;
use App\Models\Tutor_calander_availability;
use App\Models\Payments;
use App\Models\Grade;

use App\User;
use Validator;
use Mail;
use App\Mail\StudentClassBookingMail;
use App\Mail\CancelBookingMail;
use Illuminate\Support\Carbon;
#stripe
use Stripe\Stripe;
use App\Models\AdminDisableBookingDates;
use App\Models\AdminDisableBookings;

class ViewBookingDetailsController extends Controller
{
        public function sendCancelBookingMail($bookingNo){
            try{
                $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['booking_no'=>$bookingNo])->first();
                Mail::send(new CancelBookingMail($data));
            }catch(\Exception $e){
                \Log::error($e->getMessage());
            }
        }
        public function cancelBookedClass($bookingNo){
            try{
                $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['booking_no'=>$bookingNo])->first();

                if(@$data['bookingDataInformation']){
                    if(@$data['bookingDataInformation']->booking_date == date('Y-m-d') && @$data['  bookingDataInformation']->from_time <= date('H:i:s')){
                        session()->flash("","You cannot cancel past booking!");
                        return redirect()->back();
                    }
                    if(@$data['bookingDataInformation']->booking_date == date('Y-m-d') && @$data['bookingDataInformation']->from_time > date('H:i:s')){

                            
                            $payment = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();

                            if(@$payment){
                                $HourFullRefund = (Carbon::parse($data['bookingDataInformation']->booking_date." ".$data['bookingDataInformation']->from_time))->subhours(24);

                                $HourHalfRefund = (Carbon::parse($data['bookingDataInformation']->booking_date." ".$data['bookingDataInformation']->from_time))->subhours(12);                
                                if($HourFullRefund >= date('Y-m-d H:i:s')){
                                    // dd("if greater than 24 hour HourFullRefund : ".$HourFullRefund.' current time'.date('Y-m-d H:i:s'));
                                    //100% refund    
                                    $stripe = \Stripe\Stripe::setApiKey('sk_test_51Jv1AlJ4WRuyPsk5Mn1hxt2P8PdyrlJJHnBtz9D4ngus7Oz5l8Xpeoznk70kKfcWYoTaQtoCQjOaIkzAaucQtmtr00TmroofCD');
                                    $t = \Stripe\Refund::create([
                                      'charge' => $payment->txn_id,
                                      ['metadata' => ['order_id' => $payment->booking_id]]
                                    ]);
                                    Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->update(['refund_response'=>json_encode(@$t),'refund_id'=>@$t['id'],'refund_amount'=>$payment->amount,'refund_status'=>'S']);

                                    
                                    StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>0,'admin_commission'=>0]);

                                    $paymetDtls = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                                    session()->flash("success","Booking  cancelled. You may book again!");
                                    // session()->flash("success","Booking cancelled. You may book again!Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled! $".@$paymetDtls->refund_amount." has been refunded!"); 
                                    // session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled! $".@$paymetDtls->refund_amount." has been refunded!"); 
                                }
                                else if($HourHalfRefund >= date('Y-m-d H:i:s')){
                                    // dd("if greater than 12 hour $HourFullRefund : ".$HourFullRefund.' current time'.date('Y-m-d H:i:s'));
                                    $refundAmount = ($payment->amount*(50/100));
                                    $stripeAmount = (($payment->amount*(50/100))*100);
                                    //50% refund 
                                    $stripe = \Stripe\Stripe::setApiKey('sk_test_51Jv1AlJ4WRuyPsk5Mn1hxt2P8PdyrlJJHnBtz9D4ngus7Oz5l8Xpeoznk70kKfcWYoTaQtoCQjOaIkzAaucQtmtr00TmroofCD');
                                    $t = \Stripe\Refund::create([
                                      'charge' => $payment->txn_id,
                                      'amount'=>$stripeAmount,
                                      ['metadata' => ['order_id' => $payment->booking_id]]
                                    ]);  
                                    Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->update(['refund_response'=>json_encode(@$t),'refund_id'=>@$t['id'],'refund_amount'=>$refundAmount,'refund_status'=>'S']);

                                    $rest_of_amount = ($data['bookingDataInformation']->booking_amount - $refundAmount);
                                    $admin_ord_commission = ( $rest_of_amount * ($data['bookingDataInformation']->admin_percentage/100));
                                    $tutor_earnings  = $rest_of_amount - $admin_ord_commission;
                                    StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>$tutor_earnings,'admin_commission'=>$admin_ord_commission]);
                                    $getUser = User::where(['id'=>$data['bookingDataInformation']->tutor_id])->first();
                                    $updC['total_earning'] = $getUser->total_earning + $tutor_earnings;
                                    $updC['total_due'] = $getUser->total_due+$tutor_earnings;
                                    $updC['total_commission'] = $getUser->total_commission+$admin_ord_commission;
                                    User::where(['id'=>$data['bookingDataInformation']->tutor_id])->update($updC);

                                    $paymetDtls = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                                    session()->flash("success","Booking  cancelled. You may book again!");
                                    // session()->flash("success","Booking cancelled. You may book again!Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!".(@$paymetDtls->refund_amount)." has been refunded!"); 
                                }else{
                                    // no refund
                                    // session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!There is no refund for this booking no!");

                                    
                                    $tutor_earnings = $data['bookingDataInformation']->tutor_earnings;
                                    $admin_ord_commission = $data['bookingDataInformation']->admin_commission;
                                    
                                    StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>$tutor_earnings,'admin_commission'=>$admin_ord_commission]);
                                    $getUser = User::where(['id'=>$data['bookingDataInformation']->tutor_id])->first();
                                    $updC['total_earning'] = $getUser->total_earning + $tutor_earnings;
                                    $updC['total_due'] = $getUser->total_due+$tutor_earnings;
                                    $updC['total_commission'] = $getUser->total_commission+$admin_ord_commission;
                                    User::where(['id'=>$data['bookingDataInformation']->tutor_id])->update($updC);

                                    session()->flash("success","Booking  cancelled. You may book again!");
                                }
                            
                            }else{
                                session()->flash("success","Booking  cancelled. You may book again!");
                                // session()->flash("success","Booking cancelled. You may book again!Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!There is no refund for this booking no!");
                            }
                            StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['booking_no'=>$bookingNo])->update(['booking_status'=>'C','cancelled_by'=>'S','cancelled_on'=>now()]);
                            Tutor_calander_availability::where(['tutor_id'=>$data['bookingDataInformation']->tutor_id,'date'=>$data['bookingDataInformation']->booking_date])->where('start_time','>=',$data['bookingDataInformation']->from_time)->where('end_time','<=',$data['bookingDataInformation']->to_time)->update(['booking_status'=>'NB']);
                            try{
                                $this->sendCancelBookingMail($data['bookingDataInformation']->booking_no);
                            }catch(\Exception $e){
                                \Log::error($e->getMessage());
                            }
                            return redirect()->back();
                    }
                    else if(@$data['bookingDataInformation']->booking_date > date('Y-m-d') ){
                        $payment = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                        if(@$payment){
                            $HourFullRefund = (Carbon::parse($data['bookingDataInformation']->booking_date." ".$data['bookingDataInformation']->from_time))->subhours(24);

                            $HourHalfRefund = (Carbon::parse($data['bookingDataInformation']->booking_date." ".$data['bookingDataInformation']->from_time))->subhours(12);                
                            if($HourFullRefund >= date('Y-m-d H:i:s')){
                                // dd("if greater than equal 24 hour HourFullRefund : ".$HourFullRefund.' current time'.date('Y-m-d H:i:s'));
                                //100% refund    
                                $stripe = \Stripe\Stripe::setApiKey('sk_test_51Jv1AlJ4WRuyPsk5Mn1hxt2P8PdyrlJJHnBtz9D4ngus7Oz5l8Xpeoznk70kKfcWYoTaQtoCQjOaIkzAaucQtmtr00TmroofCD');
                                $t = \Stripe\Refund::create([
                                  'charge' => $payment->txn_id,
                                  ['metadata' => ['order_id' => $payment->booking_id]]
                                ]);
                                Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->update(['refund_response'=>json_encode(@$t),'refund_id'=>@$t['id'],'refund_amount'=>$payment->amount,'refund_status'=>'S']);

                                
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>0,'admin_commission'=>0]);

                                $paymetDtls = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                                session()->flash("success","Booking  cancelled. You may book again!");
                                // session()->flash("success","Booking cancelled. You may book again!Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled! $".@$paymetDtls->refund_amount." has been refunded!"); 
                            }
                            else if($HourHalfRefund >= date('Y-m-d H:i:s')){
                                // dd("if greater than equal 12 hour $HourFullRefund : ".$HourFullRefund.' current time'.date('Y-m-d H:i:s'));
                                $refundAmount = ($payment->amount*(50/100));
                                $stripeAmount = (($payment->amount*(50/100))*100);
                                //50% refund 
                                $stripe = \Stripe\Stripe::setApiKey('sk_test_51Jv1AlJ4WRuyPsk5Mn1hxt2P8PdyrlJJHnBtz9D4ngus7Oz5l8Xpeoznk70kKfcWYoTaQtoCQjOaIkzAaucQtmtr00TmroofCD');
                                $t = \Stripe\Refund::create([
                                  'charge' => $payment->txn_id,
                                  'amount'=>$stripeAmount,
                                  ['metadata' => ['order_id' => $payment->booking_id]]
                                ]);  
                                Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->update(['refund_response'=>json_encode(@$t),'refund_id'=>@$t['id'],'refund_amount'=>$refundAmount,'refund_status'=>'S']);

                                $rest_of_amount = ($data['bookingDataInformation']->booking_amount - $refundAmount);
                                $admin_ord_commission = ( $rest_of_amount * ($data['bookingDataInformation']->admin_percentage/100));
                                $tutor_earnings  = $rest_of_amount - $admin_ord_commission;
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>$tutor_earnings,'admin_commission'=>$admin_ord_commission]);



                                $paymetDtls = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                                session()->flash("success","Booking  cancelled. You may book again!");
                                // session()->flash("success","Booking cancelled. You may book again!Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!".(@$paymetDtls->refund_amount)." has been refunded!"); 
                            }else{
                                // session()->flash("success","Booking cancelled. You may book again!Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!There is no refund for this booking no!");

                                $tutor_earnings = $data['bookingDataInformation']->tutor_earnings;
                                $admin_ord_commission = $data['bookingDataInformation']->admin_commission;
                                
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>$tutor_earnings,'admin_commission'=>$admin_ord_commission]);
                                $getUser = User::where(['id'=>$data['bookingDataInformation']->tutor_id])->first();
                                $updC['total_earning'] = $getUser->total_earning + $tutor_earnings;
                                $updC['total_due'] = $getUser->total_due+$tutor_earnings;
                                $updC['total_commission'] = $getUser->total_commission+$admin_ord_commission;
                                User::where(['id'=>$data['bookingDataInformation']->tutor_id])->update($updC);
                                session()->flash("success","Booking  cancelled. You may book again!");
                            }
                        
                        }else{
                            // session()->flash("success","Booking cancelled. You may book again!Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!There is no refund for this booking no!");
                            session()->flash("success","Booking  cancelled. You may book again!");
                        }
                        StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['booking_no'=>$bookingNo])->update(['booking_status'=>'C','cancelled_by'=>'S','cancelled_on'=>now()]);
                        Tutor_calander_availability::where(['tutor_id'=>$data['bookingDataInformation']->tutor_id,'date'=>$data['bookingDataInformation']->booking_date])->where('start_time','>=',$data['bookingDataInformation']->from_time)->where('end_time','<=',$data['bookingDataInformation']->to_time)->update(['booking_status'=>'NB']);
                        session()->flash("success","Booking  cancelled. You may book again!");
                                
                        try{
                            $this->sendCancelBookingMail($data['bookingDataInformation']->booking_no);
                        }catch(\Exception $e){
                            \Log::error($e->getMessage());
                        }
                        return redirect()->back();
                    }else{
                        session()->flash("error","You cannot cancel your past bookings!");
                        return redirect()->back();
                    }
                }else{
                    session()->flash("error","You are trying to see the booking details which is not associated with your account!");
                    return redirect()->back();
                }
            }
            catch(\Exception $e){
                session()->flash("error",$e->getMessage());
                return redirect()->back();
            }
        }
        public function viewDetails($bookingNo){
            $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade','getTutor.getTutorShipPlan'])->where(['booking_no'=>$bookingNo])->first();
            $data['admin_disable_bookings_values'] = AdminDisableBookings::first();
            $data['all_disabled_booking_dates'] = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();
            if(@$data['bookingDataInformation']){
                if(@Auth::user()->id == $data['bookingDataInformation']->student_id){
                    if(@$data['bookingDataInformation']){
                        $data['t_my_av_show'] = MyAvailability::where(['teacher_id'=>$data['bookingDataInformation']->tutor_id,'status'=>'A'])->get();    
                    }

                    return view('student.modules.my_classes.view_student_class')->with($data);    
                }else{
                    session()->flash("error","You are trying to see the booking details which is not associated with your account!");
                    return redirect()->back();
                }    
            }else{
                session()->flash("error","Booking details which is not associated with your account!");
                return redirect()->back();
            }
            
        }


}
