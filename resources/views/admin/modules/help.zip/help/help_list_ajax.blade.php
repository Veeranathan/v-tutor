<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<div class="table-responsive">
	{{-- start --}}
	 <table id="example2" class="cell-border table table-responsive">
                      <thead>
                        <tr>
                          
                         <th >Questions </th>
                          <th >Help Category </th>
                          <th >Status </th>
                         
                          <th >Date </th>
                          
                          <th> </th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($helps as $key=> $val)
                        <tr id="data{{$val->id}}">
                          
                          <td data-label="Name">
                            {{@$val->question}}
                          </td>
                            <td data-label="Name">
                            @php
                            $cat=DB::table('help_category')->where('id',$val->help_category)->first();
                            @endphp
                            {{@$cat->name}}
                          </td>
                            <td data-label="Name">
                            @if($val->status=="A")
                            Active
                            @else
                            Inactive
                            @endif
                          </td>
                          
                          <td data-label="Name">{{date('d.m.Y', strtotime(@$val->created_at))}} </td>
                          
                        
                          {{--  <td data-label="Name">{{@$val->message}}</td> --}}
                        
                          
                          
                          <td class="reviews-lists">
                            <div class="add_ttrr actions-main ">
                              <a href="javascript:void(0);" class="action-dots"  id="action{{$val->id}}"><img src="{{url('/')}}/public/assets/images/action-dots.png" alt="" onclick="fun({{$val->id}})"></a>
                              <div class="show-actions" id="show-action{{$val->id}}" style="display: none;"> <span class="angle"><img src="{{url('/')}}/public/assets/images/angle.png" alt=""></span>
                              <ul>
                                <li><a onclick="return confirm('Are you sure want to delete this ?');" href="{{route('del.help',$val->id)}}">Delete</a></li>

                                @if($val->status=="A")
                                <li><a onclick=" return confirm('Are you sure want to deactivate this  ?');"href="{{route('inactive.help',$val->id)}}" >Deactivate</a></li>
                                @else
                                <li><a onclick=" return confirm('Are you sure want to activate this  ?');"href="{{route('active.help',$val->id)}}" >Activate</a></li>

                                @endif
                                 {{-- <li><a href="{{route('edit.help',$val->id)}}" >Edit</a></li> --}}
                                  <li><a href="{{route('view.help',$val->id)}}" >View/Edit</a></li>



                                
                              </ul>
                            </div>
                           
                            </div></td>
                          </tr>
                          
                          
                          @endforeach
                          
                        </tbody>
                      </table>
		
	</div>
	<script>
	oTable = $('#example2').DataTable({
	"pageLength":10,
	});
	</script>