
<!-- Bootstrap core JavaScript -->
<script src="{{url('/')}}/public/assets/js/jquerymin.js"></script>
<script src="{{url('/')}}/public/assets/js/bootstrap.js"></script>
<script src="{{url('/')}}/public/assets/js/carouselscript.js"></script>
<script src="{{url('/')}}/public/assets/js/owl.carousel.js"></script>
<script src="{{url('/')}}/public/assets/js/moment.js"></script>
<script src="{{url('/')}}/public/assets/js/jquery-ui.js"></script>
<script src="{{url('/')}}/public/assets/js/custom.js"></script>
<script src="{{url('/')}}/public/assets/js/calendar.js"></script>{{-- 
<script src="{{url('/')}}/public/assets/js/jquery-2.1.4.js"></script> --}}
<script src="{{url('/')}}/public/assets/js/semantic.min.js"></script>
<script>
         
         $(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
      </script>
      <script>
         
         $(".toggle-password1").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
      </script>
<script>
	$('#checkbox1').change(function(){
		if ($(this).prop('checked')==true){ 
			$('.disable-input').prop("disabled",false);
			$('.submit-login').removeClass('disable-input');
		}else{
			// $('.disable-input').Attr('disabled');
			// $('.submit-login').addClass('disable-input');
      $('.submit-login').addClass('disable-input');
      $('.disable-input').prop("disabled",true);
		}
	})
</script>

{{-- ............................. --}}
{{--   <script>
    $('.moreless-button4').click(function() {
        $('.moretext4').slideToggle();
        if($('.moreless-button4').text() == "Read More +") {
            $(this).text("Read Less -")
        } else {
            $(this).text("Read More +")
        }
    });
    </script> --}}
    <script>
    $('.moreless-button5').click(function() {
        $('.more-text5').slideToggle();
        if($('.moreless-button5').text() == "Load  More +") {
            $(this).text("Load Less -")
        } else {
            $(this).text("Load More +")
        }
    });
    </script>
{{--     <script type="text/javascript">
    $(document).ready(function() {
        $(".click_open").click(function() {
            $(".open_menu").slideToggle("slow");
        });
    });
    </script> --}}
    <script type="text/javascript">
    $(document).ready(function() {
        $(".showmeu").click(function() {
            $(".dasbordLeft").slideToggle("slow");
        });
    });
    </script>

    <script type="text/javascript">
        
  $('#example1').calendar();
$('#example2').calendar({
  type: 'date'
});
$('#example3').calendar({
  type: 'time'
});
$('#rangestart').calendar({
  type: 'date',
  endCalendar: $('#rangeend')
});
$('#rangeend').calendar({
  type: 'date',
  startCalendar: $('#rangestart')
});
$('#example4').calendar({
  startMode: 'year'
});
$('#example5').calendar();
$('#example6').calendar({
  ampm: false,
  type: 'time'
});
$('#example7').calendar({
  type: 'month'
});
$('#example8').calendar({
  type: 'year'
});
$('#example9').calendar();
$('#example10').calendar({
  on: 'hover'
});
var today = new Date();
$('#example11').calendar({
  minDate: new Date(today.getFullYear(), today.getMonth(), today.getDate() - 5),
  maxDate: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 5)
});
$('#example12').calendar({
  monthFirst: false
});
$('#example13').calendar({
  monthFirst: false,
  formatter: {
    date: function (date, settings) {
      if (!date) return '';
      var day = date.getDate();
      var month = date.getMonth() + 1;
      var year = date.getFullYear();
      return day + '/' + month + '/' + year;
    }
  }
});
$('#example14').calendar({
  inline: true
});
$('#example15').calendar();

    </script>
