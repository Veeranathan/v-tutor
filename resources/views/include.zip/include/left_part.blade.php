
{{-- this is the login , registration, and landing page header html load --}}


@section('head')
@include('include.head')
@endsection


<!-- header -->
<header class="header_sec">
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light nav_top">
			<a class="navbar-brand" href="{{route('landing.page')}}"><img src="{{url('/')}}/public/assets/images/logo.png" alt="logo" /></a>
			  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
			  	<!-- <ul class="mr-auto">
			  	</ul> -->
		        <ul class="navbar-nav menu_sec">
		        	{{--  @if(Route::is('landing.page'))
		        	<li class="dropdown"><a href="student-postreview.html" class="dropdown-toggle drop-arw">My Reviews</a></li>
		        	@endif --}}
		             <li class="dropdown">
		             	<a href="tutor-search-result.html" class="dropdown-toggle drop-arw" data-toggle="dropdown">Find my V-Tutor </a>
		             	<span class="dropdown-toggle drop-arw" data-toggle="dropdown">
		             		<i class="fas fa-angle-down"></i>
		             	</span>
		             	<ul class="dropdown-menu">
		                    <li class="dropdown-submenu">
		                    	<a href="tutor-search-result.html" class="dropdown-toggle test" data-toggle="dropdown">By Grade</a>
		                    	<span class="dropdown-toggle drop-arw" data-toggle="dropdown">
				             		<i class="fas fa-angle-down"></i>
				             	</span>
				             	<ul class="dropdown-menu">
		             				<li><a href="tutor-search-result.html">Tutors for Grade 1</a></li>
		             				<li><a href="tutor-search-result.html">Tutors for Grade 2</a></li>
		             				<li><a href="tutor-search-result.html">Tutors for Grade 3</a></li>
		             			</ul>
		                    </li>
		                   <!--  <li class="">
		                    	<a href="#url">By Grade</a>
		                    </li> -->
		                    <li class="dropdown-submenu">
		                    	<a href="tutor-search-result.html" class="dropdown-toggle test" data-toggle="dropdown">By Subject</a>
		                    	<span class="dropdown-toggle drop-arw" data-toggle="dropdown">
				             		<i class="fas fa-angle-down"></i>
				             	</span>
		                    	<ul class="dropdown-menu">
		             				<li><a href="tutor-search-result.html"> Tutors for English</a></li>
		             				<li><a href="tutor-search-result.html">Tutors for Maths</a></li>
		             				<li><a href="tutor-search-result.html">Tutors for History</a></li>
		             			</ul>
		                    </li>
		                    <li class="dropdown-submenu">
		                    	<a href="tutor-search-result.html" class="dropdown-toggle test" data-toggle="dropdown">By Topic</a>
		                    	<span class="dropdown-toggle drop-arw" data-toggle="dropdown">
				             		<i class="fas fa-angle-down"></i>
				             	</span>
		                    	<ul class="dropdown-menu">
		             				<li><a href="tutor-search-result.html">Tutors for Topic 1</a></li>
		             				<li><a href="tutor-search-result.html">Tutors for Topic 2</a></li>
		             				<li><a href="tutor-search-result.html">Tutors for Topic 3</a></li>
		             			</ul>
		                    </li>
		                </ul>
		             </li>
		             <li class="dropdown">
		             	<a href="#" class="dropdown-toggle drop-arw" data-toggle="dropdown">Help me with</a><span class="dropdown-toggle drop-arw" data-toggle="dropdown">
		             		<i class="fas fa-angle-down"></i>
		             	</span>
		             	<ul class="dropdown-menu">
		                    <li><a href="tutor-search-result.html">Subjects</a></li>
		                    <li><a href="tutor-search-result.html">Topics</a></li>
		                    <li><a href="tutor-search-result.html">Homework</a></li>
		                    <li><a href="tutor-search-result.html">Projects</a></li>
		                </ul>
		             </li>
		             <li class="dropdown">
		             	<a href="#" class="dropdown-toggle drop-arw" data-toggle="dropdown">Log me in </a><span class="dropdown-toggle drop-arw" data-toggle="dropdown">
		             		<i class="fas fa-angle-down"></i>
		             	</span>
		             	<ul class="dropdown-menu">
		                    <li><a href="{{ route('login') }}">Log me in</a></li>
		                    <li><a href="{{ route('register') }}">Sign me up</a></li>
		                </ul>
		             </li>
		             <li class="dropdown">
		             	<a href="#" class="dropdown-toggle drop-arw" data-toggle="dropdown">Who are we</a><span class="dropdown-toggle drop-arw" data-toggle="dropdown">
		             		<i class="fas fa-angle-down"></i>
		             	</span>
		             	<ul class="dropdown-menu">
		                    <li><a href="{{route('about.us')}}">About V-Tutor</a></li>
		                    <li><a href="about-us.html">Why V-Tutor</a></li>
		                </ul>
		             </li>
		             <li class="dropdown">
		             	<a href="#" class="dropdown-toggle drop-arw" data-toggle="dropdown">Support</a><span class="dropdown-toggle drop-arw" data-toggle="dropdown">
		             		<i class="fas fa-angle-down"></i>
		             	</span>
		             	<ul class="dropdown-menu">
		                    <li><a href="{{route('faq')}}">FAQ’s</a></li>
		                    <li><a href="{{route('contact.us')}}">Message us</a></li>
		                </ul>
		             </li>
		        </ul>
			  </div>
			  <div class="hed_btn">
			  		<ul>
			  			<li><a href="#" class="pg_btn">Book my Class</a></li>
			  			<li><a href="{{route('reg.home')}}" class="pg_btn">Be a V-Tutor</a></li>
			  		</ul>
			  </div>
		</nav>
	</div>
</header>