<?php

namespace App\Http\Controllers\Student\SearchResult;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Models\Subject;
use App\Models\Grade;
use App\Models\TutorshipPlan;
use App\Models\State;
use Auth;
use App\Models\LangToTutor;
use App\Models\Language;
use App\Models\AdminDisableBookings;
use App\Models\AdminDisableBookingDates;


class SearchResultController extends Controller
{
    public function searchResult($slug = NULL,Request $request){
        // dd(session()->all());
        // dd(@session('save_search_on_click_tutor_id'));
        #initialize default data
        $data['admin_disable_bookings_values'] = AdminDisableBookings::first();
        $data['all_disabled_booking_dates'] = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();
        
        $data['states'] = State::get();
        $data['subjects'] = Subject::where('status','A')->select('id','slug','subject','capture_code','status')->orderBy('subject','asc')->get();
        $data['grades'] = Grade::where('status','A')->select('id','slug','grade_name','capture_code','status')->orderBy('grade_name','asc')->get();
        $data['min_hourly_rate_fetch'] = User::where(['user_type'=>'T','status'=>'A'])->min('min_hourly_rate');
        $data['max_hourly_rate_fetch'] = User::where(['user_type'=>'T','status'=>'A'])->max('min_hourly_rate');
        
        $userId = @Auth::user()->id;
        #search tutor data started
        $data['tutors'] = User::with(['getMyAvailability','getMinTutorShipPlan','getMaxTutorShipPlan','getuserToFavourite'=> function($query) use($userId) {
            $query->where(function($q) use($userId) {
                $q->where('user_id', $userId);
            });
        },'getTutorAcademic','languguageToTuor:id,tutor_id,language_id','languguageToTuor.languageName:id,language','getState:id,slug,state_name','getTutorShipPlan.getSubject:id,slug,subject,capture_code,status','getTutorShipPlan.getGrade:id,slug,grade_name,capture_code,status','getTutorShipPlan:id,teacher_id,grade_id,subject_id,hourly_rate,status'])->where(['user_type'=>'T','status'=>'A']);
        $maxTotalExp = 0;
        $maxTotalExp = User::where(['status'=>'A','user_type'=>'T'])->max('total_experience');
        $data['maxTotalExp'] = $maxTotalExp;
        if($maxTotalExp < 2){
            $data['experience_arr'] = range(0, $maxTotalExp);
        }else{
            $data['experience_arr'] = range(0, $maxTotalExp,2);    
        }
        
        

        #filter started
        if(@$request->all())
        {
            // dd($request->all());
            if(@$request->grade){
                // dd($request->all());
                $grade = Grade::where(['slug'=>$request->grade])->first();
                $data['tutors'] = $data['tutors']->whereHas('getTutorShipPlan.getGrade',function($q) use($request){
                    $q->where('slug',$request->grade);
                });
            }
            if(@$request->subject_id) {

                $subjectIds = Subject::whereIn('slug',$request->subject_id)->pluck('id')->toArray();
                if(@$request->grade){
                    $grade = Grade::where(['slug'=>$request->grade])->first();

                    $data['tutors'] = $data['tutors']->whereHas('getTutorShipPlan',function($q) use($request,$grade,$subjectIds){
                        $q->whereIn('subject_id',$subjectIds)->where('grade_id',$grade->id);
                    });
                }else{
                    $data['tutors'] = $data['tutors']->whereHas('getTutorShipPlan.getSubject',function($q) use($request){
                        $q->whereIn('slug',@$request->subject_id);
                    });
                }
                
            }
            if(@$request->state) {
                $data['tutors'] = $data['tutors']->whereHas('getState',function($q) use($request){
                    $q->where('slug',@$request->state);
                });
            }
            
            if(@$request->experience)
            {
                $experience_ar_split = explode(" ",$request->experience);
                // $experience_ar_split1 = explode("-",$experience_ar_split[0]);
                // dd($experience_ar_split[1]);
                if(@$experience_ar_split[0] && @$experience_ar_split[1]){
                    // dd("jfa");
                    $data['tutors'] = $data['tutors']->where(function($q) use($experience_ar_split){
                        $q->whereBetween('total_experience',[$experience_ar_split[0],$experience_ar_split[1]]);
                    });
                }else{
                    // dd($experience_ar_split[0]);
                    if(@$experience_ar_split[0]){
                        $data['tutors'] = $data['tutors']->where(function($q) use($experience_ar_split){
                            $q->where('total_experience','>=',$experience_ar_split[0]);
                        });
                    }
                    if(@$experience_ar_split[1]){
                        $data['tutors'] = $data['tutors']->where(function($q) use($experience_ar_split){
                            $q->where('total_experience','<=',$experience_ar_split[1]);
                        });
                    }        
                }
            }
            if(@$request->review) {
                $data['tutors'] = $data['tutors']->where(function($q) use($request){
                    $q->where('avg_review','>=',$request->review);
                });
            }
            if(@$request->min_hourly_rate && @$request->max_hourly_rate) {
                // $data['tutors'] = $data['tutors']->where(function($q) use($request){
                //     $q->where('min_hourly_rate','>=',$request->min_hourly_rate);
                // });
                $data['tutors'] = $data['tutors']->where(function($q) use($request){
                    $q->where('min_hourly_rate','>=',$request->min_hourly_rate);
                });
                $data['tutors'] = $data['tutors']->where(function($q) use($request){
                    $q->where('min_hourly_rate','<=',$request->max_hourly_rate);
                });
                // $data['tutors'] = $data['tutors']->where(function($q) use($request){
                //     $q->whereBetween('min_hourly_rate',[$request->min_hourly_rate,$request->max_hourly_rate]);
                // });
            }
            if(@$request->min_hourly_rate){
                $data['tutors'] = $data['tutors']->where(function($q) use($request){
                    $q->where('min_hourly_rate','>=',@$request->min_hourly_rate);
                });    
            }
            if(@$request->max_hourly_rate){
                $data['tutors'] = $data['tutors']->where(function($q) use($request){
                    $q->where('min_hourly_rate','<=',@$request->max_hourly_rate);
                });
            }
            // dd($request->all());
            $data['tutors'] = $data['tutors']->select('id','f_name','l_name','slug','user_type','student_type','status','avatar','profile_pic','about_me','profile_video','video_short_url','total_experience','total_no_of_reviews','avg_review','min_hourly_rate','created_at','state','timezone_id');
            if(@$request->sort_type == 'D') {
                $data['tutors'] = $data['tutors']->orderby('created_at','desc');
            }
            else if(@$request->sort_type == 'R') {
                $data['tutors'] = $data['tutors']->orderby('avg_review','desc');
            }
            else if(@$request->sort_type == 'E') {
                $data['tutors'] = $data['tutors']->orderby('total_experience','desc');
            }else if(@$request->sort_type == 'H') {
                $data['tutors'] = $data['tutors']->orderby('min_hourly_rate','desc');
            }
            else if(@$request->sort_type == 'L') {
                $data['tutors'] = $data['tutors']->orderby('min_hourly_rate','asc');
            }
            else{
                $data['tutors'] = $data['tutors']->orderby('avg_review','desc');    
            }
            
        }else{
            $data['tutors'] = $data['tutors']->orderby('avg_review','desc');    
        }
        // dd($data['tutors']->get());
        #show count data 
        // $data['count'] = @$data['tutors']->count();

        #search output data
        $data['tutors'] = $data['tutors']->paginate(10)->appends(request()->query());     
        // dd($data['tutors']);
        
        $data['key'] = @$request->all();
        
        #get specific filter data
        $data['grade_obj'] = Grade::where('slug',@$request->grade)->select('id','slug','grade_name','status','capture_code')->first();
        $data['grade_value'] = @$request->grade;
        $data['subject_slugs'] = @$request->subject_id;
        $data['state_value'] = State::where('slug',@$request->state)->select('id','slug','state_name')->first();
        $data['state_slug'] = @$request->state;
        if(@$request->review){
            $data['review_value'] = $request->review;    
        }
        $data['sort_type_value'] = @$request->sort_type;
        $data['experience_value'] = @$request->experience;
        $experience_ar_split = explode("-",@$request->experience);
        $data['min_experience_value'] = trim(@$experience_ar_split[0]);
        $data['max_experience_value'] = trim(@$experience_ar_split[1]);
        $data['hourly_rate_value'] = @$request->hourly_rate;
        $data['request_min_hourly_rate'] = @$request->min_hourly_rate;
        $data['request_max_hourly_rate'] = @$request->max_hourly_rate;
        return view('student.modules.search_result.search_result')->with($data);
    }
    public function applyFilter(Request $request){
        
    }
    public function addToFavourite(Request $request){
        
    }
    public function saveSearchOnClickValue(Request $request){
        if(@$request->save_on_click_value){
            session(['save_on_click_value' => @$request->save_on_click_value]);    
        }
        if(@$request->save_search_on_click_tutor_id){
            session(['save_search_on_click_tutor_id' => @$request->save_search_on_click_tutor_id]);
        }
        if(@$request->book_subject){
            session(['book_subject' => @$request->book_subject]);    
        }
        if(@$request->book_grade){
            session(['book_grade' => @$request->book_grade]);    
        }
        return 1;
    }
    
}
