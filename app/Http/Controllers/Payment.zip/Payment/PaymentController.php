<?php

namespace App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
#models
use App\Models\StudentClassBooking;

#stripe
use Stripe\Stripe;

class PaymentController extends Controller
{
    public function viewPaymentPage(Request $request){
        return view('payment.view_payment_page');
    }
    /**
    * Method: init
    * Description: This method is used to init payment.
    * Author: Sanjoy Mandal
    */
    public function init(Request $request) {
        try{
            $data['orderEncryptId'] = $request->track;
            $bookingNo = decrypt($request->track);
            $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['id'=>$bookingNo])->first();
            if(@$data['bookingDataInformation']){
                
                return view('payment.init_payment')->with($data);
            }else{
                session()->flash("error","Booking no is not matched!Please provide correct booking no!");
                return redirect()->back();
            }
        }
        catch(\Exception $e) {
          abort('401');
        }
    }
    public function initPaymentCreateObject(Request $request){
        return redirect()->route('payment.init', ['track' => encrypt(96)]);
    }

    public function redirectToGateway(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'card_no' => 'required',
            'ccExpiryMonth' => 'required',
            'ccExpiryYear' => 'required',
            'cvvNumber' => 'required',
        ]);
        // $input = $request->all();
        // if ($validator->passes()) { 
        //     $input = array_except($input,array('_token'));
        //     $stripe = \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        //     try {
        //         if (!empty(@$request->stripeToken)) 
        //         {
        //             $customer = \Stripe\Customer::create(array(
        //                 "name"  => @$request->name_of_card,
        //                 "email"  => @Auth::user()->email,
        //                 'description' => "My First Test Customer from My Sister Closet's",
        //             ));
        //             \Stripe\Customer::createSource(
        //                 $customer->id,
        //                 ['source' => @$request->stripeToken]
        //             );
        //             Auth::user()->update(['stripe_id' => $customer->id,'stripe_token' => @$request->stripeToken]);
        //         }
        //         if($customer && $customer->id)
        //         {
                    
        //             $charge = \Stripe\Charge::create([
        //                 "amount" => @$request->amount,
        //                 "customer" => @$customer->id,
        //                 "currency" => getCurrency(),
        //                 // "source" => @$request->stripeToken,
        //                 "description" => "Test payment from My Sister Closet's",
        //                 "metadata" => [@$request->metadata], 
        //             ]);
        //         }
        //         else
        //         {
        //             \Session::flash('error','Payment credentials not valid');
        //             return redirect()->back();
        //         }
        //         if(!empty($charge['status']))
        //         {
        //             $orderId = $request->orderId;
        //             if($charge['status'] == 'succeeded') {
        //                 $orderChk = $this->order->with([
        //                     'orderMasterDetails.productDetails',
        //                     'orderMasterDetails.productVariantDetails',
        //                     'customerDetails',
        //                     'getBillingCountryCode',
        //                 ])
        //                 ->where(['id' => $orderId])
        //                 ->first();
        //                 $paymentDetails = [];
        //                 $params = [
        //                     'response'  => json_encode(@$charge),
        //                     'txn_id'    => @$charge['id'],
        //                     'status'    => 'S'
        //                 ];
        //                 $this->updatePayment($params, $orderId);
        //                 $this->updateOrderStatus($orderId);
        //                 $this->sendCustomerAndSellerMail($orderId);
        //                 $response['result']['status'] = 'success';
        //                 $this->clearCart();
        //                 return redirect()->route('order.success', ['trackId' => encrypt($orderId)]);
        //             } else {
        //                 $params = [
        //                     'response'  => json_encode(@$charge),
        //                     'txn_id'    => @$charge['id'],
        //                     'status'    => 'F',
        //                 ];
        //                 $this->updatePayment($params, $orderId);
        //                 $this->orderMaster->where(['id' => @$orderId])->update(['status' => 'F']);
        //                 return view('modules.payment.payment_failed')->with(['ref_id' => @$charge['id']]);

        //             }

        //         }
        //         else{
        //             \Session::flash('error','Payment credentials not valid');
        //             return redirect()->back();
        //         }
        //     }

        //     catch (Exception $e) {
        //         \Session::flash('error',$e->getMessage());
        //         return redirect()->back();
        //     } catch(\Cartalyst\Stripe\Exception\CardErrorException $e) {
        //         \Session::flash('error',$e->getMessage());
        //         return redirect()->back();
        //     } catch(\Cartalyst\Stripe\Exception\MissingParameterException $e) {
        //         \Session::flash('error',$e->getMessage());
        //         return redirect()->back();
        //     }
        // }
    }
}
