<?php

namespace App\Http\Controllers\Student\BookClass;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Models\Subject;
use App\Models\AdminDisableBookings;
use App\Models\AdminDisableBookingDates;
use App\Models\StudentClassBooking;
use App\Models\MyAvailability;
use App\Models\TutorshipPlan;
use App\Models\UserToFavourite;
use App\Models\Tutor_calander_availability;
use App\Models\Grade;
use App\Models\Payments;
use App\Models\Commissions;
use App\User;
use Validator;
use Mail;
use App\Mail\StudentClassBookingMail;
use Illuminate\Support\Facades\Redirect;
use App\Mail\CancelBookingMail;

use App\Models\TokenModel;
use GuzzleHttp;



class BookClassController extends Controller
{
    public function cancelIncompleteBooking($id){
        $bookingInfo = StudentClassBooking::where(['id'=>$id])->first();
        StudentClassBooking::where(['id'=>$id])->whereIn('booking_status',['IC'])->delete();
        Payments::where(['booking_id'=>$id,'status'=>'I'])->delete();
        session()->flash("success","Booking cancelled. You may book again!");
        $getUser = User::where(['id'=>$bookingInfo->tutor_id])->first();
        $to_p = url('studentbook-class?search_tutor_nm_studentclass='.$getUser->f_name." ".$getUser->l_name.'&search_tutor_id_studentclass='.$getUser->id.'&search_tutor_selected_name_studentclass='.$getUser->f_name." ".$getUser->l_name.'&search_tutor_slug_studentclass='.$getUser->slug.'&book_subject='.session('book_subject'));
                return Redirect::to($to_p);    
        // return redirect()->route('student.book.class');
    }
    /*
    * Method        : studentBookClass
    * Description   : This method is 
    * Author        : Jayatri 
    */
    public function studentBookClass($slug = NULL,$id = NULL,Request $request){
        $data['admin_disable_bookings_values'] = $admin_disable_bookings_values = AdminDisableBookings::first();
        $data['all_disabled_booking_dates']= $all_disabled_booking_dates = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();
        if(@$admin_disable_bookings_values->disable_booking == 'Y'){
            session()->flash("error","Choose available time slot");
                return redirect()->back();
        }                                    
        

        try{
            // add can you restrict the availability of dates in the calendar 30 days
            $data['nextMaxDate'] = date('Y-m-d', strtotime("+30 days"));

            $userId = @Auth::user()->id;
            $gradeId = @Auth::user()->grade;
            $data['favs'] = UserToFavourite::with(['getStudentInfo','getTutorInfo.getTutorShipPlan'])->where(['user_id'=>@Auth::user()->id]);
            $data['favs'] = $data['favs']->whereHas('getTutorInfo.getTutorShipPlan',function($q) use($gradeId){
                $q->where('grade_id',$gradeId);
            });
            $data['favs'] = $data['favs']->select('id','user_id','favourite_user_id')->get();
            
            $data['grade'] = Grade::where(['id'=>@Auth::user()->grade,'status'=>'A'])->first();
            
            $student_grade_name = Grade::where(['id'=>@Auth::user()->grade])->first();
            $data['all_days'] = array(1,2,3,4,5,6,7);
            if(@$request->all()){

                if(@session('save_search_on_click_tutor_id') != 0 && @session('save_search_on_click_tutor_id')){
                    $data['book_subject'] = @$request->book_subject;    
                    if(@session('book_grade') != 0 && @session('book_grade') != @Auth::user()->grade){
                        session()->flash("error","You cannot book for other grade except your grade!Your grade is ".@$student_grade_name->grade_name);        
                    }else{
                        $gradeId = @Auth::user()->grade;
                        $data['vtutor'] = User::with(['getTutorShipPlan.getSubject','getTutorAcademic','languguageToTuor'])->where(['id'=>session('save_search_on_click_tutor_id'),'status'=>'A']);

                        if(@session('book_subject') != 0 && @session('book_grade') != 0){
                            $data['book_subject'] = $subjectId = Subject::where(['id'=>session('book_subject')])->first();
                            if(@$subjectId){
                                $data['vtutor'] = $data['vtutor']->whereHas('getTutorShipPlan',function($q) use($gradeId,$subjectId){
                                    $q->where(['grade_id'=>$gradeId,'subject_id'=>$subjectId]);
                                });     
                            }
                        }else{
                            $data['vtutor'] = $data['vtutor']->whereHas('getTutorShipPlan',function($q) use($gradeId){
                                $q->where(['grade_id'=>$gradeId]);
                            });
                        }
                        $data['vtutor'] = $data['vtutor']->first();
                        if(@$data['vtutor']){
                            if(@$data['vtutor']->state != @Auth::user()->state && @$data['vtutor']->timezone_id != @Auth::user()->timezone_id){
                                session()->flash("error","State and timezone and grade doesn't match with tutor !"); 
                                return redirect()->back();       
                            }
                            $data['subjects'] = TutorshipPlan::with(['getSubject'])->where(['teacher_id'=>$data['vtutor']->id,'grade_id'=>@Auth::user()->grade,'status'=>'A'])->get();
                            $data['subjects'] = TutorshipPlan::with(['getSubject'])->where(['teacher_id'=>$data['vtutor']->id,'grade_id'=>@Auth::user()->grade,'status'=>'A'])->get();
                            $data['t_my_av_show'] = MyAvailability::where(['teacher_id'=>$data['vtutor']->id,'status'=>'A'])->get();

                            $allbook=Tutor_calander_availability::where('booking_status','B')->where('date','<=',$data['nextMaxDate'])->where('date','>=',date('Y-m-d'))->where('tutor_id',(int)$data['vtutor']->id)->get();

                            $data['get_available_dates'] = Tutor_calander_availability::where(['tutor_id'=>$data['vtutor']->id,'booking_status'=>'NB'])->where('date','>=',date('Y-m-d'))->where('date','<=',$data['nextMaxDate'])->pluck('date')->toArray();

                            $data['get_available_start_times'] = Tutor_calander_availability::where(['tutor_id'=>$data['vtutor']->id,'booking_status'=>'NB'])->groupBy('start_time')->pluck('start_time')->toArray();
                            $data['get_available_end_times'] = Tutor_calander_availability::where(['tutor_id'=>$data['vtutor']->id,'booking_status'=>'NB'])->groupBy('end_time')->pluck('end_time')->toArray();
                            //dd($allbook);
                            $bookedd2=[];
                            if(@$allbook){
                                foreach($allbook as $val){
                                    $date=explode("-",$val->date);
                                    $from=explode(":",$val->start_time);
                                    $to=explode(":",$val->end_time);
                                   // dd($date,$from,$to);

                                    $data12=[];
                                     //$data12['id']=$val->id;
                                    $data12['year']=$date[0];
                                    $data12['month']=$date[1];
                                    $data12['day']=$date[2];

                                    $data12['from_hour']=$from[0];
                                    $data12['from_min']=$from[1];

                                    $data12['to_hour']=$to[0];
                                    $data12['to_min']=$to[1];

                                     array_push($bookedd2, $data12);

                                }    
                            }
                            
                            $data['booked']=$bookedd2;
                            /*for availabale booking*/
                            $notbook=Tutor_calander_availability::where('booking_status','NB')->where('date','<=',$data['nextMaxDate'])->where('date','>=',date('Y-m-d'))->where('tutor_id',(int)$data['vtutor']->id)->whereNotIn('date',$all_disabled_booking_dates)->get();
                           
                            $nb=[];
                            if(@$notbook){
                                foreach($notbook as $val){
                                    $date=explode("-",$val->date);
                                    $from=explode(":",$val->start_time);
                                    $to=explode(":",$val->end_time);
                                   // dd($date,$from,$to);

                                    $data12=[];
                                     //$data12['id']=$val->id;
                                    $data12['year']=$date[0];
                                    $data12['month']=$date[1];
                                    $data12['day']=$date[2];

                                    $data12['from_hour']=$from[0];
                                    $data12['from_min']=$from[1];

                                    $data12['to_hour']=$to[0];
                                    $data12['to_min']=$to[1];

                                     array_push($nb, $data12);

                                }    
                            }
                            $data['notbook']=$nb;
                            $data['key'] = @$request->all();
                            $data['book_subject'] = @$request->book_subject;
                            // $data['get_available_dates'] = Tutor_calander_availability::where(['tutor_id'=>$data['vtutor']->id,'booking_status'=>'NB']);
                            // $data['get_available_dates'] = $data['get_available_dates']->pluck('date')->toArray(); 
                            // $data['get_available_times'] = Tutor_calander_availability::where(['tutor_id'=>@$request->search_tutor_id,'booking_status'=>'NB']);
                            // $data['get_available_times'] = $data['get_available_times']->groupBy('start_time')->pluck('start_time')->toArray();
                            // $data['get_available_to_times'] = Tutor_calander_availability::where(['tutor_id'=>@$request->search_tutor_id,'booking_status'=>'NB'])->groupBy('end_time')->pluck('end_time')->toArray();
                        }
                        else{
                            session()->flash("error","You cannot book for other grade except your grade!No Vtutor found depending upon grade subject commbination!Your grade is ".@$student_grade_name->grade_name);        
                        }
                        
                    }                
                }else{
                    // $data['vtutor'] = User::with(['getTutorShipPlan.getSubject','getTutorAcademic','languguageToTuor']);
                    if(@$request->search_tutor_id){
                        $data['vtutor'] = User::with(['getTutorShipPlan.getSubject','getTutorAcademic','languguageToTuor'])->where(['id'=>@$request->search_tutor_id,'status'=>'A']); $gradeId = @Auth::user()->grade;
                        $data['vtutor'] = $data['vtutor']->whereHas('getTutorShipPlan',function($q) use($gradeId){
                            $q->where(['grade_id'=>$gradeId]);
                        }); 
                        $data['vtutor'] = $data['vtutor']->first();
                        if(@$data['vtutor']->state != @Auth::user()->state && @$data['vtutor']->timezone_id != @Auth::user()->timezone_id){
                            session()->flash("error","State and timezone and grade doesn't match with tutor !"); 
                            return redirect()->back();       
                        }
                        // $data['get_available_dates'] = Tutor_calander_availability::where(['tutor_id'=>@$request->search_tutor_id,'booking_status'=>'NB']);
                        // $data['get_available_dates'] = $data['get_available_dates']->pluck('date')->toArray();
                    
                    }
                    if(@$request->search_tutor_id_studentclass){
                        $data['vtutor'] = User::with(['getTutorShipPlan.getSubject','getTutorAcademic','languguageToTuor'])->where(['id'=>@$request->search_tutor_id_studentclass,'status'=>'A']);  
                        $gradeId = @Auth::user()->grade;
                        $data['vtutor'] = $data['vtutor']->whereHas('getTutorShipPlan',function($q) use($gradeId){
                            $q->where(['grade_id'=>$gradeId]);
                        }); 
                        $data['vtutor'] = $data['vtutor']->first();
                        if(@$data['vtutor']->state != @Auth::user()->state && @$data['vtutor']->timezone_id != @Auth::user()->timezone_id){
                            session()->flash("error","State and timezone and grade doesn't match with tutor !"); 
                            return redirect()->back();       
                        }
                    }
                    
                    if(@$data['vtutor']){
                        if(@$data['vtutor']->state != @Auth::user()->state && @$data['vtutor']->timezone_id != @Auth::user()->timezone_id){
                            session()->flash("error","State and timezone and grade doesn't match with tutor !"); 
                            return redirect()->back();       
                        }
                        $data['subjects'] = TutorshipPlan::with(['getSubject'])->where(['teacher_id'=>$data['vtutor']->id,'grade_id'=>@Auth::user()->grade,'status'=>'A'])->get();
                        $data['t_my_av_show'] = MyAvailability::where(['teacher_id'=>$data['vtutor']->id,'status'=>'A'])->get();

                        $allbook=Tutor_calander_availability::where('booking_status','B')->where('tutor_id',(int)$data['vtutor']->id)->where('date','<=',$data['nextMaxDate'])->where('date','>=',date('Y-m-d'))->whereNotIn('date',$all_disabled_booking_dates)->get();

                        $data['get_available_dates'] = Tutor_calander_availability::where(['tutor_id'=>$data['vtutor']->id,'booking_status'=>'NB'])->where('date','>=',date('Y-m-d'))->where('date','<=',$data['nextMaxDate'])->pluck('date')->toArray();

                        $data['get_available_start_times'] = Tutor_calander_availability::where(['tutor_id'=>$data['vtutor']->id,'booking_status'=>'NB'])->groupBy('start_time')->pluck('start_time')->toArray();
                        $data['get_available_end_times'] = Tutor_calander_availability::where(['tutor_id'=>$data['vtutor']->id,'booking_status'=>'NB'])->groupBy('end_time')->pluck('end_time')->toArray();
                        

                        //dd($allbook);
                        $bookedd2=[];
                        if(@$allbook){
                            foreach($allbook as $val){
                                $date=explode("-",$val->date);
                                $from=explode(":",$val->start_time);
                                $to=explode(":",$val->end_time);
                               // dd($date,$from,$to);

                                $data12=[];
                                 //$data12['id']=$val->id;
                                $data12['year']=$date[0];
                                $data12['month']=$date[1];
                                $data12['day']=$date[2];

                                $data12['from_hour']=$from[0];
                                $data12['from_min']=$from[1];

                                $data12['to_hour']=$to[0];
                                $data12['to_min']=$to[1];

                                 array_push($bookedd2, $data12);

                            }    
                        }
                        
                        $data['booked']=$bookedd2;
                        /*for availabale booking*/
                        $notbook=Tutor_calander_availability::where('booking_status','NB')->where('date','<=',$data['nextMaxDate'])->where('date','>=',date('Y-m-d'))->whereNotIn('date',$all_disabled_booking_dates)->where('tutor_id',(int)$data['vtutor']->id)->get();
                       
                        $nb=[];
                        if(@$notbook){
                            foreach($notbook as $val){
                                $date=explode("-",$val->date);
                                $from=explode(":",$val->start_time);
                                $to=explode(":",$val->end_time);
                               // dd($date,$from,$to);

                                $data12=[];
                                 //$data12['id']=$val->id;
                                $data12['year']=$date[0];
                                $data12['month']=$date[1];
                                $data12['day']=$date[2];

                                $data12['from_hour']=$from[0];
                                $data12['from_min']=$from[1];

                                $data12['to_hour']=$to[0];
                                $data12['to_min']=$to[1];

                                 array_push($nb, $data12);

                            }    
                        }
                        
                        $data['notbook']=$nb;
                    }else{
                        session()->flash("error","You cannot book for other grade except your grade!No Vtutor found depending upon grade subject commbination!Your grade is ".@$student_grade_name->grade_name);    
                    }
                    $data['key'] = @$request->all();
                    $data['book_subject'] = @$request->book_subject;
                }
            }
            
            session(['book_subject' => 0]);
            session(['book_grade' => 0]);
            session(['save_search_on_click_tutor_id' => 0]);
            session(['save_on_click_value'=>'NA']);
            $data['key'] = @$request->all();
            $data['book_subject'] = @$request->book_subject;
            return view('student.modules.studentbook_class.studentbook_class')->with($data);
        
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            session()->flash("error",$e->getMessage());
            return redirect()->back();
        }
        
    }
    
    public function ajaxCheckingBookingSlot(Request $request){
        try{
            $booking_date = trim($request->data['booking_date']);
            $tutor_id = trim($request->data['tutor_id']);
            $data['get_available_start_times'] = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->groupBy('start_time')->pluck('start_time')->toArray();
            
            $minSTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->min('start_time');
            $data['min_available_start_times'] = date('h:i a',strtotime($minSTime));

            $maxSTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->max('start_time');
            $data['max_available_start_times'] = date('h:i a',strtotime($maxSTime));

            $data['get_available_end_times'] = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->groupBy('end_time')->pluck('end_time')->toArray();

            $min_end_times = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->min('end_time');
            $data['min_available_end_times'] = date('h:i a',strtotime($min_end_times));

            $maxETime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->max('end_time');
            $data['max_available_end_times'] = date('h:i a',strtotime($maxETime));
            // $data['get_available_start_times'] = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->groupBy('start_time')->pluck('start_time')->toArray();
            
            // $minSTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->min('start_time');
            // $data['min_available_start_times'] = date('h:i a',strtotime($minSTime));

            // $maxSTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->max('start_time');
            // $data['max_available_start_times'] = date('h:i a',strtotime($maxSTime));

            // $data['get_available_end_times'] = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->groupBy('end_time')->pluck('end_time')->toArray();

            // $min_end_times = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->min('end_time');
            // $data['min_available_end_times'] = date('h:i a',strtotime($min_end_times));

            // $maxETime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->max('end_time');
            // $data['max_available_end_times'] = date('h:i a',strtotime($maxETime));
            return response()->json($data,200);
            

        }catch(\Exception $e){
            \Log::error($e->getMessage());
            $data['message'] = $e->getMessage();
            return response()->json($data,200);
        }
    }
    public function ajaxCheckTimeSlot(Request $request){
        try{
            $booking_date = trim($request->data['booking_date']);
            $tutor_id = trim($request->data['tutor_id']);
            $from_time = date('h:i a',strtotime(trim($request->data['from_time'])));
            $data['get_available_start_times'] = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->groupBy('start_time')->pluck('start_time')->toArray();
            
            $minSTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->min('start_time');
            $data['min_available_start_times'] = date('h:i a',strtotime($minSTime));

            $maxSTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->max('start_time');
            $data['max_available_start_times'] = date('h:i a',strtotime($maxSTime));

            $data['get_available_end_times'] = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->where('start_time','>=',$from_time)->groupBy('end_time')->pluck('end_time')->toArray();

            $min_end_times = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->where('start_time','>=',$from_time)->min('end_time');
            $data['min_available_end_times'] = date('h:i a',strtotime($min_end_times));

            $maxETime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->where('start_time','>=',$from_time)->max('end_time');
            $data['max_available_end_times'] = date('h:i a',strtotime($maxETime));
            return response()->json($data,200);
            

        }catch(\Exception $e){
            \Log::error($e->getMessage());
            $data['message'] = $e->getMessage();
            return response()->json($data,200);
        }
    }
    public function ajaxCheckBookingDate(Request $request){
        try{

            $tutor_id = trim($request->data['tutor_id']);
            $bookingDate = date("Y-m-d", strtotime($request->data['get_booking_date']));
            $from_time = date("H:i:s", strtotime($request->data['from_time']));
            $to_time = date("H:i:s", strtotime($request->data['to_time']));
            $day = date("D", strtotime($request->data['get_booking_date']));
            if(@$bookingDate < date('Y-m-d')){
                $data['output'] = 'false';
                $data['message'] = 'Date is not available';
                return response()->json($data,200);   
            }
            if(@$bookingDate == date('Y-m-d')){
                if($from_time <= date('H:i:s') || $to_time <= date('H:i:s')){        
                    $data['output'] = 'false';
                    $data['message'] = 'Choose another time slot';
                    return response()->json($data,200);
                }   
            }
            $admin_disable_bookings_values = AdminDisableBookings::first();
            $all_disabled_booking_dates = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();

            if($day == "Mon"){
                $dValue = 1;
            }
            if($day == "Tue"){
                $dValue = 2;
            }
            if($day == "Wed"){
                $dValue = 3;
            }
            if($day == "Thu"){
                $dValue = 4;
            }
            if($day == "Fri"){
                $dValue = 5;
            }
            if($day == "Sat"){
                $dValue = 6;
            }
            if($day == "Sun"){
                $dValue = 7;
            }
            if($bookingDate < date('Y-m-d')){
                if($from_time <= date('H:i:s') || $to_time <= date('H:i:s')){        
                    $data['output'] = 'false';
                    $data['condition_no'] = '5';
                    return response()->json($data,200);
                }   
            }
            if(@$admin_disable_bookings_values->disable_booking == 'Y'){
                $data['output'] = 'false';
                $data['condition_no'] = '11';
                $data['message'] = 'You cannot make bookings at this time. Please contact support';
                return response()->json($data,200);
                
            }elseif(in_array($bookingDate,$all_disabled_booking_dates)){
                $data['output'] = 'false';
                $data['condition_no'] = '11';
                $data['message'] = 'You cannot make bookings for this particular date.Please contact support!Choose available slot!';
                return response()->json($data,200);
            }
            // check whether tutor is available or not 
            $starttime = $from_time;  // your start time
            $endtime = $to_time;  // End time
            $duration = '30';  // split by 30 mins

            $array_of_time = array ();
            $start_time    = strtotime ($starttime); //change to strtotime
            $end_time      = strtotime ($endtime); //change to strtotime

            $add_mins  = $duration * 60;    
            while ($start_time <= $end_time) // loop between time
            {
               $array_of_time[] = date ("h:i:s", $start_time);
               $start_time += $add_mins; // to check endtie=me
            } 
            $length=count($array_of_time);
            $from_to_times=[];
            $get_all_from_times=[];
            $get_all_to_times=[];

            for($k=0;$k<$length;$k++){
                $data=[];
                if($k+1<$length){
                    $data['from_time']=$array_of_time[$k];
                    $data['to_time']=$array_of_time[$k+1];
                    $frmT = "'".$data['from_time']."'";
                    $toT = "'".$data['to_time']."'";
                    array_push($from_to_times,$data);
                    array_push($get_all_from_times,$frmT);
                    array_push($get_all_to_times,$toT);
                }
            }
            $timeSlotCount = count($from_to_times);
            // check available or not
            $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'B','date'=>$bookingDate])->where('start_time','>=',$from_time);
            
            $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                $query->whereBetween('end_time',[$from_time,$to_time]);
            });
            
            $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
            
            if($chkBDtFrmTimeToTime > 0){
                $data['output'] = 'false';
                $data['condition_no'] = '2';
                $data['message'] = 'In between some time slots are booked!'."chkBDtFrmTimeToTime : ".$chkBDtFrmTimeToTime." timeSlotCount : ".$timeSlotCount;
                return response()->json($data,200);
            }
            // check available if
            $chkADtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$bookingDate])->where('start_time','>=',$from_time);
            
            $chkADtFrmTimeToTime = $chkADtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                $query->whereBetween('end_time',[$from_time,$to_time]);
            });
            
            $chkADtFrmTimeToTime = $chkADtFrmTimeToTime->count();
            
            if($chkADtFrmTimeToTime <= 0){
                $data['output'] = 'false';
                $data['condition_no'] = '3';
                $data['message'] = 'Time slot is not available';
                $data['d'] = 'Time slot is not available'."chkADtFrmTimeToTime : ".$chkADtFrmTimeToTime." timeSlotCount : ".$timeSlotCount;
                return response()->json($data,200);
            }
            if($timeSlotCount == $chkADtFrmTimeToTime){
                $data['output'] = 'true';
                $data['condition_no'] = '4';
                $data['message'] = 'This time slot is available';
                return response()->json($data,200);
            }else{
                $data['output'] = 'false';
                $data['condition_no'] = '3';
                $data['message'] = 'Time slot is not available';
                return response()->json($data,200);   
            }
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            $data['message'] = $e->getMessage();
            $data['output'] = 'false';
            return response()->json($data,200);
        }
    }
    public function getStudentGradeTutorData(Request $request){
        $gradeId = @Auth::user()->grade;
        if(@$gradeId){
            $data['grade_tutors'] = User::with(['getTutorShipPlan'])->where(['status'=>'A','user_type'=>'T']);
            if(@$request->search_u_name){
                $data['grade_tutors'] = $data['grade_tutors']->where(function($query) use($request) {
                    $query->Where('f_name','like','%'.$request->search_u_name.'%')
                    ->orWhere('l_name','like','%'.$request->search_u_name.'%')
                    ->orWhere(\DB::raw("CONCAT(`f_name`, ' ', `l_name`)"), 'like', '%' . $request->search_u_name. '%');
                });    
            }
            $data['grade_tutors'] = $data['grade_tutors']->whereHas('getTutorShipPlan',function($q) use($gradeId,$request){
                $q->where(['grade_id'=>$gradeId]);
            });  
            if(@$request->book_grade && @$request->book_subject){
                $gradeId = (int)(@$request->book_grade);
                $subjectslug = @$request->book_subject;
                $subject =Subject::where(['slug'=>$subjectslug])->first();
                if(@$subject){
                    $data['grade_tutors'] = $data['grade_tutors']->whereHas('getTutorShipPlan',function($q) use($request,$subject,$gradeId){
                        $q->where(['grade_id'=>$gradeId,'subject_id'=>$subject->id]);
                    });        
                }else{
                    $data['grade_tutors'] = $data['grade_tutors']->whereHas('getTutorShipPlan',function($q) use($request,$subject,$gradeId){
                        $q->where(['grade_id'=>$gradeId]);
                    });        
                }
                
            }else{
                $gradeId = (int)(@$request->book_grade);
                // $subjectslug = @$request->book_subject;
                // $subject =Subject::where(['slug'=>$subjectslug])->first();
                $data['grade_tutors'] = $data['grade_tutors']->whereHas('getTutorShipPlan',function($q) use($request,$gradeId){
                    $q->where(['grade_id'=>$gradeId]);
                });    
            }
            $data['grade_tutors'] = $data['grade_tutors']->select('id','f_name','l_name','user_type','slug','status')->get();    
            $data['grade_id'] =$gradeId; 
        }else{
            $gradeId = (int)(@$request->book_grade);
            $subjectslug = @$request->book_subject;
            $subject =Subject::where(['slug'=>$subjectslug])->first();
            $data['grade_tutors'] = User::with(['getTutorShipPlan'])->where(['status'=>'A','user_type'=>'T']);
            if(@$request->search_u_name){
                $data['grade_tutors'] = $data['grade_tutors']->where(function($query) use($request) {
                    $query->Where('f_name','like','%'.$request->search_u_name.'%')
                    ->orWhere('l_name','like','%'.$request->search_u_name.'%')
                    ->orWhere(\DB::raw("CONCAT(`f_name`, ' ', `l_name`)"), 'like', '%' . $request->search_u_name. '%');
                });    
            }
            $data['grade_tutors'] = $data['grade_tutors']->whereHas('getTutorShipPlan',function($q) use($request,$subject,$gradeId){
                $q->where(['grade_id'=>$gradeId,'subject_id'=>$subject->id]);
            });    
            $data['grade_tutors'] = $data['grade_tutors']->select('id','f_name','l_name','user_type','slug','status')->orderBy('f_name','asc')->get();    
            $data['subject_id'] =@$subject->id; 

            // $data['grade_tutors'] = [];
            $data['grade_id'] =@$gradeId;
        }
        return response()->json($data,200);
    }
    /*
    * Method        : insertBookingToPaymentTable
    * Description   : This method is used to insert into payment table 
    * Author        : Jayatri
    */ 
    public function insertBookingToPaymentTable($bookingId){
        $payment = Payments::where(['booking_id'=>$bookingId])->first();
        $bookingInfo = StudentClassBooking::where(['id'=>$bookingId])->first();
        if(!@$payment && @$bookingInfo){
            
            $crPaymentData['booking_id'] = $bookingId;
            $crPaymentData['status'] = 'I';
            $crPaymentData['amount'] = $bookingInfo->booking_amount;
            $crPayment = Payments::create($crPaymentData);
        }
    }
    // this function is used to insert booking details into booking table
    /*
    * Method : bookAClass
    * Description : This function is used to insert booking details into booking table
    * Author    : Jayatri
    */
    public function bookAClass(Request $request){
        try
        {
            $admin_disable_bookings_values = AdminDisableBookings::first();
            $all_disabled_booking_dates = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();
            if(@$admin_disable_bookings_values->disable_booking == 'Y'){
                session()->flash("error","Choose available time slot");
                return redirect()->back();
            }
            // validation 
            $request->validate([
                'tutor_id'=>'required',
                'subject_id'=>'required',
                'selected_booked_date'=>'required',
                'from_time'=>'required',
                'to_time'=>'required'
            ]);
            // fetch date time day from request 
            $bookingDate = date("Y-m-d", strtotime($request->selected_booked_date));
            $from_time = date("H:i:s", strtotime($request->from_time));
            $to_time = date("H:i:s", strtotime($request->to_time));
            $day = date("D", strtotime($request->selected_booked_date));
            $tutor_id = $request->tutor_id;
            //get day value 
            if($day == "Mon"){
                $dValue = 1;
            }
            if($day == "Tue"){
                $dValue = 2;
            }
            if($day == "Wed"){
                $dValue = 3;
            }
            if($day == "Thu"){
                $dValue = 4;
            }
            if($day == "Fri"){
                $dValue = 5;
            }
            if($day == "Sat"){
                $dValue = 6;
            }
            if($day == "Sun"){
                $dValue = 7;
            }
            if(@$admin_disable_bookings_values->disable_booking == 'Y'){
                session()->flash("error","You cannot make bookings at this time. Please contact support");
                return redirect()->back();
            }elseif(in_array($bookingDate,$all_disabled_booking_dates)){
                session()->flash("error","This date is not available!Choose another date!This date is blocked!");
                return redirect()->back();
            }
            if($bookingDate < date('Y-m-d')){
                session()->flash("error","Choose available time slot!Tutor is not available!Today from time to time should be greater than current time!");
                return redirect()->back();
            }
            if($bookingDate == date('Y-m-d')){
                if($from_time <= date('H:i:s') || $to_time <= date('H:i:s')){        
                    session()->flash("error","Choose available time slot!Tutor is not available!Today from time to time should be greater than current time!");
                    return redirect()->back();
                }   
            }
            // check whether tutor is available or not 
            $starttime = $from_time;  // your start time
            $endtime = $to_time;  // End time
            $duration = '30';  // split by 30 mins

            $array_of_time = array ();
            $start_time    = strtotime ($starttime); //change to strtotime
            $end_time      = strtotime ($endtime); //change to strtotime

            $add_mins  = $duration * 60;
            while ($start_time <= $end_time) // loop between time
            {
               $array_of_time[] = date ("h:i:s", $start_time);
               $start_time += $add_mins; // to check endtie=me
            } 
            $length=count($array_of_time);
            $from_to_times=[];
            $get_all_from_times=[];
            $get_all_to_times=[];

            for($k=0;$k<$length;$k++){
                $data=[];
                if($k+1<$length){
                    $data['from_time']=$array_of_time[$k];
                    $data['to_time']=$array_of_time[$k+1];
                    $frmT = "'".$data['from_time']."'";
                    $toT = "'".$data['to_time']."'";
                    array_push($from_to_times,$data);
                    array_push($get_all_from_times,$frmT);
                    array_push($get_all_to_times,$toT);
                }
            }
            $timeSlotCount = count($from_to_times);
            // check available or not
            $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'B','date'=>$bookingDate])->where('start_time','>=',$from_time);
            
            $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                $query->whereBetween('end_time',[$from_time,$to_time]);
            });
            
            $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
            
            if($chkBDtFrmTimeToTime > 0){
                session()->flash("error","Choose available time slot!Tutor is not available!");
                    return redirect()->back();
            }

            $chkBDtFrmTimeToTime = StudentClassBooking::where(['student_id'=>@Auth::user()->id,'booking_date'=>$bookingDate])->whereIn('booking_status',['B'])->where('from_time','>=',$from_time);
            $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                $query->whereBetween('to_time',[$from_time,$to_time]);
            });
            $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
            
            if($chkBDtFrmTimeToTime > 0){
                session()->flash("error","You have already booked other tutor with same date and time!");
                    return redirect()->back();
            }
            // 
            // check available if
            $chkADtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$bookingDate])->where('start_time','>=',$from_time);
            
            $chkADtFrmTimeToTime = $chkADtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                $query->whereBetween('end_time',[$from_time,$to_time]);
            });
            
            $chkADtFrmTimeToTime = $chkADtFrmTimeToTime->count();
            
            if($chkADtFrmTimeToTime <= 0){
               session()->flash("error","Choose available time slot!Tutor is not available!");
                    return redirect()->back();
            }
            if($timeSlotCount == $chkADtFrmTimeToTime){
                
            }else{
                session()->flash("error","Choose available time slot!Tutor is not available!");
                    return redirect()->back();
            }
            
            
            $getTutorShipPlan = TutorshipPlan::where(['teacher_id'=>$request->tutor_id,'grade_id'=>@Auth::user()->grade,'subject_id'=>$request->subject_id,'status'=>'A'])->first();
            if(!@$getTutorShipPlan){
                session()->flash("error","Tutor's tutorship plan based on tutor,grade,subject is not found!");
                return redirect()->back();
            }
            // $getTutorShipPlan->hourly_rate will provide 30 min  changed on 25-10-2021  as per feedback point
            // reschedule duration should be same as per booking duration
                
            $currentDiff = (strtotime($to_time) - strtotime($from_time))/60;
            $com = Commissions::first();
            $tutorInfoDetails = User::where(['id'=>$request->tutor_id])->first();

            $createB['booking_no'] = 'V'.time();
            $createB['student_id'] = @Auth::user()->id;
            $createB['hourly_rate'] = $getTutorShipPlan->hourly_rate;
            $createB['tutor_id'] = $request->tutor_id;
            $createB['student_grade_id'] = @Auth::user()->grade;
            $createB['subject_id'] = $request->subject_id;
            $createB['from_time'] = $from_time;
            $createB['to_time'] = $to_time;
            $createB['booking_date'] = $bookingDate;
            $createB['booking_status'] = 'IC';
            $createB['payment_method'] = 'O';
            $createB['booking_amount'] = ($currentDiff * ($getTutorShipPlan->hourly_rate/30));
            // if(@$com){
            //     $createB['tutor_earnings'] = $createB['booking_amount'] - ($createB['booking_amount'] * ($com->commission)/100);    
            //     $createB['admin_percentage'] = $com->commission;    
            //     $createB['admin_commission'] = ($createB['booking_amount'] * ($com->commission)/100);    
            // }
            if(@$tutorInfoDetails){
                $createB['tutor_earnings'] = $createB['booking_amount'] - ($createB['booking_amount'] * ($tutorInfoDetails->commission_percentage)/100);    
                $createB['admin_percentage'] = $tutorInfoDetails->commission_percentage;    
                $createB['admin_commission'] = ($createB['booking_amount'] * ($tutorInfoDetails->commission_percentage)/100);    
            }
            
            $bookingInfo = StudentClassBooking::create($createB);
            $bookingNo = 'VT00000'.$bookingInfo->id;
            $t = StudentClassBooking::where(['id'=>$bookingInfo->id,'booking_no'=>$bookingNo])->first();
                if(@$t){
                    $a = StudentClassBooking::where(['id'=>$bookingInfo->id])->first();
                    $bookingNo = 'VT00000'.$a->id;
                    StudentClassBooking::where(['id'=>$bookingInfo->id])->update(['booking_no'=>$bookingNo]);    
                }else{
                    StudentClassBooking::where(['id'=>$bookingInfo->id])->update(['booking_no'=>$bookingNo]);        
                }
            
            
            $bookingInfo = StudentClassBooking::where(['id'=>$bookingInfo->id])->first();
            // $updBookinggetMyAvailability = Tutor_calander_availability::where(['tutor_id'=>$request->tutor_id,'day'=>$dValue,'date'=>$bookingDate])->where('start_time','>=',$from_time)->where('end_time','<=',$to_time);
            // $updBookinggetMyAvailability = $updBookinggetMyAvailability->update(['booking_status'=>'B']);
            // 2021 november
            // $updBookinggetMyAvailability = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$bookingDate])->where('start_time','>=',$from_time);
            
            // $updBookinggetMyAvailability = $updBookinggetMyAvailability->where(function($query) use($request,$from_time,$to_time) {
            //     $query->whereBetween('end_time',[$from_time,$to_time]);
            // });
            // $updBookinggetMyAvailability = $updBookinggetMyAvailability->update(['booking_status'=>'B']);
            // add to favourite
            $isInsFav = UserToFavourite::where(['favourite_user_id'=>$bookingInfo->tutor_id,'user_id'=>@Auth::user()->id])->first();
            if(!@$isInsFav){
                $addUserToFav['favourite_user_id'] = $bookingInfo->tutor_id; 
                $addUserToFav['user_id'] = @Auth::user()->id; 
                $fav = UserToFavourite::create($addUserToFav);
            }
            // $this->sendBookingMail($bookingInfo->booking_no);
            session()->flash("success"," Booking order ".$bookingInfo->booking_no." received. Complete booking within the next 15 minutes to confirm");

            // jayatri 10-11-2021 insert into payment table
            $this->insertBookingToPaymentTable($bookingInfo->id);
            $this->createMeeting($bookingInfo->id);
            return redirect()->route('payment.init', ['track' => encrypt($bookingInfo->id)]);
            //call the zoom link create function
            // $this->createMeeting($bookingInfo->id);
            // return redirect()->route('payment.init', ['track' => encrypt($bookingInfo->id)]);
            
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            session()->flash("error",$e->getMessage());
            return redirect()->back();            
        }
    }
    public function sendBookingMail($bookingNo){
        try{
            $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['booking_no'=>$bookingNo])->first();
            Mail::send(new StudentClassBookingMail($data));
        }catch(\Exception $e){

            \Log::error($e->getMessage());
        }
    }
    public function sendCancelBookingMail($bookingNo){
        try{
            $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['booking_no'=>$bookingNo])->first();
            Mail::send(new CancelBookingMail($data));
        }catch(\Exception $e){
            \Log::error($e->getMessage());
        }
    }
    public function ajaxDtTimeCheckingBookingSlot(Request $request){
        // try{

            // $grade_id = trim($request->data['grade_id']);
            $tutor_id = trim($request->data['tutor_id']);
            // $subject_id = trim($request->data['subject_id']);
            
            $bookingDate = date("Y-m-d", strtotime($request->data['get_booking_date']));
            $from_time = date("H:i:s", strtotime($request->data['from_time']));
            $to_time = date("H:i:s", strtotime($request->data['to_time']));
            $day = date("D", strtotime($request->data['get_booking_date']));

            // if(@$bookingDate == date('Y-m-d')){
            //     if($from_time <= date('H:i:s') || $to_time <= date('H:i:s')){
            //         return false;
            //     }   
            // }
            if($day == "Mon"){
                $dValue = 1;
            }
            if($day == "Tue"){
                $dValue = 2;
            }
            if($day == "Wed"){
                $dValue = 3;
            }
            if($day == "Thu"){
                $dValue = 4;
            }
            if($day == "Fri"){
                $dValue = 5;
            }
            if($day == "Sat"){
                $dValue = 6;
            }
            if($day == "Sun"){
                $dValue = 7;
            }

            // check tutor is available on that time or not  j conditions
            $check = MyAvailability::where('day',$dValue)->where('teacher_id',$tutor_id)->where('from_time','<',$from_time)->where('to_time','>',$from_time)->where('status','A')->first();
            $check1 = MyAvailability::where('day',$dValue)->where('teacher_id',$tutor_id)->where('from_time','<',$to_time)->where('from_time','>',$from_time)->where('to_time','<',$to_time)->where('status','A')->first();
            $check3 = MyAvailability::where('day',$dValue)->where('teacher_id',$tutor_id)->where('from_time','<',$to_time)->where('to_time','>',$to_time)->where('status','A')->first();
            $check4 = MyAvailability::where('day',$dValue)->where('teacher_id',$tutor_id)->where('from_time',$from_time)->first();
            if($check || $check1 || $check3 || $check4){
                
            }else{
                return "false";   
            }
            
            $isChecktoMyAvailability = Tutor_calander_availability::where(['tutor_id'=>@$request->tutor_id,'day'=>$dValue,'booking_status'=>'NB','date'=>$bookingDate])->where('end_time', '=', $to_time)->first();
            $isCheckfromMyAvailability = Tutor_calander_availability::where(['tutor_id'=>@$request->tutor_id,'day'=>$dValue,'booking_status'=>'NB','date'=>$bookingDate])->where('start_time','=',$from_time)->first();
            if(@$isChecktoMyAvailability && @$isCheckfromMyAvailability){

            }else{
                return "false";
            }
            if($bookingDate <= date('Y-m-d')){
                if($from_time <= date('H:i:s') || $to_time <= date('H:i:s')){
                    return "false";
                }   
            }
            $is_date_time_day_booked_bookings_tab = StudentClassBooking::where(['tutor_id'=>$request->tutor_id,'booking_date'=>$bookingDate,'booking_status'=>'B'])->where('from_time','>=',$from_time)->where('to_time','<=',$to_time);
            $is_date_time_day_booked_bookings_tab = $is_date_time_day_booked_bookings_tab->count();
            if($is_date_time_day_booked_bookings_tab > 0){
                return "false";
            }
            
            // $is_b_get_tutor_cal_availability = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'date'=>$bookingDate,'day'=>$dValue]);
            // $is_b_get_tutor_cal_availability = $is_b_get_tutor_cal_availability->where('start_time','>=',$from_time)->where('end_time','<=',$to_time);
            // $is_b_get_tutor_cal_availability = $is_b_get_tutor_cal_availability->where(['status'=>'A','booking_status'=>'B'])->count();

            //     if(@$is_b_get_tutor_cal_availability > 0){
            //         return 'false';
            //     }
            //     // is tutor available for the time slot based on booking date from time to time
                
            //     $is_date_time_day_booked_bookings_tab = StudentClassBooking::where(['tutor_id'=>$tutor_id,'booking_date'=>$bookingDate,'booking_status'=>'B'])->where('from_time','>=',$from_time)->where('to_time','<=',$to_time);
            //     $is_date_time_day_booked_bookings_tab = $is_date_time_day_booked_bookings_tab->count();
            //     if($is_date_time_day_booked_bookings_tab > 0){
            //         return 'false';
            //     }
            //     $getTutorShipPlan = TutorshipPlan::where(['teacher_id'=>$tutor_id,'grade_id'=>@Auth::user()->grade,'subject_id'=>$subject_id,'status'=>'A'])->first();
            //     if(!@$getTutorShipPlan){
            //         // dd("condition 4");
            //         return 'false';
                
            //     }else{
            //         return 'true';
            //     }
        // }catch(\Exception $e){
        //     dd($e->getMessage());
        //     \Log::error($e->getMessage());
        //     return 'false';
        // }
    }
    public function studentBookingConfirmation($bookingNo){
        $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['student_id'=>@Auth::user()->id,'booking_no'=>$bookingNo])->first();
        $data['admin_disable_bookings_values'] = AdminDisableBookings::first();
            $data['all_disabled_booking_dates'] = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();
        if(@$data['bookingDataInformation']){
            if(@Auth::user()->id == $data['bookingDataInformation']->student_id){
                if(@$data['bookingDataInformation']){
                    $data['t_my_av_show'] = MyAvailability::where(['teacher_id'=>$data['bookingDataInformation']->tutor_id,'status'=>'A'])->get();    
                }
                return view('student.modules.studentbook_class.student_bookingconfirmation')->with($data);    
            }else{
                session()->flash("error","You are trying to see the booking details which is not associated with your account!");
                return redirect()->back();
            }    
        }else{
            session()->flash("error","You are trying to see the booking details which is not associated with your account!");
            return redirect()->back();
        }
        
    }
    public function cancelBooking($bookingNo){
        
    } 
    public function studentCancelBooking($bookingNo){
        // $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['booking_no'=>$bookingNo])->first();
        // if(@Auth::user()->id == $data['bookingDataInformation']->student_id){
        //     if(@$data['bookingDataInformation']){
        //         $data['t_my_av_show'] = MyAvailability::where(['teacher_id'=>$data['bookingDataInformation']->tutor_id,'status'=>'A'])->get();    
        //     }
        //     return view('student.modules.studentbook_class.student_booking_cancelled')->with($data);    
        // }else{
        //     session()->flash("error","You are trying to see the booking details which is not associated with your account!");
        //     return redirect()->back();
        // }
        
    }



    //zoom link create function
     public function createMeeting($id){
        $client = new GuzzleHttp\Client(['base_uri' => 'https://api.zoom.us']);
        $token =TokenModel::where('id',1)->first();
        $accessToken = json_decode($token->access_token);
        // return $accessToken->access_token;

    try {
        $BookingDetails=StudentClassBooking::where('id',$id)->first();
        $startTime=$BookingDetails->booking_date."T".$BookingDetails->from_time."Z";
        //$startTime=date('Y-m-d')."T".date("H:i:s");
       // $newtimestamp = date(strtotime('H:i:s  + 2 minute'));
        //echo date('Y-m-d H:i:s', $newtimestamp);
         //$startTime=date('Y-m-d')."T".date('H:i:s', $newtimestamp);

        $response = $client->request('POST', '/v2/users/me/meetings', [
            "headers" => [
                "Authorization" => "Bearer $accessToken->access_token"
            ],
            'json' => [
                "topic" => "TEST Meeting",
                "type" => 2,
                "start_time" => $startTime,//"2021-07-09T20:30:00",
                "duration" => "30", // 30 mins
                "end_time"=> "2021-10-22T06:35:16Z",
                "password" => "123456",
                "settings" => [
                    "host_video"=>true,
                    "participant_video"=>true,
                    "join_before_host"=>false,
                    "mute_upon_entry"=>"true",
                    "watermark"=>"true",
                    "audio"=> "voip",
                    "auto_recording"=> "local"
                ]
            ],
        ]);

        $data = json_decode($response->getBody());
        //Update 3 columb of zoom related on booking table
        $up=array(
            'start_url'=>$data->start_url,
            'join_url'=>$data->join_url,
            'total_responce'=>$response->getBody(),
        );
       $a=StudentClassBooking::where('id',$id)->update($up);

        //return $response->getBody();

    } catch(\Exception $e) {
        if( 401 == $e->getCode() ) {
            $client = new GuzzleHttp\Client(['base_uri' => 'https://zoom.us']);
            $response = $client->request('POST', '/oauth/token', [
                "headers" => [
                    "Authorization" => "Basic ". base64_encode(env('CLIENT_ID').':'.env('CLIENT_SECRET'))
                ],
                'form_params' => [
                    "grant_type" => "refresh_token",
                    "refresh_token" => $accessToken->refresh_token
                ],
            ]);
            // $db->update_access_token($response->getBody());
            TokenModel::where('id',1)->update(['access_token'=>$response->getBody()]);

            $this->createMeeting($id);
        } else {
            echo $e->getMessage();
        }
    }
    }
}
