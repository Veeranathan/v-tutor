<?php

namespace App\Http\Controllers\Teacher\MyClass;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Models\TutorAcademic;
use App\Models\StudentClassBooking;

class MyclassController extends Controller
{
    public function my_class_list(Request $request){
            $data['classes']=StudentClassBooking::where('tutor_id',Auth()->user()->id)->orderBy('from_time','DESC')->where('booking_date',date('Y-m-d'))->whereIn('booking_status',['B','CM','C']);


       if(@$request->status){
       
           if($request->status){
            $data['classes']=$data['classes']->where('booking_status',$request->status); 
          }

        $data['res']=$request->all();
        }

      $data['classes']= $data['classes']->get();

            //dd($data['classes']);
     	// $t="12:30 PM";
     	// $a=explode( ':',$t);
     	// $b=explode( ' ',$t);
     	// dd((int)$a[0],$a,$b,$b[1]);
     	//dd($a);
     	// $all=User::orderBy('id')->get();
     	// foreach($all as $val){
     	// 	$f=$val->f_name;
     	// 	$l=$val->l_name;
     	// 	$u=User::where('id',$val->id)->update(['slug'=>str_slug($f." ".$l)]);
     	// }
 // $bsb = '062148';
 //  $data = @file_get_contents('http://api.beliefmedia.com/bsb/' . $bsb . '.json');
 //  // if ($data === false) return '429';
 //  $data = json_decode($data, true);
 //  return $data['data']['branchname'];
  //return ($data['code'] == '200') ? true : false;
  //$bsb = '062146';
//echo (beliefmedia_bsb($bsb) !== false) ? 'Exists' : 'Does not exist';
    	 return view('teacher.modules.my_class.myclass_list')->with($data);
    }














    public function my_class_upcomming_list(Request $request){
       $data['classes']=StudentClassBooking::where('tutor_id',Auth()->user()->id)->orderBy('from_time','DESC')->where('booking_date','>',date('Y-m-d'))->whereIn('booking_status',['B','CM','C']);

       if(@$request->from_date || @$request->to_date){
      // dd($request->all());
         @$from_date = date('Y-m-d', strtotime($request->from_date));
         @$to_prev= $request->to_date;
         @$to=date('Y-m-d', strtotime($to_prev/*. ' + 1 days'*/));
        // dd($request->all(),$from_date,$to);

        if($from_date && $to){
            $data['classes']=$data['classes']->whereBetween('booking_date',[$from_date, $to]); 
          }

           if($request->status){
            $data['classes']=$data['classes']->where('booking_status',$request->status); 
          }

        $data['res']=$request->all();
        }
         $data['classes']= $data['classes']->get();

        return view('teacher.modules.my_class.myclass_upcomming_list')->with($data);
    }













    public function my_class_past_list(Request $request){
        $data['classes']=StudentClassBooking::where('tutor_id',Auth()->user()->id)->orderBy('from_time','DESC')->where('booking_date','<',date('Y-m-d'))->whereIn('booking_status',['B','CM','C']);


       if(@$request->from_date || @$request->to_date){
      // dd($request->all());
         @$from_date = date('Y-m-d', strtotime($request->from_date));
         @$to_prev= $request->to_date;
         @$to=date('Y-m-d', strtotime($to_prev/*. ' + 1 days'*/));
        // dd($request->all(),$from_date,$to);

        if($from_date && $to){
            $data['classes']=$data['classes']->whereBetween('booking_date',[$from_date, $to]); 
          }

           if($request->status){
            $data['classes']=$data['classes']->where('booking_status',$request->status); 
          }

        $data['res']=$request->all();
        }

        $data['classes']= $data['classes']->get();
        return view('teacher.modules.my_class.myclass_past_list')->with($data);
    }












    public function tutorClassExport(Request $request){
     //dd($request->all());
    //echo url('/');
        $data['data'] = StudentClassBooking::where('tutor_id',Auth()->user()->id)->whereIn('booking_status',['B','CM','C']);

        //dd($data['data'] );



  //--------------------------Fetch all past value---------------------------------------
      if($request->session=="past"){
        $count=StudentClassBooking::where('tutor_id',Auth()->user()->id)->where('booking_date','<',date('Y-m-d') )->whereIn('booking_status',['B','CM','C'])->count();
        if($count<1){
          return back()->with('error','No data.');
        }
         $data['data']= $data['data']->where('booking_date','<',date('Y-m-d') );
         if(@$request->from_date || @$request->to_date){
              // dd($request->all());
             @$from_date = date('Y-m-d', strtotime($request->from_date));
             @$to_prev= $request->to_date;
             @$to=date('Y-m-d', strtotime($to_prev/*. ' + 1 days'*/));
            // dd($request->all(),$from_date,$to);
              if($from_date && $to){
                  $data['data']=$data['data']->whereBetween('booking_date',[$from_date, $to]); 
              }
          }

             if($request->status){
              $data['data']=$data['data']->where('booking_status',$request->status); 
            }
             $zyz=$data['data']->get();
            if(count($zyz)<1){
              return back()->with('error','No data.');
            }
      }   



       //--------------------------Fetch all future value---------------------------------------
      if($request->session=="future"){
         $count=StudentClassBooking::where('tutor_id',Auth()->user()->id)->where('booking_date','>',date('Y-m-d') )->whereIn('booking_status',['B','CM','C'])->count();
        if($count<1){
          return back()->with('error','No data.');
        }
         $data['data']= $data['data']->where('booking_date','>',date('Y-m-d') );
         if(@$request->from_date || @$request->to_date){
              // dd($request->all());
             @$from_date = date('Y-m-d', strtotime($request->from_date));
             @$to_prev= $request->to_date;
             @$to=date('Y-m-d', strtotime($to_prev/*. ' + 1 days'*/));
            // dd($request->all(),$from_date,$to);
              if($from_date && $to){
                  $data['data']=$data['data']->whereBetween('booking_date',[$from_date, $to]); 
              }
          }

             if($request->status){
              $data['data']=$data['data']->where('booking_status',$request->status); 
            }
            $zyz=$data['data']->get();
            if(count($zyz)<1){
              return back()->with('error','No data.');
            }
      }  

        //--------------------------Fetch all present value---------------------------------------
      if($request->session=="present"){
        $count=StudentClassBooking::where('tutor_id',Auth()->user()->id)->whereIn('booking_status',['B','CM','C'])->where('booking_date',date('Y-m-d') )->whereIn('booking_status',['B','CM','C'])->count();
        //dd($count);
        if($count<1){
          return back()->with('error','No data.');
        }
         $data['data']= $data['data']->where('booking_date',date('Y-m-d') );
    
             if($request->status){
              $data['data']=$data['data']->where('booking_status',$request->status); 
            }
             $zyz=$data['data']->get();
            if(count($zyz)<1){
              return back()->with('error','No data.');
            }
      }  


    $abc=  $data['data']->orderBy('id','desc')->with(['getStudent','getTutor','getSubject','getStudentGrade'])->get();
     //dd($abc);
    $data = '';
    
      $data .='<table>
      <tr>
      <th style="border:1px solid black;background-color
      :lime">Booking id</th>
      <th style="border:1px solid black;background-color
      :lime">Student name</th>
      <th style="border:1px solid black;background-color
      :lime">Tutor name</th>
      <th style="border:1px solid black;background-color
      :lime">Grade</th>
      <th style="border:1px solid black;background-color
      :lime">Subject</th>
      <th style="border:1px solid black;background-color
      :lime">From time</th>
      <th style="border:1px solid black;background-color
      :lime">To time</th>
      <th style="border:1px solid black;background-color
      :lime">Booking date</th>
      <th style="border:1px solid black;background-color
      :lime">Status</th>

      <th style="border:1px solid black;background-color
      :lime">Payment</th>
      <th style="border:1px solid black;background-color
      :lime">Zoom url</th>
      
      
   
      </tr>
      ';
      foreach (@$abc as $value) {
        // booking status 
        if ($value->booking_status=="B") {
          $status = "Booked";
        }elseif ($value->booking_status=="C") {
          $status = "Cancelled";
        }elseif($value->booking_status=="I"){
           $status = "In Progress";
        }
       
        else{
           $status = "Completed";
        }

         @$value->payment_method="Online";
        

        $data .= '
        <tr>
        <td style="border:1px solid black;">'.@$value->booking_no.'</td>
        <td style="border:1px solid black;">'.@$value->getStudent->f_name." ".@$value->getStudent->l_name.'</td>
        <td style="border:1px solid black;">'.@$value->getTutor->f_name." ".@$value->getTutor->l_name.'</td>
        <td style="border:1px solid black;">'.@$value->getStudentGrade->grade_name.'</td>
        <td style="border:1px solid black;">'.@$value->getSubject->subject.'</td>
        <td style="border:1px solid black;">'.@$value->from_time.'</td>
        <td style="border:1px solid black;">'.@$value->to_time.'</td>
        <td style="border:1px solid black;">'.@$value->booking_date.'</td>

        <td style="border:1px solid black;">'.@$status.'</td>
        <td style="border:1px solid black;">'.@$value->payment_method.'</td>
        <td style="border:1px solid black;">'.@$value->start_url.'</td>
       
        
        </tr>';
      }
      $data .= '</table>';
    
      //dd($data);
    header("Content-Type: application/xls");    
    header("Content-Disposition: attachment; filename=StudentClassRecord.xls");  
    header("Pragma: no-cache"); 
    header("Expires: 0");
   // dd($data); 
    echo $data;
    // return view('admin.modules.employers.manage_employers',$data);
    }





}
