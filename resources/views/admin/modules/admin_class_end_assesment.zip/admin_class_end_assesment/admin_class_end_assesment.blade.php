@extends('admin.layouts.app')
@section('title')
Bookings Management
@endsection
@section('links')
@include('admin.includes.links')
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css">
<style type="text/css">
    .dt-buttons{
        display: none;
    }
</style>
@endsection
@section('header')
@include('admin.includes.header')
@endsection
@section('sidebar')
@include('admin.includes.sidebar')
@endsection
@section('content')
<div class="content">
    <div class="container">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12 col-xs-12">
            {{-- <div class="col-sm-12"> --}}
                <h1 class="pull-left page-title">Bookings Management</h1>
                <ol class="breadcrumb pull-right">
                    {{-- <li> <a href="{{ route('add.grade') }}"><i class="far fa-plus-square" aria-hidden="true"></i> Add Grade</a></li> --}}
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading rm02 rm04">
                        <form action="{{ route('booking.management.list.tab') }}" method="get">
                            <div data-column="1" class="form-group">
                                <label for="col1_filter">Search Booking No</label>
                                <input type="text" placeholder=" " id="col1_filter" name="booking_search" class="form-control reset_val" value="" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                            </div>
                            
                            {{-- <div data-column="3" class="form-group">
                                <div class="dash-d1">
                                    <label for="col3_filter">Search From Date(Posted On)</label>
                                    <div class="ui calendar calendardatepicker" id="from_date">
                                        <div class="ui input left icon">
                                          <input type="text" id="col3_filter" name="col3_filter" placeholder="" class="form-control reset_val" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                                          <span class="over_llp1"><img src="{{ asset('public/admin/assets/images/cal.png') }}" alt=""></span>
                                          <span class="error_from_date error"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div data-column="4" class="form-group">
                                <div class="dash-d1">
                                    <label for="col4_filter">Search To Date (Posted On)</label>
                                    <div class="ui calendar calendardatepicker" id="to_date">
                                        <div class="ui input left icon">
                                          <input type="text" id="col4_filter" name="col4_filter" placeholder="" class="form-control reset_val" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                                          <span class="over_llp1"><img src="{{ asset('public/admin/assets/images/cal.png') }}" alt=""></span>
                                          <span class="error_to_date error"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div data-column="7" class="form-group">
                                <label for="col7_filter">Posted By</label>
                                <select id="col7_filter" name="col7_filter" class="form-control reset_val">
                                    <option value="">Select Posted By</option>
                                    @if(@$users)
                                    @foreach(@$users as $s)
                                    <option value="{{ @$s->id }}">{{ @$s->f_name.' '.@$s->l_name }}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div> --}}
                            
                            
                            <div class="rm05">
                                <button class="btn btn-primary waves-effect waves-light w-md search_click" type="button">Search</button>
                            </div>
                            <div class="rm05">
                                <button class="btn btn-primary waves-effect waves-light w-md reset_search" type="button">Reset </button>
                            </div>
                            <div class="rm05 rightButtons">
                                <button class="btn btn-primary waves-effect waves-light w-md download" id="download" type="submit">Download </button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                    <div class="panel-body">
                        @include('admin.includes.message')
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="table-responsive">
                                    {{-- <div class="table-res"> --}}
                                    <table class="table table-bordered table-striped" id="example">
                                        <thead>
                                            <tr>
                                                <th class="rm07">Booking No</th>
                                                <th class="rm07">Student/Tutor</th>
                                                <th class="rm07">Posted By</th>
                                                <th class="rm07">Date</th>
                                                <th class="rm07">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                  {{-- </div> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End row --> 
    </div>
    <!-- container --> 
</div>
@endsection    
@section('footer')
@include('admin.includes.footer')
@endsection
@section('script')
@include('admin.includes.script')
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $(".buttons-excel").hide();
        function filterColumn ( i ) {
            $('#example').DataTable().column( i ).search(
                $('#col'+i+'_filter').val(),
            ).draw();
        }
        
        var dataTableObj = {
            dom: "<div class='table-res'></div>"+'p'+'B',
            stateSave: false,
            "order": [
                [4, "desc"]
            ],
            "stateLoadParams": function (settings, data) {
                // $('#col1_filter').val(data.search.grade_name);  
            },
            stateSaveParams: function (settings, data) { 
                // data.search.grade_name = $('#col1_filter').val();
            },

            "processing": true,
            "serverSide": true,
            'serverMethod': 'post',
            "createdRow": function( row, data, dataIndex ) { 
                var id = (JSON.stringify(data.id)),
                r = JSON.stringify(dataIndex);
                // // $(row).
                $(row).addClass("tr_class_"+id);
                $(row).addClass("tr_row_class");
                $(row).children(':nth-child(1)').addClass('rm07');
                $(row).children(':nth-child(2)').addClass('rm07');
                $(row).children(':nth-child(3)').addClass('rm07');
                $(row).children(':nth-child(4)').addClass('rm07');
                $(row).children(':nth-child(5)').addClass('rm07');
                // $(row).children(':nth-child(6)').addClass('rm07');
                // $(row).children(':nth-child(7)').addClass('rm07');
                // $(row).children(':nth-child(8)').addClass('rm07');
                // $(row).children(':nth-child(9)').addClass('rm07');
                // $(row).children(':nth-child(10)').addClass('rm07');
                
                $(row).children(':nth-child(0)').attr('data-id',r);
                $(row).children(':nth-child(4)').attr('data-id',r);
            },
            "ajax": {
                "url": "{{ route('admin.class.end.assesment.management') }}",
                "data": function ( d ) {
                    console.log(d);
                    d.myKey = "myValue";
                    d._token = "{{ @csrf_token() }}";
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Do something here
                    console.log("'error in datatable");
                }
            },
            'columns': [
            { 
                data: "id",
                render: function(data, type, full, meta){    
                    return full.booking_info.booking_no;
                }
            },
            
            { 
                data: "user_id",
                render: function(data, type, full, meta){ 
                    if(full.get_user.user_type == 'T'){
                        return 'Tutor';
                    }else{
                        return 'Student';
                    }
                }
            },
            { 
                data: "user_id",
                render: function(data, type, full, meta){ 
                    return full.get_user.f_name+" "+full.get_user.l_name;
                }
            },
            { 
                data: "created_at",
                render: function(data, type, full, meta){    
                    var date = new Date(full.created_at);
                        var day = date.getDate();
                        var month = date.getMonth(); 
                        var year = date.getFullYear();
                        var created_at = year+'-'+("0" + (month+ 1)).slice(-2)+'-'+("0" + day).slice(-2);
                        return created_at;
                }
            },
            { 
                data: "id",
                render: function(data, type, full, meta){ 
                // console.log("print : "+JSON.stringify(meta)); 
                    var a='';
                    
                    a+= '<a href="javascript:void(0);" class="action-dots action" data-key="'+full.id+'" id="action'+full.id+'"><img src="{{ asset('public/admin/assets/images/action-dots.png') }}" alt=""></a>\n\
                        <div class="show-actions" id="show-action'+full.id+'" style="display: none;">\n\
                            <span class="angle"><img src="{{ asset('public/admin/assets/images/angle.png') }}" alt=""></span>\n\
                            <ul>';
                    a+='<li><a href="{{ url('admin/view-class-end-assesment').'/' }}'+full.id+'">View Details</a></li>';
                    
                    
                    a+='</ul>\n\
                  </div>';
                    return a;
                }
            },
            ]
            // ,
            // columnDefs: [
            //     {
            //         render: function (data, type, full, meta) {
            //             return "<div class='text-wrap width-200'>" + data + "</div>";
            //         },
            //         targets: 3
            //     }
            //  ]
        };
        var table = dataTableCall(dataTableObj,"example");
        // var info = table.page.info();
        // alert(JSON.stringify(info));
        $("#example_filter").hide();
        $("#example_wrapper div").eq(0).addClass("table-res");
        $(document).on("click",".action",function(e){
            var id = $(this).data("key");
            $("#show-action"+id).slideToggle();

        });
        // $('#col5_filter').on( ' change', function () {
        //     filterColumn( $(this).parents('div').data('column') );
        // });
        // $('#col6_filter').on( 'change', function () {
        //     filterColumn( $(this).parents('div').data('column') );
        // });
        $('body').on('click','.reset_search', function() {
            $(".reset_val").val("");
            $('#example').DataTable().search('').columns().search('').draw();
        });
        $('body').on('click','.search_click', function() {
            filterColumn( 1 );
            filterColumn( 2 );
            filterColumn( 3 );
            filterColumn( 4 );
            filterColumn( 5 );
            filterColumn( 6 );
            filterColumn( 7 );
            filterColumn( 8 );
            filterColumn( 9 );
            filterColumn( 10 );
        });
        $('#example tbody').on( 'click', 'tr', function () {
            
        });
        $(document).on("click",".cancel_booking",function(e){
            var id = $(e.currentTarget).data("id"),
            obj = $(this),
            reqData = {
                'jsonrpc' : '2.0',                
                '_token'  : '{{csrf_token()}}',
                'data'    : {
                    'id'    : id
                }
            },
            temp = table.row('.tr_class_'+id).data();
            
            $("#data_table_data_s").val(table);
            $("#ajax_data_id").val(id);
            var tName = "Do you want to cancel "+temp.booking_no+" ? ";
            var ajax_url = "{{ route('ajax.cancel.booking') }}";
            var targetId = $(this).attr("id");
            $("#tId").val(targetId);
            $("#type_popup_next").val("A");
            $("#ajax_url").val(ajax_url);
            $("#tName").val(tName);
            isAuthorizedByAdmin(tName,targetId,id);
        });
        // $("#download").click(function(){
        //     // table = table.page.len( 25 ).draw();
        //     $(".buttons-excel").trigger("click");

        // });
        $(".calendardatepicker").calendar({
            type: 'date',
            formatter: {
                date: function (date, settings) {
                    if (!date) return '';
                    var day = date.getDate() + '';
                    if (day.length < 2) {
                        day = '0' + day;
                    }
                    var month = (date.getMonth() + 1) + '';
                    if (month.length < 2) {
                        month = '0' + month;
                    }
                    var year = date.getFullYear();
                    var date_value = year + '-' + month + '-' + day;
                    
                    return date_value;
                }
            }
        });
        
        $("#example_info").remove();
        $("#example_length").remove();
        // var getHtml = $("#example").html();
        // var appendHtml = '<div class="table-res">'+getHtml+'</div>';
        
        // $(".example_wrapper").append(appendHtml);
    });    
</script>
@endsection