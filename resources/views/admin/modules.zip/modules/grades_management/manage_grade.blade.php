@extends('admin.layouts.app')
@section('title')
Grades Management
@endsection
@section('links')
@include('admin.includes.links')

{{-- <script src="{{ asset('public/admin/assets/js/modernizr.min.js') }}"></script> --}}
{{-- <link href="{{ asset('public/admin/assets/toastr/build/toastr.min.css') }}" rel="stylesheet">  --}}
{{-- <link href="{{ asset('public/admin/assets/css/jquery.dataTables.min.css') }}" rel="stylesheet" type="text/css">     --}}
{{-- <link href="{{ asset('public/admin/assets/css/jquery.dataTables.css') }}" rel="stylesheet" type="text/css">     --}}
{{-- <link href="{{ asset('public/admin/assets/css/jquery-ui.css') }}" rel="stylesheet" type="text/css">     --}}
{{-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css"> --}}
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">



<style type="text/css">
    .dataTables_wrapper .dataTables_paginate .paginate_button.current, .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
    color:#fff !important;
    border: 1px solid #bd201b !important;
    background: #bd201b !important;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.current, .dataTables_wrapper .dataTables_paginate .paginate_button.current {
    color:#fff !important;
    border: 1px solid #bd201b !important;
    background: #bd201b !important;
}
.selected{
    background-color: red;
}
.buttons-excel{
    display: none;
}
</style>
@endsection
@section('header')
@include('admin.includes.header')
@endsection
@section('sidebar')
@include('admin.includes.sidebar')
@endsection
@section('content')
<div class="content">
    <div class="container">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12 col-xs-12">
            {{-- <div class="col-sm-12"> --}}
                <h1 class="pull-left page-title">Grades Management</h1>
                <ol class="breadcrumb pull-right">
                    <li> <a href="{{ route('add.grade') }}"><i class="far fa-plus-square" aria-hidden="true"></i> Add Grade</a></li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading rm02 rm04">
                        {{-- <form role="form" id="searchSubject" method="get" action="{{ route('manage.grades') }}"> --}}
                            <div data-column="1" class="form-group">
                                <label for="col1_filter">Search Grade Name / Code</label>
                                <input type="text" placeholder="Grade xx" id="col1_filter" name="grade_name" class="form-control reset_val" value="" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                            </div>
                            {{-- <div class="clearfix"></div> --}}
                            <div class="rm05">
                                <button class="btn btn-primary waves-effect waves-light w-md search_click" type="submit">Search</button>
                            </div>
                            <div class="rm05">
                                <button class="btn btn-primary waves-effect waves-light w-md reset_search" type="submit">Reset </button>
                            </div>
                            <div class="rm05 rightButtons">
                                <button class="btn btn-primary waves-effect waves-light w-md download" id="download" type="submit">Download </button>
                            </div>
                            <div class="clearfix"></div>
                        {{-- </form> --}}
                    </div>
                    <div class="panel-body">
                        @include('admin.includes.message')
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped" id="example">
                                        <thead>
                                            <tr>
                                                <th class="rm07">Grade</th>
                                                <th class="rm07">Grade Code</th>
                                                <th class="rm07">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                               
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End row --> 
    </div>
    <!-- container --> 
</div>
@endsection    
@section('footer')
@include('admin.includes.footer')
@endsection
@section('script')
@include('admin.includes.script')
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $(".buttons-excel").hide();
        function filterColumn ( i ) {
            $('#example').DataTable().column( i ).search(
                $('#col'+i+'_filter').val(),
            ).draw();
        }
        
        var dataTableObj = {
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'excelHtml5',
                    exportOptions: {
                        columns: [ 0, 1 ]
                    }
                },
                'colvis'
            ],
        // buttons: [
        //     'copy', 'csv', 'excel', 'pdf', 'print'
        // ],
            stateSave: false,
            // "pageLength":2,
            "order": [
                [2, "desc"]
            ],
            "stateLoadParams": function (settings, data) {
                // $('#col1_filter').val(data.search.grade_name);  
            },
            stateSaveParams: function (settings, data) { 
                // data.search.grade_name = $('#col1_filter').val();
            },
            "processing": true,
            "serverSide": true,
            'serverMethod': 'post',
            "createdRow": function( row, data, dataIndex ) { 
                var id = (JSON.stringify(data.id)),
                r = JSON.stringify(dataIndex);
                $(row).addClass("tr_class_"+id);
                $(row).addClass("tr_row_class");
                $(row).children(':nth-child(1)').addClass('rm07');
                $(row).children(':nth-child(2)').addClass('rm07');
                $(row).children(':nth-child(3)').addClass('rm07');
                $(row).children(':nth-child(3)').attr('data-id',r);
            },
            "ajax": {
                "url": "{{ route('grade.management') }}",
                "data": function ( d ) {
                    console.log(d);
                    d.myKey = "myValue";
                    d._token = "{{ @csrf_token() }}";
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Do something here
                    console.log("'error in datatable");
                }
            },
            'columns': [
            { 
                data: "grade_name",
                render: function(data, type, full, meta){    
                    return data;
                }
            },
            { 
                data: "capture_code",
                render: function(data, type, full, meta){    
                    return data;
                }
            },
            { 
                data: "id",
                render: function(data, type, full, meta){ 
                // console.log("print : "+JSON.stringify(meta)); 
                    var a='';
                    // a += '<a href="javascript:void(0);" title="View" class="gtest"><i class="fas fa-ellipsis-v"></i></a>';
                    a+= '<a href="javascript:void(0);" class="action-dots action" data-key="'+full.id+'" id="action'+full.id+'"><img src="{{ asset('public/admin/assets/images/action-dots.png') }}" alt=""></a>\n\
                        <div class="show-actions" id="show-action'+full.id+'" style="display: none;">\n\
                            <span class="angle"><img src="{{ asset('public/admin/assets/images/angle.png') }}" alt=""></span>\n\
                            <ul>\n\
                                <li><a href="{{ url('admin/edit-grade').'/' }}'+full.id+'">Edit</a></li>\n\
                                <li><a id="delete_grade_'+full.id+'" class="delete_grade" data-id="'+full.id+'" href="javascript:void(0);">Delete</a></li>\n\
                            </ul>\n\
                          </div>';
                    return a;
                }
            },
            ]
        };
        var table = dataTableCall(dataTableObj,"example");
        // var info = table.page.info();
        // alert(JSON.stringify(info));
        $("#example_filter").hide();
        $(document).on("click",".action",function(e){
            var id = $(this).data("key");
            $("#show-action"+id).slideToggle();
        });
        // $('#col1_filter').on( 'keyup click', function () {
        //     filterColumn( $(this).parents('div').data('column') );
        // });
        $('body').on('click','.reset_search', function() {
            $(".reset_val").val("");
            $('#example').DataTable().search('').columns().search('').draw();
        });
        $('body').on('click','.search_click', function() {
            filterColumn( 1 );
            
        });
        $('#example tbody').on( 'click', 'tr', function () {
            
        });
        $(document).on("click",".delete_grade",function(e){
            var id = $(e.currentTarget).attr("data-id"),
            obj = $(this),
            reqData = {
                'jsonrpc' : '2.0',                
                '_token'  : '{{csrf_token()}}',
                'data'    : {
                'id'      : id
                }
            },
            temp = table.row('.tr_class_'+id).data();
            var targetId = $(this).attr("id");
            $("#tId").val(targetId);
            $("#type_popup_next").val("A");
            // var tName = "Do you want to delete "+temp.f_name+" "+temp.l_name+" student ?";
            $("#ajax_url").val("{{ route('ajax.delete.grade') }}");
            $('#instructionModal').modal('show');
            var tName = "Do you want to delete "+temp.grade_name+" grade?";
            $("#tName").val(tName);
            $("#data_table_data_s").val(table);
            $("#ajax_data_id").val(id);
            
        });
        $("#download").click(function(){
            $(".buttons-excel").trigger("click");
        });
    });    
</script>
@endsection