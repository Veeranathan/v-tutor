@section('head')
@include('include.head')
@endsection
<header class="header_sec">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light nav_top">
            <a class="navbar-brand" href="{{ url('/') }}"><img src="{{url('/')}}/public/assets/images/logo.png" alt="logo" /></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                <!-- <ul class="mr-auto">
                </ul> -->
                <ul class="navbar-nav menu_sec after-login">
                    
                    <li class="dropdown"> <a href="tutor-search-result.html" class="dropdown-toggle drop-arw" >Find my V-Tutor </a>
                    <!---<span class="dropdown-toggle drop-arw" data-toggle="dropdown">
                        <i class="fas fa-angle-down"></i>
                    </span>
                    <ul class="dropdown-menu">
                        <li><a href="#url">Tutors for Grade 1</a></li>
                        <li><a href="#url">Tutors for Grade 2</a></li>
                        <li><a href="#url">Tutors for Grade 3</a></li>
                    </ul> ---></li>
                    <li class="dropdown"> <a href="#" class="dropdown-toggle drop-arw" data-toggle="dropdown">Support</a><span class="dropdown-toggle drop-arw" data-toggle="dropdown">
                    <i class="fas fa-angle-down"></i>
                </span>
                <ul class="dropdown-menu">
                    <li><a href="faq.html">FAQ’s</a></li>
                    <li><a href="contact-us.html">Message us</a></li>
                </ul>
            </li>
        </ul>
    </div>
    <div class="login_menu after_log">
        <ul class="click_open">
            <li>
                <a href="#">  <em>
                    @if(Auth::user()->profile_pic)
                    {{-- {{url('/')}}/storage/app/public/student_profile_pic/{{@Auth::user()->profile_pic}} --}}
                    <img src="{{url('/')}}/public/assets/images/user-pro.png" alt="profile_img" style="width: 100%">
                    @elseif(!@Auth::user()->profile_pic && @Auth::user()->avatar)
                    <img src="{{-- {{url('/')}}/public/assets/images/user-pro.png --}}{{@Auth::user()->avatar}}" alt="profile_img" style="width: 100%">
                    @else
                    <img src="{{url('/')}}/public/assets/images/user-pro.png" alt="profile_img" style="width: 100%">
                    @endif
                    </em> <span>Hi, {{@Auth::user()->f_name}} <i class="fas fa-angle-down" aria-hidden="true"></i></span> </a>
                </li>
            </ul>
            <div class="open_menu" style="display: none;">
                <ul>
                    <li  class="acv">
                        <a href="{{ url('home') }}"> Dashboard</a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">Book a Class</a>
                    </li>
                    <li>
                        <a href="{{ url('my-profile') }}"> My Profile</a>
                    </li>
                    <li>
                        <a href="javascript:void(0);"> My Classes</a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">My Tutors</a>
                    </li>
                    <li>
                        <a href="javascript:void(0);">My Reviews</a>
                    </li>
                    
                    <li>
                        <a href="javascript:void(0);"> My Payments </a>
                    </li>
                     @if(!@Auth()->user()->platform_id)
                    <li>

                        <a href="{{route('student.reset.password.view')}}">Change Password</a>
                    </li>
                    @endif                    <li>
                         <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();"> <span></span> Logout</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                        
                                    </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>
</header>