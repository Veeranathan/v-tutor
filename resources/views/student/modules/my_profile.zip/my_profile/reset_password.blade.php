@extends('layouts.app')
@section('title')
<title>V-tutor | User | Home</title>
@endsection
@section('left_part')
@include('include.student_top_common')
@endsection
@section('content')
<!-- bannersec -->
<!-- bannersec -->
   <div class="top_mar"></div>
    <!--- profile --->
     <section class="user-account">
        <div class="container">
            <div class="row">
                <div class="zin">
                         @include('include.student_left_common'){{-- left common part --}}

                    <div class="user-right-panel tutor-right">

                        

                        <div class="turo-edit">

                        <div class="user-right-top">
                            <h2 class="profile-heading"> Reset Password <span><img src="{{url('/')}}/public/assets/images/pencil.png"></span></h2>
                            <p>You can change your password in this section</p>
                            <br>
                            @include('include.errors')

                            <form id="frm" method="post" action="{{route('student.update.password')}}">
                              @csrf
                               <div class="user-account-info">
                                    
                                    <div class="row new_rows no-gutters">
                                        <div class="col-md-5 col-sm-6">
                                            <div class="form_box_area">
                                                <label>Current Password</label>
                                                <input type="password" placeholder="Enter your current password "  name="old_password" > </div>
                                        </div>
                                    </div>
                                    <div class="row new_rows no-gutters">
                                        <div class="col-md-5 col-sm-6">
                                            <div class="form_box_area">
                                                <label>New Password</label>
                                                <input id="new_password" type="password" placeholder="Enter your new password" name="newPassword" > 
                                                <span class="new_password-error error"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row new_rows no-gutters">
                                        <div class="col-md-5 col-sm-6">
                                            <div class="form_box_area">
                                                <label>Re-enter New Password</label>
                                                <input id="confirm_password" type="password" placeholder="Confirm your new password" name="confirm"> 
                                                <span class="confirm_password-error error"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row new_rows no-gutters">
                                        <div class="col-md-12 col-sm-12 mt-5">
                                            <hr class="das-hr">
                                            <div class="footdashSec">
                                                <input type="submit" name="" value="Reset Password" class="sub_btn2 text-center">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>

                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 
@endsection
@section('footer')
@include('include.footer')
@endsection
@section('script')
@include('include.script')


 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script> 
       <script>
            $(document).ready(function(){
                $('#frm').validate({

                    rules:{
                        old_password:{
                            required:true,
                            minlength:6,                           
                        },
                        newPassword:{
                            required:true,
                            minlength:8,                           
                        },
                        confirm:{
                            required:true,
                            minlength:8,
                            equalTo : '[name="newPassword"]'                           
                        },

                    },
                    messages:{
                         old_password:{
                            required:" Old password is mandatory",
                            min:"Enter minimum 8 characters"
                        },
                        newPassword:{
                            required:" New password is mandatory",
                            min:"Enter minimum 8 characters"
                        },
                        confirm:{
                            required:" Confirm password is mandatory",
                            min:"Enter minimum 8 characters",
                            equalTo :"Passwords do not match"
                        },
                    },
                    submitHandler:function(form){
                        var password = $("#new_password").val();
                        var conf_password = $("#confirm_password").val();
                        if(password != ""){
                            var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[A-Z])(?=.*[@#$%&?!*]).*$/;
                            if(pattern.test(password)){
                                $('.new_password-error').html(''); 
                                form.submit();    
                            }else{
                                $('.new_password-error').html('Password to have minimum of 8 characters, with at least 1 capital letter, 1 number and 1 special character from these (@ # $ % & ? ! * )');
                                $('.new_password-error').css('display','block');
                                $("#new_password").val('');
                                return false;
                            }    
                        }
                        if(conf_password != ""){
                            var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[A-Z])(?=.*[@#$%&?!*]).*$/;
                            if(pattern.test(conf_password)){
                                $('.confirm_password-error').html(''); 
                                form.submit();    
                            }else{
                                $('.confirm_password-error').html('Password to have minimum of 8 characters, with at least 1 capital letter, 1 number and 1 special character from these (@ # $ % & ? ! * )');
                                $('.confirm_password-error').css('display','block');
                                $("#confirm_password").val('');
                                return false;
                            }    
                        }
                        
                        
                    }
                });
                $(document).on("blur","#new_password",function(){
                    var password = $("#new_password").val();
                    var conf_password = $("#confirm_password").val();
                    if(password != ""){
                            var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[A-Z])(?=.*[@#$%&?!*]).*$/;
                            if(pattern.test(password)){
                                $('.new_password-error').html(''); 
                                form.submit();    
                            }else{
                                $('.new_password-error').html('Password to have minimum of 8 characters, with at least 1 capital letter, 1 number and 1 special character from these (@ # $ % & ? ! * )');
                                $('.new_password-error').css('display','block');
                                $("#new_password").val('');
                                return false;
                            }    
                        }
                        if(conf_password != ""){
                            var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[A-Z])(?=.*[@#$%&?!*]).*$/;
                            if(pattern.test(conf_password)){
                                $('.confirm_password-error').html(''); 
                                form.submit();    
                            }else{
                                $('.confirm_password-error').html('Password to have minimum of 8 characters, with at least 1 capital letter, 1 number and 1 special character from these (@ # $ % & ? ! * )');
                                $('.confirm_password-error').css('display','block');
                                $("#confirm_password").val('');
                                return false;
                            }    
                        }
                        
                });
                $(document).on("blur","#confirm_password",function(){
                    var password = $("#new_password").val();
                    var conf_password = $("#confirm_password").val();
                    if(password != ""){
                        var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[A-Z])(?=.*[@#$%&?!*]).*$/;
                        if(pattern.test(password)){
                            $('.new_password-error').html(''); 
                            
                        }else{
                            $('.new_password-error').html('Password to have minimum of 8 characters, with at least 1 capital letter, 1 number and 1 special character from these (@ # $ % & ? ! * )');
                            $('.new_password-error').css('display','block');
                            $("#new_password").val('');
                            
                        }    
                    }
                    if(conf_password != ""){
                        var pattern = /^.*(?=.{8,})(?=.*\d)(?=.*[A-Z])(?=.*[@#$%&?!*]).*$/;
                        if(pattern.test(conf_password)){
                            $('.confirm_password-error').html(''); 
                            
                        }else{
                            $('.confirm_password-error').html('Password to have minimum of 8 characters, with at least 1 capital letter, 1 number and 1 special character from these (@ # $ % & ? ! * )');
                            $('.confirm_password-error').css('display','block');
                            $("#confirm_password").val('');
                            
                        }    
                    }
                });

            });
        </script>


@endsection