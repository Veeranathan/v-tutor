<?php

namespace App\Http\Controllers\Admin\Modules\BookingsManagement;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\StudentClassBooking;
use App\Models\Tutor_calander_availability;
use App\Models\Grade;
use App\Models\Subject;
use App\Models\Payments;
use App\User;
use Mail;
use App\Mail\CancelBookingMail;
#stripe
use Stripe\Stripe;
use Illuminate\Support\Carbon;

class BookingsManagementController extends Controller
{   
    
    public function bookingManagement(Request $request){
        $columnIndex = $request->order[0]['column'];
        $columnSortOrder = $request->order[0]['dir'];
        $bookings = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->whereIn('booking_status',['B','C','CM']);
        if(@$request->columns['1']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->where('booking_no','like','%'.$request->columns['1']['search']['value'].'%');
            });
        }
        if(@$request->columns['2']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('booking_status',$request->columns['2']['search']['value']);
            });
        }
        if(@$request->columns['7']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('student_id',$request->columns['7']['search']['value']);
            });
        }
        if(@$request->columns['8']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('tutor_id',$request->columns['8']['search']['value']);
            });
        }
        if(@$request->columns['9']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('student_grade_id',$request->columns['9']['search']['value']);
            });
        }
        if(@$request->columns['10']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('subject_id',$request->columns['10']['search']['value']);
            });
        }
        if(@$request->columns['3']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->whereBetween('created_at',[@$request->columns['3']['search']['value']." 00:00:00", @$request->columns['4']['search']['value']." 23:59:59"]);
            });
        }
        if(@$request->columns['4']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->whereBetween('created_at',[@$request->columns['3']['search']['value']." 00:00:00", @$request->columns['4']['search']['value']." 23:59:59"]);
            });
        }
        if(@$request->columns['5']['search']['value'] && @$request->columns['6']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->whereBetween('booking_date',[@$request->columns['5']['search']['value'], @$request->columns['6']['search']['value']]);
            });
        }
        
        $ps =  $bookings->count();
        $pp = $bookings;
        $pp = $pp->count();
        $limit = $request->length;
        $p = $bookings = $bookings;
        $p =  $p->count();
        if($columnIndex == 0) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('booking_no','asc');
            } else {
                $bookings = $bookings->orderBy('booking_no','desc');
            }
        }
        if($columnIndex == 1) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('tutor_id','asc');
            } else {
                $bookings = $bookings->orderBy('tutor_id','desc');
            }
        }
        if($columnIndex == 2) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('student_id','asc');
            } else {
                $bookings = $bookings->orderBy('student_id','desc');
            }
        }
        if($columnIndex ==3) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('subject_id','asc');
            } else {
                $bookings = $bookings->orderBy('subject_id','desc');
            }
        }
        if($columnIndex == 4) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('student_grade_id','asc');
            } else {
                $bookings = $bookings->orderBy('student_grade_id','desc');
            }
        }
        if($columnIndex == 5) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('booking_amount','asc');
            } else {
                $bookings = $bookings->orderBy('booking_amount','desc');
            }
        }
        if($columnIndex == 6) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('booking_date','asc');
            } else {
                $bookings = $bookings->orderBy('booking_date','desc');
            }
        }
        if($columnIndex == 7) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('booking_status','asc');
            } else {
                $bookings = $bookings->orderBy('booking_status','desc');
            }
        }
        if($columnIndex == 8) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('created_at','asc');
            } else {
                $bookings = $bookings->orderBy('created_at','desc');
            }
        }
        if($columnIndex == 9) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('id','asc');
            } else {
                $bookings = $bookings->orderBy('id','desc');
            }
        }
        // if($columnIndex == 10) {
        //     if($columnSortOrder == 'asc') {
        //         $bookings = $bookings->orderBy('id','asc');
        //     } else {
        //         $bookings = $bookings->orderBy('id','desc');
        //     }
        // }
        // if($columnIndex == 11) {
        //     if($columnSortOrder == 'asc') {
        //         $bookings = $bookings->orderBy('id','asc');
        //     } else {
        //         $bookings = $bookings->orderBy('id','desc');
        //     }
        // }
        $bookings = $bookings->orderBy('id','desc')->skip($request->start)->take($request->length)->get();
        $data['aaData'] = $bookings;
        $data["draw"] = intval($request->draw);
        $data['iTotalRecords'] = $ps;
        $data["iTotalDisplayRecords"] = $pp;
        return response()->json($data);
    }
    /*
    * Method        : index
    * Description   : This method is used to manage grades!
    * Author        : Jayatri
    */ 
    public function index(Request $request){
        try{
            $data['users'] = User::whereIn('status',['A','I','U'])->where(['user_type'=>'U'])->select('id','status','f_name','l_name')->get();
            $data['tutors'] = User::whereIn('status',['A','I','U'])->where(['user_type'=>'T'])->select('id','status','f_name','l_name')->get();
            $data['grades'] = Grade::whereIn('status',['A'])->select('id','grade_name','status')->get();
            $data['subjects'] = Subject::whereIn('status',['A'])->select('id','subject')->get();
            return view('admin.modules.bookings_management.bookings_management',$data);
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            session()->flash("error",$e->getMessage());
            return redirect()->back();
        }
    }
    public function bookingCancel(Request $request){
        try{
            $id = @$id;
            $booking = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['id'=>$id])->whereNotIn('booking_status',['C'])->first();
            if(@$booking){
                if(@$booking->booking_date == date('Y-m-d') && @$booking->from_time > date('H:i:s')){
                    StudentClassBooking::where(['id'=>$id])->update(['booking_status'=>'C','cancelled_by'=>'A','cancelled_on'=>now()]);
                    Tutor_calander_availability::where(['tutor_id'=>$booking->tutor_id,'date'=>$booking->booking_date])->where('start_time','>=',$booking->from_time)->where('end_time','<=',$booking->to_time)->update(['booking_status'=>'NB']);
                    $this->sendCancelBookingMail($id);
                    session()->flash("success","Booking cancelled successfully");
                    return redirect()->back();
                    
                }elseif(@$booking->booking_date > date('Y-m-d')){
                    StudentClassBooking::where(['id'=>$id])->update(['booking_status'=>'C','cancelled_on'=>now(),'cancelled_by'=>'A']);
                    Tutor_calander_availability::where(['tutor_id'=>$booking->tutor_id,'date'=>$booking->booking_date])->where('start_time','>=',$booking->from_time)->where('end_time','<=',$booking->to_time)->update(['booking_status'=>'NB']);
                    $this->sendCancelBookingMail($id);
                    session()->flash("success","Booking cancelled successfully");
                    return redirect()->back();
                }else{
                    session()->flash("error","You cannot cancel past bookings!");
                    return redirect()->back();
                    
                }
            }else{
                session()->flash("error","Booking is already cancelled");
                return redirect()->back();
                // $data['status'] = 0;
                // $data['message'] = "Please provide correct booking details!";
                // return response()->json($data,200);
            }
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            return redirect()->back();
        }
    }
    public function cancelBooking(Request $request){
        try{
            $id = @$request->data['id'];
            $data['bookingDataInformation'] = $booking = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->where(['id'=>$id])->whereNotIn('booking_status',['C'])->first();
            if(@$booking){
                if(@$data['bookingDataInformation']->booking_date == date('Y-m-d') && @$data['  bookingDataInformation']->from_time <= date('H:i:s')){
                    session()->flash("","You cannot cancel past booking!");
                    return redirect()->back();
                }
                if(@$booking->booking_date == date('Y-m-d') && @$booking->from_time > date('H:i:s')){
                    $payment = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();

                        if(@$payment){
                            $HourFullRefund = (Carbon::parse($data['bookingDataInformation']->booking_date." ".$data['bookingDataInformation']->from_time))->subhours(24);

                            $HourHalfRefund = (Carbon::parse($data['bookingDataInformation']->booking_date." ".$data['bookingDataInformation']->from_time))->subhours(12);                
                            if($HourFullRefund >= date('Y-m-d H:i:s')){
                                // dd("if greater than 24 hour HourFullRefund : ".$HourFullRefund.' current time'.date('Y-m-d H:i:s'));
                                //100% refund    
                                $stripe = \Stripe\Stripe::setApiKey('sk_test_51Jv1AlJ4WRuyPsk5Mn1hxt2P8PdyrlJJHnBtz9D4ngus7Oz5l8Xpeoznk70kKfcWYoTaQtoCQjOaIkzAaucQtmtr00TmroofCD');
                                $t = \Stripe\Refund::create([
                                  'charge' => $payment->txn_id,
                                  ['metadata' => ['order_id' => $payment->booking_id]]
                                ]);
                                Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->update(['refund_response'=>json_encode(@$t),'refund_id'=>@$t['id'],'refund_amount'=>$payment->amount,'refund_status'=>'S']);

                                
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>0,'admin_commission'=>0]);

                                $paymetDtls = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                                session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled! $".@$paymetDtls->refund_amount." has been refunded!"); 
                            }
                            else if($HourHalfRefund >= date('Y-m-d H:i:s')){
                                // dd("if greater than 12 hour $HourFullRefund : ".$HourFullRefund.' current time'.date('Y-m-d H:i:s'));
                                $refundAmount = ($payment->amount*(50/100));
                                $stripeAmount = (($payment->amount*(50/100))*100);
                                //50% refund 
                                $stripe = \Stripe\Stripe::setApiKey('sk_test_51Jv1AlJ4WRuyPsk5Mn1hxt2P8PdyrlJJHnBtz9D4ngus7Oz5l8Xpeoznk70kKfcWYoTaQtoCQjOaIkzAaucQtmtr00TmroofCD');
                                $t = \Stripe\Refund::create([
                                  'charge' => $payment->txn_id,
                                  'amount'=>$stripeAmount,
                                  ['metadata' => ['order_id' => $payment->booking_id]]
                                ]);  
                                Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->update(['refund_response'=>json_encode(@$t),'refund_id'=>@$t['id'],'refund_amount'=>$refundAmount,'refund_status'=>'S']);

                                $rest_of_amount = ($data['bookingDataInformation']->booking_amount - $refundAmount);
                                $admin_ord_commission = ( $rest_of_amount * ($data['bookingDataInformation']->admin_percentage/100));
                                $tutor_earnings  = $rest_of_amount - $admin_ord_commission;
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>$tutor_earnings,'admin_commission'=>$admin_ord_commission]);

                                $getUser = User::where(['id'=>$data['bookingDataInformation']->tutor_id])->first();
                                $updC['total_earning'] = $getUser->total_earning + $tutor_earnings;
                                $updC['total_due'] = $getUser->total_due+$tutor_earnings;
                                $updC['total_commission'] = $getUser->total_commission+$admin_ord_commission;
                                User::where(['id'=>$data['bookingDataInformation']->tutor_id])->update($updC);

                                $paymetDtls = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                                session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!".(@$paymetDtls->refund_amount)." has been refunded!");   
                            }else{
                                // no refund
                                $tutor_earnings = $data['bookingDataInformation']->tutor_earnings;
                                $admin_ord_commission = $data['bookingDataInformation']->admin_commission;
                                
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>$tutor_earnings,'admin_commission'=>$admin_ord_commission]);
                                $getUser = User::where(['id'=>$data['bookingDataInformation']->tutor_id])->first();
                                $updC['total_earning'] = $getUser->total_earning + $tutor_earnings;
                                $updC['total_due'] = $getUser->total_due+$tutor_earnings;
                                $updC['total_commission'] = $getUser->total_commission+$admin_ord_commission;
                                User::where(['id'=>$data['bookingDataInformation']->tutor_id])->update($updC);
                                session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!There is no refund for this booking no!");
                            }
                        
                        }else{
                            session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!There is no refund for this booking no!");
                        }
                    StudentClassBooking::where(['id'=>$id])->update(['booking_status'=>'C','cancelled_by'=>'A','cancelled_on'=>now()]);
                    Tutor_calander_availability::where(['tutor_id'=>$booking->tutor_id,'date'=>$booking->booking_date])->where('start_time','>=',$booking->from_time)->where('end_time','<=',$booking->to_time)->update(['booking_status'=>'NB']);
                    $this->sendCancelBookingMail($id);
                    $data['status'] = 1;
                    $data['message'] = "Booking cancelled";
                    $payment = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                    return response()->json($data,200);
                }elseif(@$booking->booking_date > date('Y-m-d')){
                    $payment = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();

                        if(@$payment){
                            $HourFullRefund = (Carbon::parse($data['bookingDataInformation']->booking_date." ".$data['bookingDataInformation']->from_time))->subhours(24);

                            $HourHalfRefund = (Carbon::parse($data['bookingDataInformation']->booking_date." ".$data['bookingDataInformation']->from_time))->subhours(12);                
                            if($HourFullRefund >= date('Y-m-d H:i:s')){
                                // dd("if greater than 24 hour HourFullRefund : ".$HourFullRefund.' current time'.date('Y-m-d H:i:s'));
                                //100% refund    
                                $stripe = \Stripe\Stripe::setApiKey('sk_test_51Jv1AlJ4WRuyPsk5Mn1hxt2P8PdyrlJJHnBtz9D4ngus7Oz5l8Xpeoznk70kKfcWYoTaQtoCQjOaIkzAaucQtmtr00TmroofCD');
                                $t = \Stripe\Refund::create([
                                  'charge' => $payment->txn_id,
                                  ['metadata' => ['order_id' => $payment->booking_id]]
                                ]);
                                Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->update(['refund_response'=>json_encode(@$t),'refund_id'=>@$t['id'],'refund_amount'=>$payment->amount,'refund_status'=>'S']);

                                
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>0,'admin_commission'=>0]);

                                $paymetDtls = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                                session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled! $".@$paymetDtls->refund_amount." has been refunded!"); 
                            }
                            else if($HourHalfRefund >= date('Y-m-d H:i:s')){
                                // dd("if greater than 12 hour $HourFullRefund : ".$HourFullRefund.' current time'.date('Y-m-d H:i:s'));
                                $refundAmount = ($payment->amount*(50/100));
                                $stripeAmount = (($payment->amount*(50/100))*100);
                                //50% refund 
                                $stripe = \Stripe\Stripe::setApiKey('sk_test_51Jv1AlJ4WRuyPsk5Mn1hxt2P8PdyrlJJHnBtz9D4ngus7Oz5l8Xpeoznk70kKfcWYoTaQtoCQjOaIkzAaucQtmtr00TmroofCD');
                                $t = \Stripe\Refund::create([
                                  'charge' => $payment->txn_id,
                                  'amount'=>$stripeAmount,
                                  ['metadata' => ['order_id' => $payment->booking_id]]
                                ]);  
                                Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->update(['refund_response'=>json_encode(@$t),'refund_id'=>@$t['id'],'refund_amount'=>$refundAmount,'refund_status'=>'S']);

                                $rest_of_amount = ($data['bookingDataInformation']->booking_amount - $refundAmount);
                                $admin_ord_commission = ( $rest_of_amount * ($data['bookingDataInformation']->admin_percentage/100));
                                $tutor_earnings  = $rest_of_amount - $admin_ord_commission;
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>$tutor_earnings,'admin_commission'=>$admin_ord_commission]);



                                $paymetDtls = Payments::where(['booking_id'=>$data['bookingDataInformation']->id])->first();
                                session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!".(@$paymetDtls->refund_amount)." has been refunded!"); 
                            }else{
                                // no refund

                                $tutor_earnings = $data['bookingDataInformation']->tutor_earnings;
                                $admin_ord_commission = $data['bookingDataInformation']->admin_commission;
                                
                                StudentClassBooking::where(['id'=>$data['bookingDataInformation']->id])->update(['tutor_earnings'=>$tutor_earnings,'admin_commission'=>$admin_ord_commission]);
                                $getUser = User::where(['id'=>$data['bookingDataInformation']->tutor_id])->first();
                                $updC['total_earning'] = $getUser->total_earning + $tutor_earnings;
                                $updC['total_due'] = $getUser->total_due+$tutor_earnings;
                                $updC['total_commission'] = $getUser->total_commission+$admin_ord_commission;
                                User::where(['id'=>$data['bookingDataInformation']->tutor_id])->update($updC);

                                session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!There is no refund for this booking no!");
                            }
                        
                        }else{
                            session()->flash("success","Your booking ".$data['bookingDataInformation']->booking_no." is now cancelled!There is no refund for this booking no!");
                        }
                    StudentClassBooking::where(['id'=>$id])->update(['booking_status'=>'C','cancelled_by'=>'A','cancelled_on'=>now()]);
                    Tutor_calander_availability::where(['tutor_id'=>$booking->tutor_id,'date'=>$booking->booking_date])->where('start_time','>=',$booking->from_time)->where('end_time','<=',$booking->to_time)->update(['booking_status'=>'NB']);
                    $this->sendCancelBookingMail($id);
                    $data['status'] = 1;
                    $data['message'] = "Booking cancelled";
                    return response()->json($data,200);
                }else{
                    $data['status'] = 0;
                    $data['message'] = "You cannot cancel past bookings!";
                    return response()->json($data,200);
                }
            }else{
                $data['status'] = 0;
                $data['message'] = "Please provide correct booking details!";
                return response()->json($data,200);
            }
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            $data['status'] = 0;
            $data['message'] = $e->getMessage();
            return response()->json($data,200);
        }
    }
    public function viewDetails($bookingNo){
         $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade','getPaymentsInfo'])->where(['booking_no'=>$bookingNo])->first();
         return view('admin.modules.bookings_management.view_booking_details',$data);
    }

    public function sendCancelBookingMail($id){
        try{
            $data['bookingDataInformation'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade','getPaymentsInfo'])->where(['id'=>$id])->first();
            Mail::send(new CancelBookingMail($data));
        }catch(\Exception $e){

            \Log::error($e->getMessage());
        }   
    }
    public function getBookingManagementList(Request $request){
        
        $data['bookings'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->whereIn('booking_status',['B','C','CM']);
        if(@$request->booking_search){
            $bookings = $bookings->where(function($query) use($request) {
                $query->where('booking_no','like','%'.$request->booking_search.'%');
            });
        }
        if(@$request->col2_filter){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('booking_status',$request->col2_filter);
            });
        }
        if(@$request->col7_filter){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('student_id',$request->col7_filter);
            });
        }
        if(@$request->col8_filter){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('tutor_id',$request->col8_filter);
            });
        }
        if(@$request->col9_filter){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('student_grade_id',$request->col9_filter);
            });
        }
        if(@$request->col10_filter){
            $bookings = $bookings->where(function($query) use($request) {
                $query->Where('subject_id',$request->col10_filter);
            });
        }
        
        if(@$request->col3_filter && @$request->col4_filter){
            $bookings = $bookings->where(function($query) use($request) {
                $query->whereBetween('created_at',[@$request->col3_filter." 00:00:00", @$request->col4_filter." 23:59:59"]);
            });
        }
        if(@$request->col5_filter && @$request->col6_filter){
            $bookings = $bookings->where(function($query) use($request) {
                $query->whereBetween('booking_date',[@$request->col5_filter, @$request->col6_filter]);
            });
        }
        $data['bookings'] = $data['bookings']->orderBy('id','desc')->get();
        $t = '';
        $t .='<table>
            <tr>
                <th style="border:1px solid black;background-color
      :lime">Booking id</th>
      <th style="border:1px solid black;background-color
      :lime">Student name</th>
      <th style="border:1px solid black;background-color
      :lime">Tutor name</th>
      <th style="border:1px solid black;background-color
      :lime">Grade</th>
      <th style="border:1px solid black;background-color
      :lime">Subject</th>
      <th style="border:1px solid black;background-color
      :lime">From time</th>
      <th style="border:1px solid black;background-color
      :lime">To time</th>
      <th style="border:1px solid black;background-color
      :lime">Booking date</th>
      <th style="border:1px solid black;background-color
      :lime">Status</th>

      <th style="border:1px solid black;background-color
      :lime">Payment</th>
      <th style="border:1px solid black;background-color
      :lime">Zoom url</th>
            </tr>
            ';
        if(@$data['bookings']){
            foreach(@$data['bookings'] as $value){
                // booking status 
        if ($value->booking_status=="B") {
          $status = "Booked";
        }elseif ($value->booking_status=="C") {
          $status = "Cancelled";
        }elseif($value->booking_status=="I"){
           $status = "In Progress";
        }  
        elseif ($value->booking_status=="CM"){
           $status = "Completed";
        }else{
            $status = "";
        }
        $payment_method="Online";
        $t .= '
        <tr>
        <td style="border:1px solid black;">'.@$value->booking_no.'</td>
        <td style="border:1px solid black;">'.@$value->getStudent->f_name." ".@$value->getStudent->l_name.'</td>
        <td style="border:1px solid black;">'.@$value->getTutor->f_name." ".@$value->getTutor->l_name.'</td>
        <td style="border:1px solid black;">'.@$value->getStudentGrade->grade_name.'</td>
        <td style="border:1px solid black;">'.@$value->getSubject->subject.'</td>
        <td style="border:1px solid black;">'.date('h:i a',strtotime(@$value->from_time)).'</td>
        <td style="border:1px solid black;">'.date('h:i a',strtotime(@$value->to_time)).'</td>
        <td style="border:1px solid black;">'.@$value->booking_date.'</td>

        <td style="border:1px solid black;">'.@$status.'</td>
        <td style="border:1px solid black;">'.@$payment_method.'</td>
        <td style="border:1px solid black;">'.@$value->join_url.'</td>
        </tr>';
            }
        }
        $t .= '</table>';
        header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");    
        header("Content-Disposition: attachment; filename=BookingManagement.xls");  
        header("Pragma: no-cache"); 
        header("Expires: 0");
        echo $t;
    }

}
