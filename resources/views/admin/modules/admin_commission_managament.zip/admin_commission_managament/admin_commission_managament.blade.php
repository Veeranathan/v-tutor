@extends('admin.layouts.app')
@section('title')
Commission Update
@endsection
@section('links')
@include('admin.includes.links')
<link href="{{ asset('public/admin/assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('public/admin/assets/css/core.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('public/admin/assets/css/icons.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('public/admin/assets/css/responsive.css') }}" rel="stylesheet" type="text/css">    
@endsection
@section('header')
@include('admin.includes.header')
@endsection
@section('sidebar')
@include('admin.includes.sidebar')
@endsection
@section('content')
<div class="content">
    <div class="wraper container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="pull-left page-title">Commission Update</h4>
                <ol class="breadcrumb pull-right">
                    
                </ol>
            </div>
        </div>
        <!-- Personal-Information -->
        <div class="panel panel-default panel-fill">
            <div class="panel-body rm02 rm04">
                @include('admin.includes.message')
                <div class="frm_admin">
                        <form id="commissionForm" method="post" action="{{ route('admin.set.commission') }}">
                            @csrf
                            <div class="row">
                                <div class="col-lg-3 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="grade_name">Commission Percentage*</label>
                                        <input type="number" placeholder="Commission" id="commission" name="commission" class="form-control required" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');" min="0" max="100" value="{{ @$admin_commission_management->commission }}">
                                    </div>
                                </div>
                                
                                <div class="col-sm-12">
                                    <div class="ad_btn">
                                        <button class="btn btn-primary waves-effect waves-light w-md c_save_grade" id="save_grade" type="button">Save</button> 
                                    </div>
                                </div>
                            </div>
                        </form>
                </div>
            </div>
        </div>
        <!-- Personal-Information -->
    </div>
</div>
@endsection    
@section('footer')
@include('admin.includes.footer')
@endsection
@section('script')
@include('admin.includes.script')
<script src="{{ asset('public/admin/assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('public/admin/assets/js/bootstrap.min.js') }}"></script>
<script src="{{asset('public/admin/assets/js/jquery.validate.js')}}"></script>
<script>
$(document).ready(function(){
    var isvalidator = $('#commissionForm').validate();
    $('#commissionForm').on('keyup keypress keydown', function(e) {
      var keyCode = e.keyCode || e.which;
      if (keyCode === 13) { 
        e.preventDefault();
        return false;
      }
    });
    $("#save_grade").click(function(){
        if(isvalidator.form()){
        if(isvalidator.valid()){
            var obj = $("#save_grade"),
            tId = obj.attr("id"),
            tName = "c_save_grade",
            tFrmId = "commissionForm";
            $("#type_popup_next").val("R");
            isAuthorizedByAdmin(tName,tId,tFrmId);
        }else{
            $('#instructionModal').modal('hide');
        } 
        }  
    });
});
</script>
@endsection