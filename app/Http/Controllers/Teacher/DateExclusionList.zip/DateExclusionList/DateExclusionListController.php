<?php

namespace App\Http\Controllers\Teacher\DateExclusionList;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\MyAvailability;
use App\Models\Tutor_calander_availability;
use App\Models\AdminDisableBookings;
use App\Models\AdminDisableBookingDates;
use App\Models\TutorNonAvailabilityDetails;
use Auth;

class DateExclusionListController extends Controller
{
    /*
    * Method        : viewDateExclusionList
    * Description   : This method is to show view date exxclusion list
    * Author        : Jayatri
    */
    public function viewMyDateExclusionList(Request $request)
    {
        $data['all_disabled_booking_dates']= $all_disabled_booking_dates = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();
        $data['nextMaxDate'] = date('Y-m-d', strtotime("+30 days"));
        $data['get_available_dates'] = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB'])->where('date','>=',date('Y-m-d'))->where('date','<=',$data['nextMaxDate'])->whereNotIn('date',$all_disabled_booking_dates)->groupBy('date')->pluck('date')->toArray();
        // ->where('date','>=',date('Y-m-d'))->where('date','<=',$data['nextMaxDate'])
        // ->orderBy('date','asc')
        // $data['getTutorCalDatesTimes'] = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id])->whereIn('booking_status',['NA'])->get();
        $data['getTutorCalDatesTimes'] = TutorNonAvailabilityDetails::where(['tutor_id'=>@Auth::user()->id])->get();
        return view('teacher.modules.manage_date_exclusion_list.manage_date_exclusion_list')->with($data);
    }
    /*
    * Method        : updateMyDateExclusionList
    * Description   : This method is to update date exxclusion list
    * Author        : Jayatri
    */
    public function updateMyDateExclusionList(Request $request)
    {
        // code...
        if(@$request->all()){
            $data['all_disabled_booking_dates']= $all_disabled_booking_dates = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();

            $bookingDate = date('Y-m-d',strtotime($request->selected_date));
            if(@$request->from_time){
                $from_time = date('H:i:s',strtotime($request->from_time));    
            }
            if(@$request->to_time){
                $to_time = date('H:i:s',strtotime($request->to_time));   
                
            }

            if(@$request->from_time && @$request->to_time){ 
                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'B','date'=>$bookingDate])->where('start_time','>=',$from_time);
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
            }else{
                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'B','date'=>$bookingDate]);
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
            }
            if($chkBDtFrmTimeToTime > 0){
                session()->flash("error","Cannot exclude date / time as class(es) have been booked. You may choose to cancel those sessions from 'My Classes' T&C's apply");
                return redirect()->back();
            }
            /******new conditions******/ 
            if(@$request->from_time && @$request->to_time){ 

                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NA','date'=>$bookingDate])->where('start_time','>=',$from_time);
                
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
                if($chkBDtFrmTimeToTime > 0){
                    session()->flash("error","Cannot exclude date / time as class(es) have been booked. You may choose to cancel those sessions from My Classes T&C's apply");
                    return redirect()->back();
                }
            }
            /************ Main Conditions********************************/ 
            if(@$request->from_time && @$request->to_time){ 

                $day = date("D", strtotime($request->selected_date));
                $tutor_id = @Auth::user()->id;
                //get day value 
                if($day == "Mon"){
                    $dValue = 1;
                }
                if($day == "Tue"){
                    $dValue = 2;
                }
                if($day == "Wed"){
                    $dValue = 3;
                }
                if($day == "Thu"){
                    $dValue = 4;
                }
                if($day == "Fri"){
                    $dValue = 5;
                }
                if($day == "Sat"){
                    $dValue = 6;
                }
                if($day == "Sun"){
                    $dValue = 7;
                }
                // if(@$admin_disable_bookings_values->disable_booking == 'Y'){
                //     session()->flash("error","The date is already blocked by admin. Please contact support");
                //     return redirect()->back();
                // }
                if(in_array($bookingDate,$all_disabled_booking_dates)){
                    session()->flash("error","The date is already blocked by admin. Please contact support");
                    return redirect()->back();
                }
                if($bookingDate < date('Y-m-d')){
                    session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.Today from time to time should be greater than current time!");
                    return redirect()->back();
                }
                if($bookingDate == date('Y-m-d')){
                    if($from_time <= date('H:i:s') || $to_time <= date('H:i:s')){        
                        session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.Today from time to time should be greater than current time!");
                        return redirect()->back();
                    }   
                }
                // check whether tutor is available or not 
                $starttime = $from_time;  // your start time
                $endtime = $to_time;  // End time
                $duration = '30';  // split by 30 mins

                $array_of_time = array ();
                $start_time    = strtotime ($starttime); //change to strtotime
                $end_time      = strtotime ($endtime); //change to strtotime

                $add_mins  = $duration * 60;
                while ($start_time <= $end_time) // loop between time
                {
                   $array_of_time[] = date ("h:i:s", $start_time);
                   $start_time += $add_mins; // to check endtie=me
                } 
                $length=count($array_of_time);
                $from_to_times=[];
                $get_all_from_times=[];
                $get_all_to_times=[];

                for($k=0;$k<$length;$k++){
                    $data=[];
                    if($k+1<$length){
                        $data['from_time']=$array_of_time[$k];
                        $data['to_time']=$array_of_time[$k+1];
                        $frmT = "'".$data['from_time']."'";
                        $toT = "'".$data['to_time']."'";
                        array_push($from_to_times,$data);
                        array_push($get_all_from_times,$frmT);
                        array_push($get_all_to_times,$toT);
                    }
                }
                $timeSlotCount = count($from_to_times);
                // check available or not
                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'B','date'=>$bookingDate])->where('start_time','>=',$from_time);
                
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
                
                if($chkBDtFrmTimeToTime > 0){
                    session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.");
                        return redirect()->back();
                }
                // check available if
                $chkADtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$bookingDate])->where('start_time','>=',$from_time);
                
                $chkADtFrmTimeToTime = $chkADtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                
                $chkADtFrmTimeToTime = $chkADtFrmTimeToTime->count();
                
                if($chkADtFrmTimeToTime <= 0){
                   session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.");
                        return redirect()->back();
                }
                if($timeSlotCount == $chkADtFrmTimeToTime){
                    
                }else{
                   
                    session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.");
                        return redirect()->back();
                }
            }
            /***********************Add and Update start********************************/ 
            $crTutorNonAvilability['tutor_id'] = @Auth::user()->id;
            $crTutorNonAvilability['unavialable_date'] = $request->selected_date;
            if(@$request->from_time){
                $crTutorNonAvilability['start_time'] = $from_time;
            }
            if(@$request->to_time){
                $crTutorNonAvilability['end_time'] = $to_time;
            }
            $tutorNonAvilabilityDetails = TutorNonAvailabilityDetails::create($crTutorNonAvilability);
            // else{
                if(@$request->from_time && @$request->to_time){ 
                    $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB','date'=>$bookingDate])->where('start_time','>=',$from_time);
                    $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                        $query->whereBetween('end_time',[$from_time,$to_time]);
                    });
                    $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->update(['booking_status'=>'NA']);
                    session()->flash("success","Date added to exclusion list");
                }else{
                    Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB','date'=>$bookingDate])->update(['booking_status'=>'NA']);        
                    session()->flash("success","Date added to exclusion list");
                }
            // }
            /****************************Update end****************************/ 
        }
        return redirect()->back();
    }
    /*
    * Method        : viewDateExclusionList
    * Description   : This method is to show view date exxclusion list
    * Author        : Jayatri
    */
    public function ajaxCheckingDateExclusion(Request $request){
        try{
            
            $data_get_selected_date = $request->data['selected_date'];

            // $from_time = $request->data['from_time'];
            // $to_time = $request->data['to_time'];
            //conditions
            $data['all_disabled_booking_dates']= $all_disabled_booking_dates = AdminDisableBookingDates::where('status','A')->pluck('disable_booking_date')->toArray();

            $bookingDate = date('Y-m-d',strtotime($request->data['selected_date']));

            $minSTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB','date'=>$bookingDate])->min('start_time');
            $data['minSTime'] = date('h:i a',strtotime($minSTime));

            $maxSTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB','date'=>$bookingDate])->max('start_time');
            $data['maxSTime'] = date('h:i a',strtotime($maxSTime));

            $minTTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB','date'=>$bookingDate])->min('end_time');
            $data['minTTime'] = date('h:i a',strtotime($minTTime));

            $maxTTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB','date'=>$bookingDate])->max('end_time');
            $data['maxTTime'] = date('h:i a',strtotime($maxTTime));
            
            $data['get_available_start_times'] = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB','date'=>$bookingDate])->groupBy('start_time')->pluck('start_time')->toArray();
            $data['get_available_end_times'] = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NB','date'=>$bookingDate])->groupBy('end_time')->pluck('end_time')->toArray();

            if(@$request->data['from_time']){
                $from_time = date('H:i:s',strtotime($request->data['from_time']));    
            }
            if(@$request->data['to_time']){
                $to_time = date('H:i:s',strtotime($request->data['to_time']));    
            }
            
            
            if(@$request->data['from_time'] && @$request->data['to_time']){ 
                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'B','date'=>$bookingDate])->where('start_time','>=',$from_time);
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
            }else{
                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'B','date'=>$bookingDate]);
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
            }
            if($chkBDtFrmTimeToTime > 0){
                // session()->flash("error","Cannot exclude date / time as class(es) have been booked. You may choose to cancel those sessions from My Classes");
                // return redirect()->back();
                $data['output'] = 'false';
                $data['condition_no'] = '1';
                $data['message'] = "Cannot exclude date / time as class(es) have been booked. You may choose to cancel those sessions from 'My Classes' T&C's apply";
                    return $data;
            }
            /******new conditions******/ 
            if(@$request->data['from_time'] && @$request->data['to_time']){ 

                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NA','date'=>$bookingDate])->where('start_time','>=',$from_time);
                
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
                
                if($chkBDtFrmTimeToTime > 0){
                    $data['output'] = 'false';
                    $data['condition_no'] = '2';
                    $data['message'] = "Cannot exclude date / time as class(es) have been booked. You may choose to cancel those sessions from My Classes T&C's apply";
                    return $data;
                    // session()->flash("error","This date & time is already added previously!");
                    // return redirect()->back();
                }
            }
            /************ Main Conditions********************************/ 
            if(@$request->data['from_time'] && @$request->data['to_time']){ 

                $day = date("D", strtotime($request->selected_date));
                $tutor_id = @Auth::user()->id;
                //get day value 
                if($day == "Mon"){
                    $dValue = 1;
                }
                if($day == "Tue"){
                    $dValue = 2;
                }
                if($day == "Wed"){
                    $dValue = 3;
                }
                if($day == "Thu"){
                    $dValue = 4;
                }
                if($day == "Fri"){
                    $dValue = 5;
                }
                if($day == "Sat"){
                    $dValue = 6;
                }
                if($day == "Sun"){
                    $dValue = 7;
                }
                // if(@$admin_disable_bookings_values->disable_booking == 'Y'){
                //     session()->flash("error","The date is already blocked by admin. Please contact support");
                //     return redirect()->back();
                // }
                if(in_array($bookingDate,$all_disabled_booking_dates)){
                    $data['output'] = 'false';
                    $data['condition_no'] = '3';
                    $data['message'] = 'The date is already blocked by admin. Please contact support!';
                    return $data;
                    // session()->flash("error","The date is already blocked by admin. Please contact support");
                    // return redirect()->back();
                }
                if($bookingDate < date('Y-m-d')){
                    $data['output'] = 'false';
                    $data['condition_no'] = '5';
                    $data['message'] = 'Date / Time not applicable to availability. Please ensure you choose based on your schedule.Today from time to time should be greater than current time!';
                    return $data;
                    // session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.Today from time to time should be greater than current time!");
                    // return redirect()->back();
                }
                if($bookingDate == date('Y-m-d')){
                    if($from_time <= date('H:i:s') || $to_time <= date('H:i:s')){  

                        $data['output'] = 'false';
                        $data['condition_no'] = '5';
                        $data['message'] = 'Date / Time not applicable to availability. Please ensure you choose based on your schedule.Today from time to time should be greater than current time!';
                        return $data;
                        // session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.Today from time to time should be greater than current time!");
                        // return redirect()->back();
                    }   
                }
                // check whether tutor is available or not 
                $starttime = $from_time;  // your start time
                $endtime = $to_time;  // End time
                $duration = '30';  // split by 30 mins

                $array_of_time = array ();
                $start_time    = strtotime ($starttime); //change to strtotime
                $end_time      = strtotime ($endtime); //change to strtotime

                $add_mins  = $duration * 60;
                while ($start_time <= $end_time) // loop between time
                {
                   $array_of_time[] = date ("h:i:s", $start_time);
                   $start_time += $add_mins; // to check endtie=me
                } 
                $length=count($array_of_time);
                $from_to_times=[];
                $get_all_from_times=[];
                $get_all_to_times=[];

                for($k=0;$k<$length;$k++){
                    $data=[];
                    if($k+1<$length){
                        $data['from_time']=$array_of_time[$k];
                        $data['to_time']=$array_of_time[$k+1];
                        $frmT = "'".$data['from_time']."'";
                        $toT = "'".$data['to_time']."'";
                        array_push($from_to_times,$data);
                        array_push($get_all_from_times,$frmT);
                        array_push($get_all_to_times,$toT);
                    }
                }
                $timeSlotCount = count($from_to_times);
                // check available or not
                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'B','date'=>$bookingDate])->where('start_time','>=',$from_time);
                
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->count();
                
                if($chkBDtFrmTimeToTime > 0){
                    $data['output'] = 'false';
                    $data['condition_no'] = '6';
                    $data['message'] = 'Date / Time not applicable to availability. Please ensure you choose based on your schedule.';
                    return $data;
                    // session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.");
                    // return redirect()->back();
                }
                // check available if
                $chkADtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$bookingDate])->where('start_time','>=',$from_time);
                
                $chkADtFrmTimeToTime = $chkADtFrmTimeToTime->where(function($query) use($request,$from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                
                $chkADtFrmTimeToTime = $chkADtFrmTimeToTime->count();
                
                if($chkADtFrmTimeToTime <= 0){
                    $data['output'] = 'false';
                    $data['condition_no'] = '7';
                    $data['message'] = 'Date / Time not applicable to availability. Please ensure you choose based on your schedule.';
                    return $data;
                    // session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.");
                    // return redirect()->back();
                }
                if($timeSlotCount == $chkADtFrmTimeToTime){
                    $data['output'] = 'true';
                    $data['condition_no'] = '9';
                    $data['message'] = 'Available';
                    return $data;
                }else{
                    $data['output'] = 'false';
                    $data['condition_no'] = '11';
                    $data['message'] = 'Date / Time not applicable to availability. Please ensure you choose based on your schedule.';
                    return $data;
                   // return 'false';
                    // session()->flash("error","Date / Time not applicable to availability. Please ensure you choose based on your schedule.");
                    //     return redirect()->back();
                }
            }else{
                $data['output'] = 'true';
                $data['condition_no'] = '12';
                    $data['message'] = 'Available';
                return $data;
            }
            // end of conditions
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            $data['output'] = 'false';
            $data['condition_no'] = '14';
            $data['message'] = $e->getMessage();
            return $data;
        }
    }
    public function getDateFromToTimes(Request $request){
        try{
            $booking_date = trim($request->data['selected_date']);
            $tutor_id = @Auth::user()->id;
            
            $data['get_available_start_times'] = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->groupBy('start_time')->pluck('start_time')->toArray();
            
            $minSTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->min('start_time');
            $data['min_available_start_times'] = date('h:i a',strtotime($minSTime));

            $maxSTime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->max('start_time');
            $data['max_available_start_times'] = date('h:i a',strtotime($maxSTime));

            $data['get_available_end_times'] = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->groupBy('end_time')->pluck('end_time')->toArray();

            $min_end_times = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->min('end_time');
            $data['min_available_end_times'] = date('h:i a',strtotime($min_end_times));

            $maxETime = Tutor_calander_availability::where(['tutor_id'=>$tutor_id,'booking_status'=>'NB','date'=>$booking_date])->max('end_time');
            $data['max_available_end_times'] = date('h:i a',strtotime($maxETime));
            return response()->json($data,200);
        }catch(\Exception $e){
            \Log::error($e->getMessage());
            $data['message'] = $e->getMessage();
            return response()->json($data,200);
        }
    }
    public function deleteNonAvilability($id){
        $getTutorNonAV = TutorNonAvailabilityDetails::where('id',$id)->first();
        if(@$getTutorNonAV){
            $from_time = @$getTutorNonAV->start_time;
            $to_time = @$getTutorNonAV->end_time;
            $unavialable_date = @$getTutorNonAV->unavialable_date;
            if(@$getTutorNonAV->start_time && @$getTutorNonAV->end_time){ 
                $chkBDtFrmTimeToTime = Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NA','date'=>$unavialable_date])->where('start_time','>=',$from_time);
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->where(function($query) use($from_time,$to_time) {
                    $query->whereBetween('end_time',[$from_time,$to_time]);
                });
                $chkBDtFrmTimeToTime = $chkBDtFrmTimeToTime->update(['booking_status'=>'NB']);
                session()->flash("success","Date & Time deleted successfully!");
            }else{
                Tutor_calander_availability::where(['tutor_id'=>@Auth::user()->id,'booking_status'=>'NA','date'=>$unavialable_date])->where('booking_status',['NA'])->update(['booking_status'=>'NB']);        
                session()->flash("success","Date & Time deleted successfully");
            }
            TutorNonAvailabilityDetails::where('id',$id)->delete(); 
            session()->flash("success","Date & Time deleted successfully");
            return redirect()->back();   
        }else{
            session()->flash("error","id is wrong!Please provide correct id!");
            return redirect()->back();
        }
    }

}
