@extends('layouts.app')
@section('title')
<title>V-tutor | Student | Booking Confirmaton | {{ @$bookingDataInformation->booking_no }}</title>
@endsection
@section('left_part')
@include('include.student_top_common')
@endsection
@section('content')
<!-- bannersec -->
<!-- bannersec -->
<div class="top_mar"></div>
<!--- profile --->
<section class="user-account">
    <div class="container">
        <div class="row">
            <div class="zin">
                @include('include.student_left_common')
                <div class="user-right-panel">
                    <div class="user-right-top-new ">
                        <h2 class="profile-heading">Booking Confirmation</h2>
                        <p>Your booking {{ @$bookingDataInformation->booking_no }} sucessfully done. Here have your booking details</p>
                        @include('include.errors')
                    </div>
                    <form action="" method="post" class="chcoutt_rm_07 require-validation"  data-cc-on-file="false" data-stripe-publishable-key="{{ env('STRIPE_KEY') }}" id="payment-form">
                        <input type="hidden" name="email" value="{{ @$bookingDataInformation->getStudent->email }}">
                        <input type="hidden" name="orderId" value="{{ @$bookingDataInformation->id }}">
                        <input type="hidden" name="order_no" value="{{ @$bookingDataInformation->booking_no }}">
                        <input type="hidden" name="amount" value="{{ @$bookingDataInformation->booking_amount }}"> 
                        <input type="hidden" name="currency" value="usd">
                        <input type="hidden" name="metadata" value="{{ json_encode($array = ['order_id' =>  @$bookingDataInformation->id , 'order_no' => @$bookingDataInformation->booking_no]) }}" > 
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <div class="class-feild mt-4">
                            <div class="row">
                                <div class="col-12">
                                    <div class="tuto-rating">
                                        <em>
                                        @if(@$bookingDataInformation->getTutor->profile_pic)
                                        <img src="{{asset('storage/app/public/teacher_profile_pic/'.@$bookingDataInformation->getTutor->profile_pic)}}" alt="" id="img2">
                                        @else
                                        @if(@$bookingDataInformation->getTutor->avatar)
                                        <img src="{{@$bookingDataInformation->getTutor->avatar}}" alt="" id="img2">
                                        @else
                                        <img src="{{ asset('public/assets/images/user-pro.png') }}" alt="" id="img2">
                                        @endif
                                        @endif
                                        </em>
                                        <div class="tu-info">
                                            <h2>{{ @$bookingDataInformation->getTutor->f_name }} {{ @$bookingDataInformation->getTutor->l_name }}</h2>
                                            <div class="sed">
                                                <span><img src="{{ asset('public/assets/images/map.png') }}">  {{ @$bookingDataInformation->getTutor->getState->state_name }}</span>
                                                <ul class="profile-rating m-0">
                                                    @if(@$bookingDataInformation->avg_review>=0 && @$bookingDataInformation->avg_review<=0.24)
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=0.25 && @$bookingDataInformation->avg_review<=0.74)
                                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=0.75 && @$bookingDataInformation->avg_review<=1.24)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=1.25 && @$bookingDataInformation->avg_review<=1.74)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=1.75 && @$bookingDataInformation->avg_review<=2.24)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=2.25 && @$bookingDataInformation->avg_review<=2.74)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=2.75 && @$bookingDataInformation->avg_review<=3.24)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=3.25 && @$bookingDataInformation->avg_review<=3.74)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=3.75 && @$bookingDataInformation->avg_review<=4.24)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=4.25 && @$bookingDataInformation->avg_review<=4.74)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                                    @endif
                                                    @if(@$bookingDataInformation->avg_review>=4.75 && @$bookingDataInformation->avg_review<=5)
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                                    @endif
                                                    <li>
                                                        <p>{{ @$bookingDataInformation->getTutor->avg_review }} ({{ @$bookingDataInformation->getTutor->total_no_of_reviews }})</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="sed ">
                                            </div>
                                            <div class="sed grade_sed">
                                                <span><img src="{{ asset('public/assets/images/gra.png') }}"> {{ @$bookingDataInformation->getStudentGrade->grade_name }}</span>
                                                <span>
                                                <img src="{{ asset('public/assets/images/world.png') }}"> 
                                                @if(@$t_my_av_show)
                                                @foreach(@$t_my_av_show as $key=>$t)
                                                @if(@$key != 0), @endif
                                                @if(@$t->day == 1)
                                                Monday
                                                @elseif(@$t->day == 2)
                                                Tuesday
                                                @elseif(@$t->day == 3)
                                                Wednesday
                                                @elseif(@$t->day == 4)
                                                Thursday
                                                @elseif(@$t->day == 5)
                                                Friday
                                                @elseif(@$t->day == 6)
                                                Saturday
                                                @elseif(@$t->day == 7)
                                                Sunday
                                                @endif
                                                {{ date("h:i a", strtotime(@$t->from_time)) }}-{{ date("h:i a", strtotime(@$t->to_time)) }}
                                                @endforeach
                                                @endif
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="user-right-top-new marb90 text-center">
                            <div class="row new_rows no-gutters">
                                <div class="col-md-3 col-sm-6 from_time_value book_f_t_v">    
                                    <h6>Name On Card</h6>
                                    <input
                                    class='form-control' size='4' type='text' name="name_of_card">
                                    <span id="error_selected_d error" class="" style="color: red"></span>
                                </div>
                                <div class="col-md-3 col-sm-6 from_time_value book_f_t_v">    
                                    <h6>Card Number</h6>
                                    <input
                                    autocomplete='off' class='form-control card-number' size='20'
                                    type='text' name="card_no">
                                    <span id="error_f" class="error_start_end_time" style="color: red"></span>
                                </div>
                                <div class="col-md-3 col-sm-6 from_time_value book_f_t_v">
                                    <h6>CVC</h6>
                                    <input autocomplete='off'
                                    class='form-control card-cvc' placeholder='ex. 311' size='4'
                                    type='text' name="cvvNumber">
                                    <span id="to_f1" class="error_start_end_time" style="color: red"></span>
                                </div>
                                <div class="col-md-3 col-sm-6 from_select_subject_student_book">
                                    <div class="form_box_area">

                                        <label for="control-label">Expiration Month </label>

                                        <input
                                    class='form-control card-expiry-month' placeholder='MM' size='2'
                                    type='text' name="ccExpiryMonth">

                                    </div>

                                </div>
                                <div class="col-md-3 col-sm-6 from_select_subject_student_book">
                                    <div class="form_box_area">

                                        <label for="control-label">Expiration Year </label>

                                        <input
                                    class='form-control card-expiry-year' placeholder='YYYY' size='4'
                                    type='text' name="ccExpiryYear">

                                    </div>

                                </div>

                            </div>
                            <div class="btn_3_cc">
                                
                            </div>
                            {{-- <img src="{{ asset('public/assets/images/confr.png') }}"> --}}
                            {{-- <h2 class="profile-headingnew">Your booking order is received. </h2> --}}
                            {{-- <p class="" style="font-style: italic;">An email with booking details will be sent once confirmed</p> --}}
                            {{-- <p class="bold_black_text">Kindly pay to confirm booking</p> --}}
                            
                            <div class="booking-stat table_book">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Booking Number </th>
                                                <th>Subject</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Rate per session (30 mins)</th>
                                                <th>Amount</th>
                                            </tr>
                                        </thead>
                                        <tr>
                                            <td>{{ @$bookingDataInformation->booking_no }}</td>
                                            <td>{{ @$bookingDataInformation->getSubject->subject }} </td>
                                            <td>{{ @$bookingDataInformation->booking_date }}</td>
                                            <td>{{ date("h:i a", strtotime(@$bookingDataInformation->from_time)) }} to {{ date("h:i a", strtotime(@$bookingDataInformation->to_time)) }}</td>
                                            <td>${{ @$bookingDataInformation->hourly_rate }}</td>
                                            <td>${{ @$bookingDataInformation->booking_amount }}</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="btn_3_cc">
                                    
                                    <input type="submit" name="" value="Pay" class="sub_btn new-subbtn">
                                    
                                    
                                </div>
                            </div>
                        </div>
                        
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade log_modal_bx" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">You are about to leave the site to complete booking process</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="modal_button">
                    <ul>
                        <li><a href="#" class=" pg_btn">Leave</a></li>
                        <li><a href="#" class="pg_btn">Stay</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('footer')
@include('include.footer')
@endsection
@section('script')
@include('include.script')
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script type="text/javascript">
    $(function() {
        var $form         = $(".require-validation");
        $('form.require-validation').bind('submit', function(e) {
            var $form         = $(".require-validation"),
            inputSelector = ['input[type=email]', 'input[type=password]',
            'input[type=text]', 'input[type=file]',
            'textarea'].join(', '),
            $inputs       = $form.find('.required').find(inputSelector),
            $errorMessage = $form.find('div.error'),
            valid         = true;
            $errorMessage.addClass('hide');

            $('.has-error').removeClass('has-error');
            $inputs.each(function(i, el) {
              var $input = $(el);
              if ($input.val() === '') {
                $input.parent().addClass('has-error');
                $errorMessage.removeClass('hide');
                e.preventDefault();
            }
        });
            if($('.card-number').val().length == 16){
                if (!$form.data('cc-on-file')) {
                  e.preventDefault();
                  Stripe.setPublishableKey($form.data('stripe-publishable-key'));
                  Stripe.createToken({
                    number: $('.card-number').val(),
                    cvc: $('.card-cvc').val(),
                    exp_month: $('.card-expiry-month').val(),
                    exp_year: $('.card-expiry-year').val()
                }, stripeResponseHandler);
              }
          }
          else{
            $('.error')
                .removeClass('hide')
                .find('.alert')
                .text('Your card number is incorrect.');
                return false;
          }
      });

        function stripeResponseHandler(status, response) {
            if (response.error) {
                $('.error')
                .removeClass('hide')
                .find('.alert')
                .text(response.error.message);
            } else {
            // token contains id, last4, and card type
            var token = response['id'];
            // insert the token into the form so it gets submitted to the server
            $form.find('input[type=text]').empty();
            $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
            $form.get(0).submit();
        }
    }

});
</script>
@endsection