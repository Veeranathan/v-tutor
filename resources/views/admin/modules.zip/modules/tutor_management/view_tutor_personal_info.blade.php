@extends('admin.layouts.app')
@section('title')
Personal Info
@endsection
@section('links')
@include('admin.includes.links')
<style type="text/css">
    .buttons-excel{
    display: none;
}
</style>
@endsection
@section('header')
@include('admin.includes.header')
@endsection
@section('sidebar')
@include('admin.includes.sidebar')
@endsection
@section('content')
<div class="content">
    <div class="wraper container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="pull-left page-title">Personal Info<br/><p class="small_tag">You can find information or view tutor profile in this section  </p></h1>
                <ol class="breadcrumb pull-right">
                    <li> <a href="{{ route('manage.tutors') }}"><i class="fas fa-angle-double-left"></i> Back</a></li>
                    <li> <a href="{{ route('edit.tutor.personal.info.step.1',$user->id) }}"><i class="fas fa-angle-double-left"></i> Edit</a></li>
                </ol>
            </div>
        </div>
        <div class="step_tab">
            <ul>
                <li class="active">
                    <a href="javascript:void(0);" id="clickHere" data-toggle="modal" data-target="#instructionModal" style="display:none;">Click</a>
                    <a href="{{ route('view.tutor.personal.info.step.1',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/peri.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/perih.png') }}" class="accth"></span>
                    Personal Info
                    </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor.tutorship.plans',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/gar.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/garh.png') }}" class="accth"></span>
                    Tutorship Plan
                    </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor.academics',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/aca.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/acah.png') }}" class="accth"></span>
                    Academics
                    </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor.experience',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/ex.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/exh.png') }}" class="accth"></span>
                    Experience </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor.recognitions',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/rec.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/rech.png') }}" class="accth"></span>
                    Recognitions
                    </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/rec.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/rech.png') }}" class="accth"></span>
                    Availabity
                    </a>
                </li>
                <div class="clearfix"></div>
            </ul>
        </div>
        <!-- Personal-Information -->
        <div class="panel panel-default panel-fill">
            <div class="panel-body rm02 rm04">
                @include('admin.includes.message')
                <form id="updatePersonalInfo" method="post" action="{{ route('edit.tutor.personal.info.step.1',@$user->id) }}" enctype="multipart/form-data">
                    @csrf
                    <div class="frm_admin">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="f_name">First Name</label>
                                    <p class="text-muted">{{ @$user->f_name }}</p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="l_name"> Last Name</label>
                                    <p class="text-muted">{{ @$user->l_name }}</p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <p class="text-muted">{{ @$user->email }}</p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="phone">Mobile Number</label>
                                    <p class="text-muted">{{ @$user->phone }}</p>
                                    
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="teacher_emp_status">Employment Status</label>
                                    <p class="text-muted">
                                        @if(@$user->teacher_emp_status == 'A')
                                        Yes, I'm a full-time teacher
                                        @elseif(@$user->teacher_emp_status == 'B')
                                        No, but I have teaching experience
                                        @elseif(@$user->teacher_emp_status == 'C')
                                        Yes, but I'm not a teacher
                                        @elseif(@$user->teacher_emp_status == 'D')
                                        No, but I have passion for teaching
                                        @endif
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="hours">How many hours can you commit?</label>
                                    <p class="text-muted">
                                        @if(@$user->hours == '1-4')
                                        < 5 hrs a week
                                        @elseif(@$user->hours == '5-10')
                                        5 – 10 hrs a week
                                        @elseif(@$user->hours == '10-20')
                                        10 – 20 hrs a week
                                        @elseif(@$user->hours == '20-40')
                                        20 – 40 hrs a week
                                        @elseif(@$user->hours == '40+')
                                        > 40 hrs a week
                                        @endif
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="why_tutor">Why do you want to be a Tutor?</label>
                                    <p class="text-muted">
                                        @if(@$user->why_tutor == 'A')
                                        Leverage my teaching experience
                                        @elseif(@$user->why_tutor == 'B')
                                        Looking for after-hours gig
                                        @elseif(@$user->why_tutor == 'C')
                                        To make more money by teaching
                                        @elseif(@$user->why_tutor == 'D')
                                        Teaching is my passion, money secondary
                                        @elseif(@$user->why_tutor == 'E')
                                        Safe way to make money from home
                                        @endif
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="language">Language</label>
                                    <p class="text-muted">
                                        @foreach(@$tutor_to_lan as $l)
                                        {{ @$l->languageName->language }}
                                        @endforeach
                                    </p>
                                </div>
                            </div>
                            
                            <div class="clearfix"></div>
                            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <div class="checkBox new-cus tur-radio">
                                        <span>Do you have experience working with children?</span>
                                        <p class="text-muted">
                                            @if(@$user->work_with_child == 'Y')
                                            Yes
                                            @else
                                            No
                                            @endif
                                        </p>
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <div class="checkBox new-cus tur-radio">
                                        <span>Do you have a history or pending criminal court cases or charges laid against you?</span>
                                        <p class="text-muted">
                                            @if(@$user->criminal_case == 'Y')
                                            Yes
                                            @else
                                            No
                                            @endif
                                        </p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 tutor-c criminal_details_hide_show">
                                <div class="form-group">
                                    <label for="criminal_details">Share more details</label>
                                    <p class="text-muted">
                                        {{ @$user->criminal_details }}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label for="about_me">What makes you an awesome V-Tutor?</label>
                                    <p class="text-muted">
                                        {!! strip_tags(@$user->about_me) !!}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="uplodimg form-group">
                                    <div class="uplodimgfil">
                                        <span>Profile Picture</span>
                                        
                                        
                                    </div>
                                    <div class="uplodimgfilimg">
                                        <em>

                                            @if(@$user->profile_pic)
                                                <img id="img2" src="{{ URL::to('storage/app/public/teacher_profile_pic/'.@$user->profile_pic) }}" alt="">
                                            @else
                                                @if(@$user->avatar)
                                                    <img id="img2" src="{{@$user->avatar}}" alt="">
                                                @else
                                                    <img id="img2" src="{{ asset('public/admin/assets/images/uplodimg.png') }}" alt="" style="display:none;">
                                                @endif
                                            @endif
                                        </em>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label for="profile_video">Profile Video</label>
                                    <p class="text-muted">
                                        {!! strip_tags(@$user->profile_video) !!}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="user-account-info">
                                    <h3>Residential Address</h3>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="country">Country</label>
                                    <p class="text-muted">
                                        @if(@$user->country == 1)
                                        Australia
                                        @endif
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="state">State / Province / Region</label>
                                    <p class="text-muted">
                                        {{ @$user->getState->state_name }}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="city">City</label>
                                    <p class="text-muted">
                                        {{ @$user->city }}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="address">Unit & Street Address</label>
                                    <p class="text-muted">
                                        {!! strip_tags(@$user->address) !!}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="zip">Zip / Postal Code</label>
                                    <p class="text-muted">
                                        {{ @$user->zip }}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="user-account-info">
                                    <h3>References</h3>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="user-account-info">
                                    <h3>Add Reference 1</h3>
                                </div>
                            </div>

                            
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form_box_area">
                                    <label for="ref_2_name">Name</label>
                                    <p class="text-muted">
                                        {{ @$tutor_to_ref->ref_1_name }}    
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form_box_area">
                                    <label>Email</label>
                                    <p class="text-muted">
                                        {{ @$tutor_to_ref->ref_1_email }}    
                                    </p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form_box_area">
                                    <label>Phone</label>
                                    <p class="text-muted">
                                        {{ @$tutor_to_ref->ref_1_phone }}    
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form_box_area">
                                    <label for="ref_2_relation">Relationship</label>
                                    <p class="text-muted">
                                        @if(@$tutor_to_ref->ref_1_relation == 1)Partner @endif
                                        @if(@$tutor_to_ref->ref_1_relation == 2)Family @endif
                                        @if(@$tutor_to_ref->ref_1_relation == 3)Friend @endif
                                        @if(@$tutor_to_ref->ref_1_relation == 4)Colleague @endif
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="user-account-info">
                                    <h3>Add Reference 2</h3>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form_box_area">
                                    <label for="ref_2_name">Name</label>
                                    <p class="text-muted">
                                        {{ @$tutor_to_ref->ref_2_name }}    
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form_box_area">
                                    <label>Email</label>
                                    <p class="text-muted">
                                        {{ @$tutor_to_ref->ref_2_email }}    
                                    </p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form_box_area">
                                    <label>Phone</label>
                                    <p class="text-muted">
                                        {{ @$tutor_to_ref->ref_2_phone }}    
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form_box_area">
                                    <label for="ref_2_relation">Relationship</label>
                                    <p class="text-muted">
                                        @if(@$tutor_to_ref->ref_2_relation == 1)Partner @endif
                                        @if(@$tutor_to_ref->ref_2_relation == 2)Family @endif
                                        @if(@$tutor_to_ref->ref_2_relation == 3)Friend @endif
                                        @if(@$tutor_to_ref->ref_2_relation == 4)Colleague @endif
                                    </p>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="user-account-info">
                                    <h3>Bank Information</h3>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="zip">Bank Name</label>
                                    <p class="text-muted">
                                        {{ @$user->bank_name }}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="zip">Account No</label>
                                    <p class="text-muted">
                                        {{ @$user->account_no }}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="zip">Account Name</label>
                                    <p class="text-muted">
                                        {{ @$user->account_name }}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="zip">BSB Code</label>
                                    <p class="text-muted">
                                        {{ @$user->bsb_code }}
                                    </p>
                                    
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-sm-12">
                                <div class="ad_btn">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection    
@section('footer')
@include('admin.includes.footer')
@endsection
@section('script')
@include('admin.includes.script')
<script src="{{asset('public/admin/assets/js/jquery.validate.js')}}"></script>

@endsection