@extends('admin.layouts.app')
@section('title')
Student Personal Info
@endsection
@section('links')
@include('admin.includes.links')
        {{-- <link href="{{ asset('public/admin/assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('public/admin/assets/css/semantic.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('public/admin/assets/css/core.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('public/admin/assets/css/icons.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('public/admin/assets/css/responsive.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('public/admin/assets/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">
        <script src="https://kit.fontawesome.com/446e463225.js" crossorigin="anonymous"></script>
        <script src="{{ asset('public/admin/assets/js/modernizr.min.js') }}"></script> --}}
<style type="text/css">
    
</style>
@endsection
@section('header')
@include('admin.includes.header')
@endsection
@section('sidebar')
@include('admin.includes.sidebar')
@endsection
@section('content')
<div class="content">
    <div class="wraper container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="pull-left page-title">Edit Student Personal Info<br/><p class="small_tag">You can find information or edit your profile in this section</p></h1>
                <ol class="breadcrumb pull-right">
                    <li> <a href="{{ route('manage.students') }}"><i class="fas fa-angle-double-left"></i> Back</a></li>
                    <li> <a href="{{ route('view.student',@$user->id) }}"><i class="fas fa-angle-double-left"></i> View</a></li>
                </ol>
            </div>
        </div>
        
        <!-- Personal-Information -->
        <div class="panel panel-default panel-fill">
            <div class="panel-body rm02 rm04">
                @include('admin.includes.message')
                <form id="updateStudentPersonalInfo" method="post" action="{{ route('edit.student.personal.info.step.1',@$user->id) }}" enctype="multipart/form-data">
                    @csrf
                    <div class="frm_admin">
                        <div class="row">
                            
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="f_name">Student First Name*</label>
                                    <input type="text" id="f_name" name="f_name" placeholder="First Name " class="form-control required" value="{{ @$user->f_name }}" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="l_name">Student Last Name*</label>
                                    <input type="text" placeholder="Last Name" id="l_name" name="l_name" class="form-control required" value="{{ @$user->l_name }}" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');"> 
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="grade">Grade</label>
                                    <select class="form-control rm06 " name="grade" id="grade">
                                        <option value="">Select Grade</option>
                                        @if(@$grades)
                                            @foreach(@$grades as $grade)
                                                <option value="{{ @$grade->id }}" @if(@$grade->id == @$user->grade) selected="" @endif>{{ @$grade->grade_name }}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <div class="dash-d1">
                                        <label for="dob">Date of birth *</label>
                                        <div class="ui calendar" id="from_date">
                                            <div class="ui input left icon">
                                              <input type="date" id="dob" name="dob" placeholder="Select Date" class="form-control required" autocomplete="off" readonly="" value="{{ @$user->dob }}" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                                              <span class="over_llp1"><img src="{{ asset('public/admin/assets/images/cal.png') }}" alt=""></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            {{-- <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="dob">Date Of Birth*</label>
                                    <input type="text" class="datepicker form-control required" placeholder="Enter date of birth" id="dob" readonly="" name="dob" value="{{ @$user->dob }}">
                                </div>
                            </div> --}}
                            
                            
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="gender">Gender</label>
                                    <select class="form-control rm06 " name="gender" id="gender">
                                        <option value="">Select Gender</option>
                                        <option value="M" @if(@$user->gender == 'M')  selected=""  @endif>Male</option>
                                        <option value="F" @if(@$user->gender == 'F')  selected=""  @endif>Female</option>
                                        <option value="O" @if(@$user->gender == 'O')  selected=""  @endif>Neither</option>
                                        <option value="P" @if(@$user->gender == 'P')  selected=""  @endif>Prefer not to say</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="school">School</label>
                                    <input type="text" id="school" name="school" placeholder="Where you currently study?" class="form-control " value="{{ @$user->school }}" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <div class="checkBox new-cus tur-radio">
                                        <span>Are you a full-time student? *</span>
                                        <ul>
                                            <li class="one_li_check">
                                                <input type="radio" id="radio1" name="is_full_time" value="Y" @if(@$user->is_full_time == 'Y')  checked=""  @endif onclick="yes()">
                                                <label for="radio1">Yes</label>
                                            </li>
                                            <li>
                                                <input type="radio" id="radio2" name="is_full_time" value="N" @if(@$user->is_full_time == 'N')  checked=""  @endif onclick="no()">
                                                <label for="radio2">No</label>
                                            </li>
                                        </ul>
                                        {{-- <p class="note">Note: A WWC pass is an essential criterion to onboard</p> --}}
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-5 col-md-6 col-sm-12 col-xs-12 tutor-c" @if(@$user->is_full_time == 'N')  checked="" style="display:none;" @endif>
                                <div class="form-group">
                                    <div class="checkBox new-cus tur-radio">
                                        <span>Do you private school or home school?*</span>
                                        <ul>
                                            <li class="one_li_check">
                                                <input type="radio" id="radio3" name="private_or_home" value="Y" class="required private_or_home" @if(@$user->private_or_home == 'Y')  checked=""  @endif >
                                                <label for="radio3">Yes</label>
                                            </li>
                                            <li>
                                                <input type="radio" id="radio4"  name="private_or_home" value="N" @if(@$user->private_or_home == 'N')  checked=""  @endif class="required private_or_home">
                                                <label for="radio4" >No</label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="clearfix"></div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label for="about_me">About the Student</label>
                                    <textarea autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');" minlength="10" id="about_me" name="about_me" placeholder="Write briefly about you, what you like, hobbies and interests in about 200 words" class="from-text">{!! strip_tags(@$user->about_me) !!}</textarea>
                                </div>
                            </div>
                            {{-- <div class="clearfix"></div> --}}
                            {{-- <div class="col-sm-12 col-xs-12">
                                <div class="uplodimg form-group">
                                    <div class="uplodimgfil">
                                        <span>Profile Picture</span>
                                        <input type="file" name="img" id="file-1" class="inputfile inputfile-1" data-multiple-caption="{count} files selected" onchange="fun();">
                                        <label for="file-1">Upload Profile Pic<img src="{{ asset('public/admin/assets/images/up.png') }}" alt=""></label>
                                    </div>
                                    <div class="uplodimgfilimg">
                                        <em>
                                            @if(@$user->profile_pic)
                                            <img id="img2" src="{{ URL::to('storage/app/public/teacher_profile_pic/'.@$user->profile_pic) }}" alt="">
                                            @else
                                            <img id="img2" src="{{ asset('public/admin/assets/images/uplodimg.png') }}" alt="" style="display:none;">
                                            @endif
                                        </em>
                                    </div>
                                </div>
                            </div> --}}
                            {{-- <div class="clearfix"></div> --}}
                            <div class="clearfix"></div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="uplodimg form-group">
                                    <div class="uplodimgfil">
                                        <span>Profile Picture</span>
                                        <input type="file" name="img" id="file-1" class="inputfile inputfile-1 @if(!@$user->profile_pic) @if(!@$user->avatar) required @endif @endif" data-multiple-caption="{count} files selected">
                                        <label for="file-1">Upload Profile Pic<img src="{{ asset('public/admin/assets/images/up.png') }}" alt=""></label>
                                        <span class="error_image error"></span>
                                        {{-- <label data-toggle="modal" class="onhover" data-target="#instructionModal"><p class="" style="padding: 25px;">Please ensure to upload a profile pic that meets the  <a href="javascript:void(0);" style="color:#b80f0a;">standards and requirements </a>of V-Tutor.</p></label> --}}  
                                    </div>
                                    <div class="uplodimgfilimg">
                                        <em>
                                            @if(@$user->profile_pic)
                                                <img id="img2" src="{{ URL::to('storage/app/public/student_profile_pic/'.@$user->profile_pic) }}" alt="">
                                            @else
                                                @if(@$user->avatar)
                                                    <img id="img2" src="{{@$user->avatar}}" alt="">
                                                @else
                                                    <img id="img2" src="{{ asset('public/admin/assets/images/uplodimg.png') }}" alt="" style="display:none;">
                                                @endif
                                            @endif
                                        </em>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <div class="user-account-info">
                                    <h3>Parental Information</h3>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="salutation">Salutation</label>
                                    <select class="form-control rm06 required" name="salutation" id="salutation">
                                        <option value="">Select Salutation</option>
                                        <option value="1" @if(@$user->salutation == '1')  selected=""  @endif>Mr.</option>
                                        <option value="2" @if(@$user->salutation == '2')  selected=""  @endif>Mrs.</option>
                                        <option value="3" @if(@$user->salutation == '3')  selected=""  @endif>Ms.</option>
                                        <option value="4" @if(@$user->salutation == '4')  selected=""  @endif>Dr.</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="parent_f_name">Parent First Name*</label>
                                    <input type="text" id="parent_f_name" name="parent_f_name" class="form-control required" placeholder="First Name" value="{{ @$user->parent_f_name }}" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">  
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="parent_l_name">Parent Last Name*</label>
                                    <input type="text" id="parent_l_name" name="parent_l_name" class="form-control required" placeholder="Last Name" value="{{ @$user->parent_l_name }}" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">  
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="email">Email Address*</label>
                                    <input type="email" id="email" name="email" placeholder="myemailaddress@xyz.com" class="form-control required" value="{{ @$user->email }}" autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="phone">Mobile Number*</label>
                                    <input type="number" class="form-control required" placeholder="0123456789" id="phone" name="phone" value="{{ @$user->phone }}" minlength="10" maxlength="10" onkeypress='validate(event)' autocomplete="off" onfocus="this.removeAttribute('readonly');" readonly="" onclick="this.removeAttribute('readonly');" onblur="this.removeAttribute('readonly');">
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12  ">
                                <div class="form-group">
                                    <label for="annual_income">Annual Income<span tooltip="This is an optional choice used demographic analysis only. It is not shared with any third party and will not make a difference to services offered in the platform"><i class="qus-cir far fa-question-circle"></i></span></label>
                                    <select name="annual_income" id="annual_income" class="form-control ">
                                        <option value="A" @if(@$user->annual_income == 'A') selected="" @endif>&lt; 100,000</option>
                                        <option value="B" @if(@$user->annual_income == 'B') selected="" @endif>100,000 – 150,000</option>
                                        <option value="C" @if(@$user->annual_income == 'C') selected="" @endif>150,000 –200,000</option>
                                        <option value="D" @if(@$user->annual_income == 'D') selected="" @endif> 200,000 &gt;</option>
                                        <option value="P" @if(@$user->annual_income == 'P') selected="" @endif>Prefer not to say</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label for="qualification">Qualification*</label>
                                    <select class="form-control  rm06 required" name="qualification" id="qualification">
                                        <option value="">Select Qualification</option>
                                        <option value="1" @if(@$user->qualification == "1") selected="" @endif>Doctoral Degree</option>
                                        <option value="2" @if(@$user->qualification == "2") selected="" @endif>Postgraduate</option>
                                        <option value="3" @if(@$user->qualification == "3") selected="" @endif>Master's Degree (Research)</option>
                                        <option value="4" @if(@$user->qualification == "4") selected="" @endif>Master's Degree</option>
                                        <option value="5" @if(@$user->qualification == "5") selected="" @endif>Bachelor Honours Degree</option>
                                        <option value="6" @if(@$user->qualification == "6") selected="" @endif>Bachelor’s Degree</option>
                                        <option value="7" @if(@$user->qualification == "7") selected="" @endif>Associate Degree</option>
                                        <option value="8" @if(@$user->qualification == "8") selected="" @endif>Advanced Diploma</option>
                                        <option value="9" @if(@$user->qualification == "9") selected="" @endif>Diploma</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="clearfix"></div>
                            
                            <div class="col-sm-12">
                                <div class="ad_btn">
                                    <button class="btn btn-primary waves-effect waves-light w-md c_save_edit_student_personal_info" id="save_edit_student_personal_info" type="button">Save</button> 
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection    
@section('footer')
@include('admin.includes.footer')
@endsection
@section('script')
@include('admin.includes.script')
<script type="text/javascript">
    var isvalidator = $('#updateStudentPersonalInfo').validate({
            rules: {
                f_name: { 
                    required: true
                },
                l_name: { 
                    required: true
                },
                phone:{
                    required:true,
                    number:true,
                    remote:{
                        url:"{{route('ajax.tutor.duplicate.phone.check')}}",
                        type:"POST",
                        data: {
                            grade_name: function() {
                                return $("#phone").val();
                            },
                            id: function() {
                                return {{ @$user->id }};
                            },
                            _token: '{{ csrf_token() }}'
                        }
                    }
                },
                email:{
                    required:true,
                    email:true,
                    remote:{
                        url:"{{route('ajax.tutor.duplicate.email.check')}}",
                        type:"POST",
                        data: {
                            grade_name: function() {
                                return $("#email").val();
                            },
                            id: function() {
                                return {{ @$user->id }};
                            },
                            _token: '{{ csrf_token() }}'
                        }
                    }
                }
            },
            messages: {
                email:{
                   remote:'Email-id has already been taken'  
                },
                phone:{
                   remote:'Phone no has already been taken'  
                }
            }
        });
    $("#save_edit_student_personal_info").click(function(){
        if(isvalidator.form()){
        if(isvalidator.valid()){
            var obj = $("#save_edit_student_personal_info"),
            tId = obj.attr("id"),
            tName = "c_save_edit_student_personal_info",
            tFrmId = "updateStudentPersonalInfo";
            $("#type_popup_next").val("R");
            isAuthorizedByAdmin(tName,tId,tFrmId);
        }else{
            $('#instructionModal').modal('hide');
        } 
        } 
        
    });
    function yes(){
        $(".tutor-c").hide(); 
    }
    function no(){
      $(".tutor-c").show(); 
    }
    $(document).ready(function(){
        $("#from_date").calendar({
            type: 'date',
            maxDate:new Date(),
            formatter: {
                date: function (date, settings) {
                    if (!date) return '';
                    var day = date.getDate() + '';
                    if (day.length < 2) {
                        day = '0' + day;
                    }
                    var month = (date.getMonth() + 1) + '';
                    if (month.length < 2) {
                        month = '0' + month;
                    }
                    var year = date.getFullYear();
                    return year + '-' + month + '-' + day;
                }
            }
        });
//         $('#example2').calendar({
//   type: 'date'
// });
        // $(".datepicker").datepicker({dateFormat: "yy-mm-dd",
        //     defaultDate: new Date(),
        //     // minDate: new Date(),
        //     changeMonth: true,
        //     changeYear: true,
        //     yearRange: '-100:+0'
        // });
        
        $(document).on("change","#file-1",function(){
            var i=document.getElementById('file-1').files[0];
            var b=URL.createObjectURL(i);
            // $(".review_img").show();
            $("#img2").show();
            $("#img2").attr("src",b);
        });
        
        $("#about_me").on('keyup', function() {
            var words = 0;
            if((this.value.match(/\S+/g)) != null) {
                words = this.value.match(/\S+/g).length;
            }
            if(words > 200){
                var trimmed = $(this).val().split(/\s+/, 200).join(" ");
                $(this).val(trimmed + " ");
            }
        });
    });
</script>
<script type="text/javascript">
    function checkDob(){
        
    }
    function fun(){
        var i=document.getElementById('file-1').files[0];
        var b=URL.createObjectURL(i);
        $(".review_img").show();
        $("#img2").show();
        $("#img2").attr("src",b);
    }
    function validate(evt) {
        var theEvent = evt || window.event;
          // Handle paste
          if (theEvent.type === 'paste') {
              key = event.clipboardData.getData('text/plain');
          } else {
          // Handle key press
          var key = theEvent.keyCode || theEvent.which;
          key = String.fromCharCode(key);
      }
      var regex = /[0-9]/;
      if( !regex.test(key) ) {
        theEvent.returnValue = false;
        if(theEvent.preventDefault) theEvent.preventDefault();
    }
    
</script>
@endsection