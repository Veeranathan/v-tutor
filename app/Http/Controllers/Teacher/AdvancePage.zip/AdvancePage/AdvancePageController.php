<?php

namespace App\Http\Controllers\Teacher\AdvancePage;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\User;
use App\Models\State;
use App\Models\Grade;
use App\Models\Subject;
use App\Models\TutorshipPlan;
use App\Models\TutorExperience;
use App\Models\TutorRecognision;
use App\Models\TutorAcademic;
use App\Models\University;
use App\Models\FieldOfStudy;
use App\Models\ExpToSubject;
use App\Models\LangToTutor;
use App\Models\Language;
use App\Models\TutorToRef;
use App\Models\TimezoneLists;
use App\Models\Branch;
use App\Models\Nationality;
use Validator;

class AdvancePageController extends Controller
{
    //
    public function myAdvancePage(Request $request){
        $data['teacher']=User::where('id',Auth()->user()->id)->first();
        $data['tutor_to_ref']=TutorToRef::where('tutor_id',Auth()->user()->id)->first();
        $data['state']=State::orderBy('id','asc')->get();
        $data['lan']=Language::orderBy('id')->get();
        $data['tutor_to_lan']=LangToTutor::where('tutor_id',Auth()->user()->id)->get();
        $data['timezonesLists']=TimezoneLists::get();
        $data['nationalities']=Nationality::get();
        return view('teacher.modules.advance_page.advance_page')->with($data);
    }
    public function updatemyAdvancePage(Request $request){
        
        $request->validate([
            'nationality_id'                => 'required',
            'visa_type'                     => 'required',
            'id_proof_type'                 => 'required',
            'residence_id_proof_type'       => 'required',
            'visa_expiry'                   => 'required',
            // 'residence_proof'               => 'required',
            // 'id_proof'               => 'required',
            'bank_name'                     => 'required',
            'account_no'                    => 'required',
            'bsb_code'                      => 'required',
            'account_name'                  => 'required',
            'ref_1_f_name'                  => 'required',
            'ref_1_l_name'                  => 'required',
            'ref_1_email'                   => 'required|email', 
            'ref_1_phone'                   => 'required',
            'ref_2_f_name'                  => 'required',
            'ref_2_l_name'                  => 'required',
            'ref_2_email'                   => 'required|email',
            'ref_2_phone'                   => 'required'
        ]);
        if(!@Auth::user()->id_proof){
            $request->validate([
                'nationality_id'                => 'required',
                'visa_type'                     => 'required',
                'id_proof_type'                 => 'required',
                'residence_id_proof_type'       => 'required',
                'visa_expiry'                   => 'required',
                // 'residence_proof'               => 'required',
                'id_proof'               => 'required',
                'bank_name'                     => 'required',
                'account_no'                    => 'required',
                'bsb_code'                      => 'required',
                'account_name'                  => 'required',
                'ref_1_f_name'                  => 'required',
                'ref_1_l_name'                  => 'required',
                'ref_1_email'                   => 'required|email', 
                'ref_1_phone'                   => 'required',
                'ref_2_f_name'                  => 'required',
                'ref_2_l_name'                  => 'required',
                'ref_2_email'                   => 'required|email',
                'ref_2_phone'                   => 'required'
            ]);
        }
        if(!@Auth::user()->residence_proof){
            $request->validate([
                'nationality_id'                => 'required',
                'visa_type'                     => 'required',
                'id_proof_type'                 => 'required',
                'residence_id_proof_type'       => 'required',
                'visa_expiry'                   => 'required',
                'residence_proof'               => 'required',
                // 'id_proof'               => 'required',
                'bank_name'                     => 'required',
                'account_no'                    => 'required',
                'bsb_code'                      => 'required',
                'account_name'                  => 'required',
                'ref_1_f_name'                  => 'required',
                'ref_1_l_name'                  => 'required',
                'ref_1_email'                   => 'required|email', 
                'ref_1_phone'                   => 'required',
                'ref_2_f_name'                  => 'required',
                'ref_2_l_name'                  => 'required',
                'ref_2_email'                   => 'required|email',
                'ref_2_phone'                   => 'required'
            ]); 
        }
        if(@$request->id_proof){
            $unlnk=User::where('id',auth()->user()->id)->first();
            @$prev_img = $unlnk->id_proof;
            if(@$prev_img){               
                @unlink('storage/app/public/id_proof/'.$prev_img);
            }
            //this is for upload 
            $image = $request->id_proof;
            $profile = time() . '-' . rand(1000, 9999) . '.' . $image->getClientOriginalExtension();
            $image->move("storage/app/public/id_proof",$profile);
            $user_pic_update=User::where('id',Auth()->user()->id)->update(['id_proof'=>$profile]);
        }
        if(@$request->residence_proof){
            $unlnk=User::where('id',auth()->user()->id)->first();
            @$prev_img = $unlnk->residence_proof;
            if(@$prev_img){               
                @unlink('storage/app/public/residence_proof/'.$prev_img);
            }
            //this is for upload 
            $image = $request->residence_proof;
            $profile = time() . '-' . rand(1000, 9999) . '.' . $image->getClientOriginalExtension();
            $image->move("storage/app/public/residence_proof",$profile);
            $user_pic_update=User::where('id',Auth()->user()->id)->update(['residence_proof'=>$profile]);
        }
        $isTutorToRef = TutorToRef::where(['tutor_id'=>Auth()->user()->id])->first();
        if(@$isTutorToRef){
            $updTutorToRef['ref_1_f_name'] = @$request->ref_1_f_name;
            $updTutorToRef['ref_1_l_name'] = @$request->ref_1_l_name;
            $updTutorToRef['ref_1_email'] = @$request->ref_1_email;
            $updTutorToRef['ref_1_phone'] = @$request->ref_1_phone;
            $updTutorToRef['ref_1_relation'] = @$request->ref_1_relation;
            $updTutorToRef['ref_2_f_name'] = @$request->ref_2_f_name;
            $updTutorToRef['ref_2_l_name'] = @$request->ref_2_l_name;
            $updTutorToRef['ref_2_email'] = @$request->ref_2_email;
            $updTutorToRef['ref_2_phone'] = @$request->ref_2_phone;
            $updTutorToRef['ref_2_relation'] = @$request->ref_2_relation;
            TutorToRef::where(['tutor_id'=>Auth()->user()->id])->update($updTutorToRef);
        }else{
            $updTutorToRef['tutor_id'] = Auth()->user()->id;
            $updTutorToRef['ref_1_f_name'] = @$request->ref_1_f_name;
            $updTutorToRef['ref_1_l_name'] = @$request->ref_1_l_name;
            $updTutorToRef['ref_1_email'] = @$request->ref_1_email;
            $updTutorToRef['ref_1_phone'] = @$request->ref_1_phone;
            $updTutorToRef['ref_1_relation'] = @$request->ref_1_relation;
            $updTutorToRef['ref_2_f_name'] = @$request->ref_2_f_name;
            $updTutorToRef['ref_2_l_name'] = @$request->ref_2_l_name;
            $updTutorToRef['ref_2_email'] = @$request->ref_2_email;
            $updTutorToRef['ref_2_phone'] = @$request->ref_2_phone;
            $updTutorToRef['ref_2_relation'] = @$request->ref_2_relation;
            $tutorCrt = TutorToRef::create($updTutorToRef);
        }
        $upd['nationality_id'] = @$request->nationality_id;
        $upd['visa_type'] = @$request->visa_type;
        $upd['id_proof_type'] = @$request->id_proof_type;
        $upd['residence_id_proof_type'] = @$request->residence_id_proof_type;
        $upd['visa_expiry'] = @$request->visa_expiry;
        $upd['bank_name'] = @$request->bank_name;
        $upd['bsb_code'] = @$request->bsb_code;
        $upd['account_no'] = @$request->account_no;
        $upd['account_name'] = @$request->account_name;
        $upd['visa_expiry'] = @$request->visa_expiry;
        $upd['draft'] = 'N';
        User::where(['id'=>@Auth::user()->id])->update($upd);
        return back()->with('success','Your profile is updated');
    }
}
