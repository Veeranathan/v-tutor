<!-- footer -->
<footer class="footer_sec login-footer">
	<div class="foot_top">
		<div class="container">
			<div class="foot_top_inr">
				<div class="row">
					<div class="col-sm-3">
						<div class="foot_bx">
							<h4>Quick links</h4>
							<ul>
								<li><a href="{{route('landing.page')}}">Home</a></li>
								<li><a href="#url">About us</a></li>
								<li><a href="#url">Message us</a></li>
								<li><a href="#url">FAQ</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						
						<div class="foot_bx">
							<h4>For Students</h4>
							<ul>
								@if(!@Auth::user()->id)
								<li><a href="{{route('login')}}">Log me in</a></li>
								<li><a href="#url">Book my class</a></li>
								<li><a href="#url">Find a Tutor</a></li>
								<li><a href="#url">My classes</a></li>
								<li><a href="#url">My Profile</a></li>
								@else
								<li><a href="#url">Book my class</a></li>
								<li><a href="#url">Find a Tutor</a></li>
								<li><a href="#url">My classes</a></li>
								<li><a href="#url">My Profile</a></li>
								@endif
							</ul>
						</div>
						
					</div>
					<div class="col-sm-3">
						<div class="foot_bx">
							<h4>For Tutors</h4>
							<ul>@if(!@Auth::user()->id)
								<li><a href="{{route('login')}}">Log me in</a></li>
								<li><a href="{{route('reg.home')}}">Sign me up</a></li>
								<li><a href="{{route('tutor.myclass')}}">My classes</a></li>
								<li><a href="{{route('teacher.profile')}}">My Profile</a></li>
								<li><a href="{{route('tutor.availability')}}">My availability</a></li>
								@else
								<li><a href="{{route('tutor.myclass')}}">My classes</a></li>
								<li><a href="{{route('teacher.profile')}}">My Profile</a></li>
								<li><a href="{{route('tutor.availability')}}">My availability</a></li>
								@endif
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="foot_bx">
							<h4>Follow us</h4>
							<ul>
								<li>Email :  <a href="mailto:hello@v-tutor.com.au">hello@v-tutor.com.au</a></li>
							</ul>
							</div>								
							<div class="foot_sos_box">
							<ul>
								<li>
									<a href="#url" target="_blank">
									<i class="foot_sos"><img src="{{url('/')}}/public/assets/images/footsos1.png" alt="" /></i>
									<i class="foot_sos_hov"><img src="{{url('/')}}/public/assets/images/footsos11.png" alt="" /></i>
									</a>									
								</li>
								<li>
									<a href="#url" target="_blank">
									<i class="foot_sos"><img src="{{url('/')}}/public/assets/images/footsos2.png" alt="" /></i>
									<i class="foot_sos_hov"><img src="{{url('/')}}/public/assets/images/footsos22.png" alt="" /></i>
									</a>									
								</li>
								<li>
									<a href="#url" target="_blank">
									<i class="foot_sos"><img src="{{url('/')}}/public/assets/images/footsos3.png" alt="" /></i>
									<i class="foot_sos_hov"><img src="{{url('/')}}/public/assets/images/footsos33.png" alt="" /></i>
									</a>									
								</li>
								<li>
									<a href="#url" target="_blank">
									<i class="foot_sos"><img src="{{url('/')}}/public/assets/images/footsos4.png" alt="" /></i>
									<i class="foot_sos_hov"><img src="{{url('/')}}/public/assets/images/footsos44.png" alt="" /></i>
									</a>									
								</li>
								<li>
									<a href="#url" target="_blank">
									<i class="foot_sos"><img src="{{url('/')}}/public/assets/images/footsos5.png" alt="" /></i>
									<i class="foot_sos_hov"><img src="{{url('/')}}/public/assets/images/footsos55.png" alt="" /></i>
									</a>									
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="foot_botm">
		<div class="container">
			<div class="foot_botm_inr">
				<div class="foot_botm_left">
					<ul>
						<li>Copyright © 2021 <a href="#url">V-Tutor.com.au</a>   <span>|</span> All Rights Reserved </li>
					</ul>
				</div>
				<div class="foot_botm_right">
					<ul>
						<li><a href="#url">Terms & Conditions </a> <span class="shal">/</span></li>
						<li><a href="#url">Privacy Policy</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	
</footer>

<div class="foot_arw fixed">
	<a href="javascript:" id="return-to-top"><img src="{{url('/')}}/public/assets/images/foot_ar_bot.png" alt=""></a>
</div>