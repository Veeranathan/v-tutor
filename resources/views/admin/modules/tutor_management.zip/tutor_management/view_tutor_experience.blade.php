@extends('admin.layouts.app')
@section('title')
My Experience
@endsection
@section('links')
@include('admin.includes.links')
<link rel="stylesheet" type="text/css" href="{{ asset('public/admin/assets/libs/css/chosen.css') }}">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/fixedcolumns/3.2.1/css/fixedColumns.dataTables.min.css"/>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<style type="text/css">
/*this is excel button needs to hide as we have already download option*/
.buttons-excel{
    display: none;
}
</style>
@endsection
@section('header')
@include('admin.includes.header')
@endsection
@section('sidebar')
@include('admin.includes.sidebar')
@endsection
@section('content')
<div class="content">
    <div class="wraper container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="pull-left page-title">My Experience<br/><p class="small_tag">You can find information or view tutor profile in this section  </p></h1>
                <ol class="breadcrumb pull-right">
                    <li> <a href="{{ route('manage.tutors') }}"><i class="fas fa-angle-double-left"></i> Back</a></li>
                    <li> <a href="{{ route('edit.tutor.experience',$user->id) }}"><i class="fas fa-angle-double-left"></i> Edit Experience</a></li>
                </ol>
            </div>
        </div>
        <div class="step_tab">
            <ul>
                <li class="">
                    <a href="{{ route('view.tutor.personal.info.step.1',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/peri.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/perih.png') }}" class="accth"></span>
                    Personal Info
                    </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor.tutorship.plans',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/gar.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/garh.png') }}" class="accth"></span>
                    Tutorship Plan
                    </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor.academics',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/aca.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/acah.png') }}" class="accth"></span>
                    Academics
                    </a>
                </li>
                <li class="active">
                    <a href="{{ route('view.tutor.experience',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/ex.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/exh.png') }}" class="accth"></span>
                    Experience </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor.recognitions',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/rec.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/rech.png') }}" class="accth"></span>
                    Recognitions
                    </a>
                </li>
                <li>
                    <a href="{{ route('view.tutor',$user->id) }}">
                    <span><img src="{{ asset('public/admin/assets/images/rec.png') }}" class="actt"><img src="{{ asset('public/admin/assets/images/rech.png') }}" class="accth"></span>
                    Availabity
                    </a>
                </li>
                <div class="clearfix"></div>
            </ul>
        </div>
        <!-- Personal-Information -->
        <div class="panel panel-default panel-fill">
            <div class="panel-body rm02 rm04">
                @include('admin.includes.message')

                    <div class="frm_admin">
                        <div class="row">
                            <div class="centerButtons">
                                
                                <div class="rm05 rightButtons">
                                <button class="btn btn-primary waves-effect waves-light w-md download" id="download" type="button">Download </button>
                            </div>
                            <div class="clearfix"></div>
                            
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped" id="example">
                                        <thead>
                                            <tr>
                                                <th>Organization </th>
                                                <th>Job Title</th>
                                                <th>Year Of Experience</th>    
                                                <th>From Year</th>    
                                                <th>To Year</th>    
                                                <th>Description</th>
                                                <th>Subject Taught</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                
            </div>
        </div>

    </div>
</div>
@endsection    
@section('footer')
@include('admin.includes.footer')
@endsection
@section('script')
@include('admin.includes.script')
<script src="{{asset('public/admin/assets/js/jquery.validate.js')}}"></script>
<script src="{{ asset('public/admin/assets/libs/js/chosen.jquery.min.js') }}"></script>
<script src="{{url('/')}}/public/assets/js/chosen.jquery.js" type="text/javascript"></script>
<script src="{{url('/')}}/public/assets/js/init.js" type="text/javascript"></script>
{{-- for datatable --}}
{{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script> --}}
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
{{-- for validation --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
{{-- <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script> --}}
<script type="text/javascript">
$("#example_filter").hide();
$(document).ready(function(){
    $.validator.setDefaults({ ignore: ":hidden:not(.slct)" });
    $(document).on("click",".action",function(){
        var id = $(this).data("key");
        $("#show-action"+id).slideToggle();
    });
    var isvalidator = $('#edit_tutor_experience').validate({
        rules: {
            grade_id: { required: true},
            hourly_rate: { required: true,number:true},
        },
        submitHandler:function(form){
           form.submit();
        },
    });
    $("#edit_tutor_experience_button").click(function(){
        if(isvalidator.valid()){
            var obj = $("#edit_tutor_experience_button"),
            tId = obj.attr("id"),
            tName = "c_edit_tutor_experience_button",
            tFrmId = "edit_tutor_experience";
            $("#type_popup_next").val("R");
            isAuthorizedByAdmin(tName,tId,tFrmId);
        }else{
            $('#instructionModal').modal('hide');
        }    
    });
    $('.slct').chosen();
    function filterColumn ( i ) {
        $('#example').DataTable().column( i ).search(
            $('#col'+i+'_filter').val(),
        ).draw();
    }
    var dataTableObj = {
        // dom: 'Bfrtip',
        // dom: "<div class='table-res'></div>"+'p'+'B',
        // buttons: [
        //     {
        //         extend: 'excelHtml5',
        //         exportOptions: {
        //             columns: [ 0, 1,2,3,4,5,6 ]
        //         }
        //     },
        //     'colvis'
        // ],
        stateSave: true,
        // "pageLength":2,
        "order": [
            [0, "desc"]
        ],
        "stateLoadParams": function (settings, data) {
            // $('#col1_filter').val(data.search.grade_name);  
        },
        stateSaveParams: function (settings, data) { 
            // data.search.grade_name = $('#col1_filter').val();
        },
        "processing": true,
        "serverSide": true,
        'serverMethod': 'post',
        "createdRow": function( row, data, dataIndex ) { 
            var id = (JSON.stringify(data.id)),
            r = JSON.stringify(dataIndex);
            $(row).addClass("tr_class_"+id);
            $(row).addClass("tr_row_class");
            $(row).children(':nth-child(8)').addClass('rm07');
            $(row).children(':nth-child(8)').attr('data-id',r);
        },
        "ajax": {
            "url": "{{ route('manage.exp.data',@$user->id) }}",
            "data": function ( d ) {
                console.log(d);
                d.myKey = "myValue";
                d._token = "{{ @csrf_token() }}";
            },
            error: function (jqXHR, textStatus, errorThrown) {
                // Do something here
                console.log("'error in datatable");
            }
        },
        'columns': [
        { 
            data: "organization",
            render: function(data, type, full, meta){
                if(data != null){
                    return data;
                }else{
                    return "";
                } 
                
            }
        },
        { 
            data: "job_title",
            render: function(data, type, full, meta){    
                if(data != null){
                    return data;
                }else{
                    return "";
                }
            }
        },
        { 
            data: "year_of_exp",
            render: function(data, type, full, meta){  
                if(data != null){
                    return data;
                }else{
                    return "";
                }
            }
        },
        { 
            data: "from_year",
            render: function(data, type, full, meta){  
                if(data != null){
                    return data;
                }else{
                    return "";
                }
            }
        },
        { 
            data: "to_year",
            render: function(data, type, full, meta){  
                if(data != null){
                    return data;
                }else{
                    return "";
                }
            }
        },
        { 
            data: "description",
            render: function(data, type, full, meta){ 
                if(data != null){
                    return data;
                }else{
                    return "";
                }
            }
        },
        { 
            data: "id",
            render: function(data, type, full, meta){ 
                var length = full.get_exp_to_sub.length;
                if(length>0){
                    var subjects = "";
                    for(var i=0;i<length;i++){
                        subjects = subjects+" "+full.get_exp_to_sub[i].subject_name.subject;
                    }
                    return subjects;
                }else{
                    return "";
                }
            }
        },
        ]
    };
    var table = dataTableCall(dataTableObj,"example");
    // var table = $('#example').DataTable(
     
    // );
    $('.year_dropdown').calendar({
      type: 'year'
    });
    $("#example_filter").hide();
    $("#description").on('keyup', function() {
        var words = 0;
        if((this.value.match(/\S+/g)) != null) {
            words = this.value.match(/\S+/g).length;
        }
        if(words > 100){
            var trimmed = $(this).val().split(/\s+/, 100).join(" ");
            $(this).val(trimmed + " ");
        }
    });
    $(document).on("blur","#to_year",function(){
        var to_year = parseInt($.trim($("#to_year").val()));
        var from_year = parseInt($.trim($("#from_year").val()));
        if(to_year < from_year){
            $(this).val("");
            $(".error_from_year").html("From year cannot be greater than to year!");
            $(".error_to_year").html("From year cannot be greater than to year!");
        }else{
            var year_of_exp = to_year - from_year;
            $("#year_of_exp").val(year_of_exp);
        }

    });
    $(document).on("blur","#from_year",function(){
        var to_year = parseInt($.trim($("#to_year").val()));
        var from_year = parseInt($.trim($("#from_year").val()));
        if(to_year < from_year){
            $(this).val("");
            $(".error_to_year").html("From year cannot be greater than to year!");
            $(".error_from_year").html("From year cannot be greater than to year!");
        }else{
            var year_of_exp = to_year - from_year;
            $("#year_of_exp").val(year_of_exp);
        }

    });
    $(document).on("click",".delete_tutor_experience",function(e){
        var targetId = $(this).attr("id");
            $("#tId").val(targetId);
            $("#type_popup_next").val("A");
            $("#ajax_url").val("{{ route('ajax.delete.experience') }}");
            $('#instructionModal').modal('show');
            var id = $(e.currentTarget).data("id"),
            obj = $(this),
            reqData = {
                'jsonrpc' : '2.0',                
                '_token'  : '{{csrf_token()}}',
                'data'    : {
                    'id'    : id
                }
            },
            temp = table.row('.tr_class_'+id).data();
            $("#data_table_data_s").val(table);
            $("#ajax_data_id").val(id);
        // var id = $(e.currentTarget).data("id"),
        // obj = $(this),
        // reqData = {
        //     'jsonrpc' : '2.0',                
        //     '_token'  : '{{csrf_token()}}',
        //     'data'    : {
        //         'id'    : id
        //     }
        // },
        // temp = table.row('.tr_class_'+id).data();
        // if(confirm("Do you want to delete this experience?")){
        //     $.ajax({
        //         url:"{{ route('ajax.delete.experience') }}",
        //         dataType: 'json',
        //         data: reqData,
        //         type: 'post',
        //         success:function(resp){
        //             if(resp.status == 1){
        //                 table.row('.tr_class_'+id).remove().draw( false );
        //                 toastr.success(resp.message);
        //             }else{
        //                 toastr.error(resp.message);
        //             }
        //         },
        //         error:function(){
        //             toastr.error("Something went wrong!Ajax error!");
        //         }
        //     });
        // }
    });
    $("#download").click(function(){
            $(".buttons-excel").trigger("click");
        });
    // $("#example_wrapper div").eq(0).addClass("table-res");
    $("#example_info").remove();
        $("#example_length").remove();
});
</script>
@endsection