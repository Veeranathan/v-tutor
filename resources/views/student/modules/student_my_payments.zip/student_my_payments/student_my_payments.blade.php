@extends('layouts.app')
@section('title')
<title>V-tutor | Student | My Payments </title>
@endsection
@section('left_part')
@include('include.student_top_common')
{{-- for datatable --}}
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
@endsection
<body class="after-user">
    @section('content')
    <!-- bannersec -->
    <div class="top_mar"></div>
    <!--- profile --->
    <section class="user-account">
        <div class="container">
        <div class="row">
            <div class="zin">
                @include('include.student_left_common'){{-- left common part --}}
                <div class="user-right-panel">
                    <div class="user-right-top-new ">
                        {{-- @include('include.errors') --}}
                        <h2 class="profile-heading">My Payments </h2>
                        <p>You can find information about your payments in this section</p>
                    </div>
                    <form method="get" action="{{route('student.ga.my.payments')}}" id="frm">
                    <div class="class-feild">
                        
                            <div class="row new_rows no-gutters">
                                <div class="col-sm-6">
                                    <div class="form_box_area">
                                        <div class="dash-d1" data-column="1">
                                            <label>From Date</label>
                                            <div class="ui calendar" id="from">
                                                <div class="ui input left icon">
                                                    <input type="text" placeholder="Select date" id="col1_filter" name="from_date" autocomplete="off" class="reset_val">
                                                    <span class="over_llp1"><img src="{{url('/')}}/public/assets/images/cal.png" alt=""></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="dash-d1" data-column="2">
                                            <label>To Date</label>
                                            <div class="ui calendar" id="to">
                                                <div class="ui input left icon">
                                                    <input type="text" placeholder="Select date" id="col2_filter" name="to_date" autocomplete="off" class="reset_val">
                                                    <span class="over_llp1"><img src="{{url('/')}}/public/assets/images/cal.png" alt=""></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <a href="javascript:void(0);"  class="dash-btn rest_btn2 search_click @if(@$tot_payments <= 0) addDisablePhone pointerEventsNone @endif"><img src="{{ asset('public/assets/images/ser.png') }}">Search</a>
                                    {{-- <button class="dash-btn search_click"> <img src="{{url('/')}}/public/assets/images/ser.png"> Search </button> --}}
                                </div>
                                <div class="col-sm-2">
                                    <a href="javascript:void(0)"  class="dash-btn rest_btn2 reset_search">Reset </a>
                                    {{-- <a href="{{ route('student.my.payments') }}"  class="dash-btn rest_btn2"><img src="{{ asset('public/assets/images/ser.png') }}">Reset Search</a> --}}
                                </div>
                            </div>
                        
                    </div>
                    <div class="user-right-top-new">
                        <div class="main-tabels">
                            <!-- Nav tabs -->
                            <div class="tab-rii">
                                {{-- 
                                <div class="float-right">
                                    <form method="post" action="{{route('student.class.export')}}">
                                        @csrf
                                        <input type="hidden" name="session" value="present">
                                        <input type="hidden" name="status" value="{{request('status')}}">
                                        <button class="deen" type="submit">Download</button>
                                    </form>
                                </div>
                                --}}
                            </div>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="today">
                                    <div class="float-right">
                                            
                                            {{-- <a href="#" class="deen" id="download_my_payments">Download</a> --}}
                                            <button class="deen" type="submit">Download</button>
                                        
                                        {{-- <a href="#" class="deen" id="download_my_payments">Download</a> --}}
                                    </div>
                                    <div class="custom-table">
                                        {{-- start --}}
                                        <table id="example" class="cell-border table table-responsive">
                                            <thead>
                                                <tr>
                                                    <th >Booking ID <img src="{{url('/')}}/public/assets/images/sort.png"></th>
                                                    <th >Date <img src="{{url('/')}}/public/assets/images/sort.png"></th>
                                                    <th >Grade <img src="{{url('/')}}/public/assets/images/sort.png"></th>
                                                    <th >Subject <img src="{{url('/')}}/public/assets/images/sort.png"></th>
                                                    <th >Tutor <img src="{{url('/')}}/public/assets/images/sort.png"></th>
                                                    
                                                    <th >Amount <img src="{{url('/')}}/public/assets/images/sort.png"></th>
                                                    {{-- <th >Transaction ID <img src="{{url('/')}}/public/assets/images/sort.png"></th> --}}
                                                    {{-- <th >Invoice ID<img src="{{url('/')}}/public/assets/images/sort.png"></th> --}}
                                                    {{-- <th></th> --}}
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {{-- @if(@$myPayments)
                                                @foreach(@$myPayments as $key=> $val)
                                                <tr>
                                                    <td data-label="Name">
                                                        {{@$val->booking_no}}
                                                    </td>
                                                    <td data-label="Name"> {{date('Y.m.d', strtotime(@$val->booking_date))}}</td>
                                                    <td data-label="Name">{{@$val->getStudentGrade->grade_name}}</td>
                                                    <td data-label="Name">{{@$val->getSubject->subject}}</td>
                                                    <td data-label="Name">{{@$val->getTutor->f_name}}  {{@$val->getTutor->l_name}}</td>
                                                    <td data-label="Name">
                                                        ${{@$val->booking_amount}}
                                                    </td>
                                                    <td data-label="Name">
                                                        {{@$val->getPaymentsInfo->txn_id}}
                                                    </td>
                                                    <td data-label="Name">
                                                        {{@$val->getPaymentsInfo->invoice_id}}
                                                    </td>
                                                    <td>
                                                        <div class="add_ttrr actions-main">
                                                            <a href="javascript:void(0);" class="action-dots"  id="action{{$val->id}}"><img src="{{url('/')}}/public/assets/images/action-dots.png" alt="" onclick="fun({{$val->id}})"></a>
                                                            <div class="show-actions" id="show-action{{$val->id}}" style="display: none;">
                                                                <span class="angle"><img src="{{url('/')}}/public/assets/images/angle.png" alt=""></span>
                                                                <ul>
                                                                    <li><a href="#">Download Invoice</a></li>
                                                                </ul>
                                                            </div>
                                                            
                                                        </div>
                                                    </td>
                                                </tr>
                                                @endforeach
                                                @endif --}}
                                            </tbody>
                                        </table>
                                        </div>
                                    </div>
                                    {{-- end --}}
                                </div>
                                {{-- table panel end --}}
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </section>
    @endsection
    @section('footer')
    @include('include.footer')
    @endsection
    @section('script')
    @include('include.script')
    <script src="{{url('/')}}/public/assets/js/chosen.jquery.js" type="text/javascript"></script>
    <script src="{{url('/')}}/public/assets/js/init.js" type="text/javascript"></script>
    {{-- for datatable --}}
    {{-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script> --}}
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
    {{-- for validation --}}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script>
    
    <script type="text/javascript">
        function filterColumn ( i ) {
            $('#example').DataTable().column( i ).search(
                $('#col'+i+'_filter').val(),
            ).draw();
        }
        // oTable = $('#example').DataTable({  
        // "pageLength":10,
        // "order": [
        //         [0, "desc"]
        // ]
        // });
        // student.g.my.payments
        var oTable = $('#example').DataTable({
            stateSave: false,
            // "pageLength":2,
            "order": [
                [2, "desc"]
            ],
            "stateLoadParams": function (settings, data) {
                // $('#col1_filter').val(data.search.grade_name);  
            },
            stateSaveParams: function (settings, data) { 
                // data.search.grade_name = $('#col1_filter').val();
            },
            "processing": true,
            "serverSide": true,
            'serverMethod': 'post',
            "createdRow": function( row, data, dataIndex ) { 
                // var id = (JSON.stringify(data.id)),
                // r = JSON.stringify(dataIndex);
                // $(row).addClass("tr_class_"+id);
                // $(row).addClass("tr_row_class");
                // $(row).children(':nth-child(1)').addClass('rm07');
                // $(row).children(':nth-child(2)').addClass('rm07');
                // $(row).children(':nth-child(3)').addClass('rm07');
                // $(row).children(':nth-child(3)').attr('data-id',r);
            },
            "ajax": {
                "url": "{{ route('student.g.my.payments') }}",
                "data": function ( d ) {
                    console.log(d);
                    d.myKey = "myValue";
                    d._token = "{{ @csrf_token() }}";
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // Do something here
                    console.log("'error in datatable");
                }
            },
            'columns': [
            { 
                data: "booking_no",
                render: function(data, type, full, meta){    
                    return data;
                }
            },
            { 
                data: "booking_date",
                render: function(data, type, full, meta){ 
                    if(full.booking_date != null) {
                        var date = new Date(full.booking_date);
                        var day = date.getDate();
                        var month = date.getMonth(); 
                        var year = date.getFullYear();
                        var booking_date = year+'.'+("0" + (month+ 1)).slice(-2)+'.'+("0" + day).slice(-2);
                        return booking_date;
                    }else{
                        return ' ';
                    }   
                    return data;
                }
            },
            { 
                data: "student_grade_id",
                render: function(data, type, full, meta){    
                    return full.get_student_grade.grade_name;
                }
            },
            { 
                data: "subject_id",
                render: function(data, type, full, meta){    
                    return full.get_subject.subject;
                }
            },
            { 
                data: "tutor_id",
                render: function(data, type, full, meta){    
                    return full.get_tutor.f_name+" "+full.get_tutor.l_name;
                }
            },
            { 
                data: "booking_amount",
                render: function(data, type, full, meta){    
                    if(full.booking_status == 'C'){
                        if(full.get_payments_info != null){
                            var refund_amount = full.get_payments_info.refund_amount;
                            return '$'+data+' ( $'+refund_amount+' refunded )';    
                        }else{
                            return '$'+data;   
                        }
                        
                    }else{
                        return '$'+data;
                    }
                    return '$'+data;
                    // return '$'+data;
                }
            },
            // { 
            //     data: "id",
            //     render: function(data, type, full, meta){    
            //         if(full.get_payments_info != null){
            //             if(full.get_payments_info.txn_id != null){
            //                 return full.get_payments_info.txn_id;    
            //             }else{
            //                 return '';
            //             }    
            //         }else{
            //             return '';
            //         }
                    
                    
            //     }
            // },
            // { 
            //     data: "id",
            //     render: function(data, type, full, meta){    
            //         if(full.get_payments_info != null){
            //             if(full.get_payments_info.invoice_id != null){
            //                 return full.get_payments_info.invoice_id;    
            //             }else{
            //                 return '';
            //             }    
            //         }else{
            //             return '';
            //         }
            //     }
            // },
            // { 
            //     data: "id",
            //     render: function(data, type, full, meta){ 
            //         var a='';
            //         a+='<div class="add_ttrr actions-main">\n\
            //             <a href="javascript:void(0);" class="action-dots"  id="action'+full.id+'"><img src="{{url('/')}}/public/assets/images/action-dots.png" alt="" onclick="fun('+full.id+')"></a>\n\
            //             <div class="show-actions" id="show-action'+full.id+'" style="display: none;">\n\
            //                 <span class="angle"><img src="{{url('/')}}/public/assets/images/angle.png" alt=""></span>\n\
            //                 <ul>\n\
            //                     <li><a href="#">Download Invoice</a></li>\n\
            //                 </ul>\n\
            //             </div>\n\
            //             \n\
            //         </div>';
            //         return a;
            //     }
            // },
            ]
        });
        
        $('#from').calendar({
        type: 'date'
        });
        $('#to').calendar({
        type: 'date'
        
        });
        $('body').on('click','.reset_search', function() {
            $(".reset_val").val("");
            $('#example').DataTable().search('').columns().search('').draw();
        });
        $('body').on('click','.search_click', function() {
            filterColumn( 1 );
            filterColumn( 2 );
            
        });
        // $("#download_my_payments").click(function(){
        //     $(".buttons-excel").trigger("click");
        // });
    </script>
    <script>
        function fun(id){
        $('.show-actions').slideUp();
        $("#show-action"+id).show();
        }
        function Cancel(id){
        $("#show-action"+id).hide();
        }
        $(document).mouseup(function(e)
        {
        var container = $(".show-actions");
        // if the target of the click isn't the container nor a descendant of the container
        if (!container.is(e.target) && container.has(e.target).length === 0)
        {
        container.hide();
        }
        });
    </script>
    @endsection