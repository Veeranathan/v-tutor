{{--  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>V-tutor</title>
    <link href="{{url('/')}}/public/assets/css/bootstrap.css" rel="stylesheet">
	<link href="{{url('/')}}/public/assets/css/font-awesome/all.min.css" rel="stylesheet">
	<link href="{{url('/')}}/public/assets/css/style.css" rel="stylesheet">  
	<link href="{{url('/')}}/public/assets/css/responsive.css" rel="stylesheet">  
	<link href="{{url('/')}}/public/assets/css/owl.carousel.css" rel="stylesheet">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

	 <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Alex+Brush&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/css/datepicker.css">
    <link href="{{url('/')}}/public/assets/css/calender.css" rel="stylesheet"> </head>
    <link rel="stylesheet" href="{{url('/')}}/public/assets/css/jquery-ui.css"> --}}

     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>V-Tutor – Student – My Profile</title>
    <link rel="icon" href="{{url('/')}}/public/admin/assets/images/favicon.ico" type="image/x-icon" />
        <link rel="shortcut icon" href="{{url('/')}}/public/admin/assets/images/favicon.ico" type="image/x-icon" />
    <link href="{{url('/')}}/public/assets/css/bootstrap.css" rel="stylesheet">
    <link href="{{url('/')}}/public/assets/css/font-awesome/all.min.css" rel="stylesheet">
    <link href="{{url('/')}}/public/assets/css/semantic.min.css" rel="stylesheet" type="text/css" />
    <link href="{{url('/')}}/public/assets/css/style.css" rel="stylesheet">

    <link href="{{url('/')}}/public/assets/css/responsive.css" rel="stylesheet">
    <link href="{{url('/')}}/public/assets/css/owl.carousel.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Alex+Brush&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/css/datepicker.css">
    <link href="{{url('/')}}/public/assets/css/calender.css" rel="stylesheet"> </head>
    <link rel="stylesheet" href="{{url('/')}}/public/assets/css/jquery-ui.css">
      <link rel="stylesheet" href="{{url('/')}}/public/assets/css/chosen.css">
