<?php

namespace App\Http\Controllers\Teacher\MyAvailability;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\MyAvailability;
use App\Models\Tutor_calander_availability;

use Auth;

class MyAvailabilityController extends Controller
{
    public function available_page(Request $request){
    	$data['available']=MyAvailability::where('teacher_id',Auth()->user()->id)->where('status','A')->get();
    	 return view('teacher.modules.available.available_page')->with($data);
    }



    public function time_chk(Request $request){
    	 @$time=$request->time;
    	 @$format=$request->format;
        if($format=="AM"){

    	 $date=strtotime(date('Y-m-d '.$time.':00'))+30*60;
    	}else{
    		$exp=explode(":",$time);

    		if($exp[0]=="12"){
            $new=$time;
            $date=strtotime(date('Y-m-d '.$new.':00'))+1*30*60;
    		}else{
    	   $new=$time;
           $date=strtotime(date('Y-m-d '.$new.':00'))+12*60*60+30*60;
           }

          // $date= date('H:i:s',strtotime('+12hour',strtotime($date2)));
    	}
    	// $time=explode($request->time, " ");
        return response()->json(['time'=>@$date,'format'=>@$time]);

    }














    public function aval_ins(Request $request){
    	//dd($request->all());
    	$request->validate([
	      'day' => 'required',
	      'from_time' => 'required',
	      'to_time' => 'required',                              
	    ]);
       
       //FROM TIME CONVERT CALCULATION
	    if($request->from_time){
	    	$ft=explode(" ",$request->from_time);
	    	if($ft[1]=="AM"){
	    		$fromTime=$ft[0];
	    		//dd($fromTime);
	    	}else{
	    		$newtime=explode(":",$ft[0]);
	    		if($newtime[0]=="12"){

	    		$newhour=(int)$newtime[0];
	    		$fromTime=$newhour.':'.$newtime[1];

	    		}else{
	    		$newhour=(int)$newtime[0]+12;
	    		$fromTime=$newhour.':'.$newtime[1];
	    		//dd($fromTime);
	    	    }
	    	}
	    }

         //----TO TIME CONVER CALCULATION
	      if($request->to_time){
	    	$tt=explode(" ",$request->to_time);
	    	if($tt[1]=="AM"){
	    		$toTime=$tt[0];
	    		//dd($toTime);
	    	}else{
	    		$newToTime=explode(":",$tt[0]);
	    		if($newToTime[0]=="12"){
                $newToHour=(int)$newToTime[0];
	    		$toTime=$newToHour.':'.$newToTime[1];
	    		}else{
	    		$newToHour=(int)$newToTime[0]+12;
	    		$toTime=$newToHour.':'.$newToTime[1];
	    		//dd($toTime);
	    	    }
	    	}
	    }

	    //dd($fromTime,$toTime);
	    $d=(int)$request->day+1;
	    //dublicate check code will be here
	    $check = MyAvailability::where('day',$d)->where('teacher_id',Auth()->user()->id)->where('from_time','<',$fromTime)->where('to_time','>',$fromTime)->where('status','A')->first();


        $check1 = MyAvailability::where('day',$d)->where('teacher_id',Auth()->user()->id)->where('from_time','<',$toTime)->where('from_time','>',$fromTime)->where('to_time','<',$toTime)->where('status','A')->first();


        $check3 = MyAvailability::where('day',$d)->where('teacher_id',Auth()->user()->id)->where('from_time','<',$toTime)->where('to_time','>',$toTime)->where('status','A')->first();

        $check4 = MyAvailability::where('day',$d)->where('teacher_id',Auth()->user()->id)->where('from_time',$fromTime)->first();

        if($check || $check1 || $check3 || $check4){
        	return back()->with('error','Time slot already added. Choose a slot with no conflicts.');
        }

	    //insert
	    $aval_ins=new MyAvailability();

        $aval_ins->teacher_id=Auth()->user()->id;
        $aval_ins->status='A';
        $aval_ins->day=(int)$request->day+1;
        $aval_ins->from_time=$fromTime;
        $aval_ins->to_time=$toTime;
         
        $aval_ins->save();





        //delete all previous days data.
        $allPrevDays=Tutor_calander_availability::where('date','<',date('Y-m-d'))->where('tutor_id',Auth()->user()->id)->get();
        //dd($allPrevDays);
        if(count($allPrevDays)>0){
            foreach($allPrevDays as $deletee){
                Tutor_calander_availability::where('id',$deletee->id)->where('tutor_id',Auth()->user()->id)->delete();
            }
        }




        //now break time slot to 30 min and insert to user_cal_avail table
        $starttime = $fromTime;  // your start time
        $endtime = $toTime;  // End time
        $duration = '30';  // split by 30 mins

        $array_of_time = array ();
        $start_time    = strtotime ($starttime); //change to strtotime
        $end_time      = strtotime ($endtime); //change to strtotime

        $add_mins  = $duration * 60;

        while ($start_time <= $end_time) // loop between time
        {
           $array_of_time[] = date ("H:i", $start_time);
           $start_time += $add_mins; // to check endtie=me
        } 
       // dd($array_of_time);
       
        $length=count($array_of_time);
        //echo $length;
        //dd($length);
        $from_to_times=[];

        for($k=0;$k<$length;$k++){
            $data=[];
            if($k+1<$length){
                $data['from_time']=$array_of_time[$k];
                $data['to_time']=$array_of_time[$k+1];
                array_push($from_to_times,$data);
            }
        }
      //  dd($from_to_times);
      
       //now it will have a loop for a perticular day for next 3 months         
        for($i=0;$i<90;$i++){
          //if((int)$request->day+1==1){ 
            if((int)$request->day+1==7){
                $date=0;
            }
            else{
                $date=(int)$request->day+1;
            }
          
            if(date('w', strtotime("+".$i."days"))== $date){
               //echo date('Y-m-d', strtotime("+".$i." days")) .'<br>';
              // echo date('D', strtotime("+".$i." days")) .'<br>';
                // $c=[];

                foreach($from_to_times as $val){
                    // $bk=[];
                    // $bk['f']=$val['from_time'];
                    // $bk['t']=$val['to_time'];
                    // $bk['dt']=date('Y-m-d', strtotime("+".$i." days"));
                    // array_push($c, $bk);

                    //dublicate insert checking...
                    $searchData=Tutor_calander_availability::where('start_time',$val['from_time'])->where('end_time',$val['to_time'])->where('tutor_id',Auth()->user()->id)->where('date',date('Y-m-d', strtotime("+".$i." days")) )->where('day',(int)$request->day+1)->where('booking_status','B')->first();
                    if(!$searchData){
                        
                    $obj=new Tutor_calander_availability();
                    $obj->start_time=$val['from_time'];
                    $obj->end_time=$val['to_time'];
                    $obj->date=date('Y-m-d', strtotime("+".$i." days"));
                    $obj->booking_status="NB";
                    $obj->available_id= $aval_ins->id;
                    $obj->tutor_id=Auth()->user()->id;
                    $obj->day=(int)$request->day+1;

                    $obj->save();
                 }
                }
               // dd($c);
            }
        //}
    }//for loop end of 90 days

        return back()->with('success','Tutor slot added.');

    }











    public function aval_dlt(Request $request){
    	
        $srch_booking=Tutor_calander_availability::where('available_id',$request->id)->where('booking_status','B')->where('date','>=',date('Y-m-d'))->first();
        if($srch_booking){
            $allBooked=Tutor_calander_availability::where('available_id',$request->id)->where('booking_status','B')->where('date','>=',date('Y-m-d'))->get();
            $blank=[];
            foreach( $allBooked as $val){

                array_push($blank, date(' Y/m/d ', strtotime(@$val->date))."(".date('h:i A', strtotime(@$val->start_time))."-".date('h:i A', strtotime(@$val->end_time)).")");
            }
            $dates=implode(" , ",$blank);

            return response()->json(['dates'=>@$dates,'msg'=>'data']);
        }
        else{

        $allData=Tutor_calander_availability::where('available_id',$request->id)->get();

        foreach($allData as $dl){
            Tutor_calander_availability::where('id',$dl->id)->where('booking_status','NB')->delete();
        }
       $dlt=MyAvailability::where('teacher_id',Auth()->user()->id)->where('id',$request->id)->delete();

    	  return response()->json(['msg'=>'nodata']);
        }
    }













    public function fetch_from_time(Request $request){
        $fetch_from_timeDetails=MyAvailability::where('teacher_id',Auth()->user()->id)->where('day',(int)($request->id)+1)->orderBy('to_time','desc')->first();
        $lastTime=$fetch_from_timeDetails->to_time;
        $lastTimeMiliSecond=strtotime(date('Y-m-d '.$lastTime))+1*30*60;
         return response()->json(['ids'=>@$lastTimeMiliSecond]);
         //database from time theke 
         //totime +30....
         //fromtime-30
         /*
         4-4:30

         3-3:45 korle hbe na so : to_time=3:45, to_time_plus=to_time+30min
                             so :whereBetween('from_time',[to_time,to_time_plus])


         */
    }
}
