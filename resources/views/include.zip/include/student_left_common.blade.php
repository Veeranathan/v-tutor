<div class="user-left sticky_left">
    <div class="dasbordLeftsec"> <a href="#" class="showmeu"><i class="fa fa-bars"></i>Show Menus</a>
    <div class="dasbordLeft">
        <div class="user-left-info">
            <div class="user-left-top"> <em>
                @if(Auth::user()->profile_pic)
               {{-- {{url('/')}}/storage/app/public/student_profile_pic/{{@Auth::user()->profile_pic}} --}}
                    <img src="{{url('/')}}/public/assets/images/user-pro.png" alt="profile_img" style="width: 100%">
                @elseif(!@Auth::user()->profile_pic && @Auth::user()->avatar)
                <img src="{{-- {{url('/')}}/public/assets/images/user-pro.png --}}{{@Auth::user()->avatar}}" alt="profile_img" style="width: 100%">
                @else
                <img src="{{url('/')}}/public/assets/images/user-pro.png" alt="profile_img" style="width: 100%">
                @endif
                </em>
                <h2>{{@Auth::user()->f_name." ".@Auth::user()->l_name}}</h2> <p>40 classes</p> </div>
                <div class="new-lft-bottom">
                    <div class="user-left-menu">
                        <ul>
                            
                            <li class="{{request()->segment(1)=='home'?'active':''}}"><a href="{{route('home')}}"><span><img src="{{url('/')}}/public/assets/images/ac1.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac1-h.png" class="hovera"></span> Dashboard</a></li>


                            <li>
                                <a  data-toggle="modal" data-target="#myModal"> <span><img src="{{url('/')}}/public/assets/images/ac5.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac5-h.png" class="hovera"></span> Book a Class</a>
                            </li>
                            
                            
                            <li class="{{request()->segment(1)=='my-profile'?'active':''}}">
                                <a href="{{route('my.profile')}}"> <span><img src="{{url('/')}}/public/assets/images/ac2.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac2-h.png" class="hovera"></span> My Profile</a>
                            </li>
                            
                            
                            <li>
                                <a href="#"> <span><img src="{{url('/')}}/public/assets/images/ac3.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac3-h.png" class="hovera"></span> My Classes</a>
                            </li>
                            <li>
                                <a href="#"> <span><img src="{{url('/')}}/public/assets/images/ac4.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac4-h.png" class="hovera"></span> My Tutors</a>
                            </li>
                            <li>
                                <a href="#"><span><img src="{{url('/')}}/public/assets/images/ac4d.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac4d-h.png" class="hovera"> </span> My Reviews</a>
                            </li>
                            <li><a href="#"><span><img src="{{url('/')}}/public/assets/images/ac6.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac6-h.png" class="hovera"></span>  My Payments</a></li>
                        </ul>
                    </div>
                    <div class="log-menu">
                        <ul>
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();"> <span><img src="{{url('/')}}/public/assets/images/ac-7.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac7-h.png" class="hovera"></span> Logout</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                        
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>