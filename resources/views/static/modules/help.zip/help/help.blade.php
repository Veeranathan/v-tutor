@extends('layouts.app')



@section('title')
<title>V-tutor | About Us</title>
@endsection

@section('left_part')
@include('include.left_part')
@endsection
@section('content')
<div class="top_mar"></div>
<section class="about-banner " style="background-image: url(images/about-nbanner.jpg);">
		<div class="container">
			<div class="row">
				<div class="col-12">
				<nav aria-label="breadcrumb">
		          <ol class="breadcrumb">
		            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
		            <li class="breadcrumb-item active" aria-current="page">Help</li>
		          </ol>
		        </nav>
		        <div class="inner-banner-title mt-0 pb-2">
		          <h1 class="title">
		            How can we help?
		          </h1>
		        </div>
	        </div>
				
			</div>
		</div>
	</section>
	<section class="topics-sec">
		<div class="container">
			<div class="topics ">
				<div class="row no-gutters">
					<ul class="nav nav-tabs new-nav">
						<li><a data-toggle="tab" href="#home" class="active">Getting Started</a></li>
						<li><a data-toggle="tab" href="#menu1">Sign Up & Accounts</a></li>
						<li><a data-toggle="tab" href="#menu2">Manage Classes</a></li>
						<li><a data-toggle="tab" href="#menu3">Tutors Guide</a></li>
						<li><a data-toggle="tab" href="#menu4">Orders & Payments</a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="tab-content helptab">

				<div id="home" class="tab-pane fade show in active">
					<h3>Getting Started</h3>
					<div class="makes_faq_bx newfaq">
						<div class="accordion" id="accordionExample">
							<div class="card">
								<div class="card-header" id="headingOne">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left"  data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
									          01. What is V-Tutor?
									        </a>
									      </h2> </div>
								<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingTwo">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
									         02. Why do I need V-Tutor?
									        </a>
									      </h2> </div>
								<div id="collapseTwo" class="collapse " aria-labelledby="headingTwo" data-parent="#accordionExample">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingThree">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
									         03. Is V-Tutor the right platform for me?
									        </a>
									      </h2> </div>
								<div id="collapseThree" class="collapse " aria-labelledby="headingThree" data-parent="#accordionExample">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingfour">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
									         04. How long does it require to get started?
									        </a>
									      </h2> </div>
								<div id="collapsefour" class="collapse " aria-labelledby="headingfour" data-parent="#accordionExample">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingfive">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">
									         05. How easy is to use V-Tutor?

									        </a>
									      </h2> </div>
								<div id="collapsefive" class="collapse " aria-labelledby="headingfive" data-parent="#accordionExample">
									<div class="card-body">
										<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic </p>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>

				<div id="menu1" class="tab-pane fade">
					<h3>Sign Up & Accounts</h3>
					<div class="makes_faq_bx newfaq">
						<div class="accordion" id="accordionExample2">
							<div class="card">
								<div class="card-header" id="headingnewOne">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left"  data-toggle="collapse" data-target="#collapsenewOne" aria-expanded="true" aria-controls="collapsenewOne">
									          01. How do I sign up?
									        </a>
									      </h2> </div>
								<div id="collapsenewOne" class="collapse show" aria-labelledby="headingnewOne" data-parent="#accordionExample2">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewTwo">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewTwo" aria-expanded="false" aria-controls="collapsenewTwo">
									         02. How long does it take to get started?
									        </a>
									      </h2> </div>
								<div id="collapsenewTwo" class="collapse " aria-labelledby="headingnewTwo" data-parent="#accordionExample2">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewThree">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewThree" aria-expanded="false" aria-controls="collapsenewThree">
									         03. Where can I update my profile?
									        </a>
									      </h2> </div>
								<div id="collapsenewThree" class="collapse " aria-labelledby="headingnewThree" data-parent="#accordionExample2">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewfour">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewfour" aria-expanded="false" aria-controls="collapsenewfour">
									         04. How do I reset my password?
									        </a>
									      </h2> </div>
								<div id="collapsenewfour" class="collapse " aria-labelledby="headingnewfour" data-parent="#accordionExample2">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewfive">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewfive" aria-expanded="false" aria-controls="collapsenewfive">
									         05. Can I sign up on behalf of my son/daughter?

									        </a>
									      </h2> </div>
								<div id="collapsenewfive" class="collapse " aria-labelledby="headingnewfive" data-parent="#accordionExample2">
									<div class="card-body">
										<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic </p>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>

				<div id="menu2" class="tab-pane fade">
					<h3>Manage Classes</h3>
					<div class="makes_faq_bx newfaq">
						<div class="accordion" id="accordionExample3">
							<div class="card">
								<div class="card-header" id="headingnewsOne">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left"  data-toggle="collapse" data-target="#collapsenewsOne" aria-expanded="true" aria-controls="collapsenewsOne">
									          01. How do I book classes?
									        </a>
									      </h2> </div>
								<div id="collapsenewsOne" class="collapse show" aria-labelledby="headingnewsOne" data-parent="#accordionExample3">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewsTwo">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewsTwo" aria-expanded="false" aria-controls="collapsenewsTwo">
									         02. How do I attend the classroom session?
									        </a>
									      </h2> </div>
								<div id="collapsenewsTwo" class="collapse " aria-labelledby="headingnewsTwo" data-parent="#accordionExample3">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewsThree">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewsThree" aria-expanded="false" aria-controls="collapsenewsThree">
									         03. How do I cancel / reschedule a booked class?
									        </a>
									      </h2> </div>
								<div id="collapsenewsThree" class="collapse " aria-labelledby="headingnewsThree" data-parent="#accordionExample3">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewsfour">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewsfour" aria-expanded="false" aria-controls="collapsenewsfour">
									         04. Can I get refund for a cancelled class?
									        </a>
									      </h2> </div>
								<div id="collapsenewsfour" class="collapse " aria-labelledby="headingnewsfour" data-parent="#accordionExample3">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewsfive">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewsfive" aria-expanded="false" aria-controls="collapsenewsfive">
									         05. Where can I find my classes?

									        </a>
									      </h2> </div>
								<div id="collapsenewsfive" class="collapse " aria-labelledby="headingnewsfive" data-parent="#accordionExample3">
									<div class="card-body">
										<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div id="menu3" class="tab-pane fade">
					<h3>Tutors Guide</h3>
					<div class="makes_faq_bx newfaq">
						<div class="accordion" id="accordionExample4">
							<div class="card">
								<div class="card-header" id="headingnewesOne">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left"  data-toggle="collapse" data-target="#collapsenewesOne" aria-expanded="true" aria-controls="collapsenewesOne">
									          01. How do I get started as a V-Tutor?
									        </a>
									      </h2> </div>
								<div id="collapsenewesOne" class="collapse show" aria-labelledby="headingnewesOne" data-parent="#accordionExample4">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewesTwo">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewesTwo" aria-expanded="false" aria-controls="collapsenewesTwo">
									         02. How long does it take for onboarding?
									        </a>
									      </h2> </div>
								<div id="collapsenewesTwo" class="collapse " aria-labelledby="headingnewesTwo" data-parent="#accordionExample4">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewesThree">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewesThree" aria-expanded="false" aria-controls="collapsenewesThree">
									         03. How many classes can I schedule?
									        </a>
									      </h2> </div>
								<div id="collapsenewesThree" class="collapse " aria-labelledby="headingnewesThree" data-parent="#accordionExample4">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewesfour">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewesfour" aria-expanded="false" aria-controls="collapsenewesfour">
									         04. How and when do I get paid?
									        </a>
									      </h2> </div>
								<div id="collapsenewesfour" class="collapse " aria-labelledby="headingnewesfour" data-parent="#accordionExample4">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewesfive">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewesfive" aria-expanded="false" aria-controls="collapsenewesfive">
									         05. How do I manage my classes?

									        </a>
									      </h2> </div>
								<div id="collapsenewesfive" class="collapse " aria-labelledby="headingnewesfive" data-parent="#accordionExample4">
									<div class="card-body">
										<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic </p>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>

				<div id="menu4" class="tab-pane fade">
					<h3>Orders & Payments</h3>
					<div class="makes_faq_bx newfaq">
						<div class="accordion" id="accordionExample5">
							<div class="card">
								<div class="card-header" id="headingnewestOne">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left"  data-toggle="collapse" data-target="#collapsenewestOne" aria-expanded="true" aria-controls="collapsenewestOne">
									          01. How do I book my class?
									        </a>
									      </h2> </div>
								<div id="collapsenewestOne" class="collapse show" aria-labelledby="headingnewestOne" data-parent="#accordionExample5">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewestTwo">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewestTwo" aria-expanded="false" aria-controls="collapsenewestTwo">
									         02. What are my payment options?
									        </a>
									      </h2> </div>
								<div id="collapsenewestTwo" class="collapse " aria-labelledby="headingnewestTwo" data-parent="#accordionExample5">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewestThree">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewestThree" aria-expanded="false" aria-controls="collapsenewestThree">
									         03. How do I get a refund for cancelled class?
									        </a>
									      </h2> </div>
								<div id="collapsenewestThree" class="collapse " aria-labelledby="headingnewestThree" data-parent="#accordionExample5">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewestfour">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewestfour" aria-expanded="false" aria-controls="collapsenewestfour">
									         04. How do I look at my previous orders?
									        </a>
									      </h2> </div>
								<div id="collapsenewestfour" class="collapse " aria-labelledby="headingnewestfour" data-parent="#accordionExample5">
									<div class="card-body">
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingnewestfive">
									<h2 class="mb-0">
									        <a class="btn btn-link btn-block text-left collapsed" data-toggle="collapse" data-target="#collapsenewestfive" aria-expanded="false" aria-controls="collapsenewestfive">
									         05. Can I book multiple classes in one go?

									        </a>
									      </h2> </div>
								<div id="collapsenewestfive" class="collapse " aria-labelledby="headingnewestfive" data-parent="#accordionExample5">
									<div class="card-body">
										<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
@endsection

@section('footer')
    @include('include.footer')
@endsection

@section('script')
    @include('include.script')
   
@endsection

