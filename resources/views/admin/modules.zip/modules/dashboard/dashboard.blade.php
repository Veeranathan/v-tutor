@extends('admin.layouts.app')
@section('title')
    Dashboard
@endsection
@section('links')
    @include('admin.includes.links')
@endsection
@section('header')
    @include('admin.includes.header')
@endsection
@section('sidebar')
    @include('admin.includes.sidebar')
@endsection
@section('content')
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h1 class="pull-left page-title">Welcome !</h1>
                    <ol class="breadcrumb pull-right">
                        <li><a href="{{ route('admin.dashboard') }}">V-tutor</a></li>
                        <li class="active">Dashboard</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <a href="{{ route('manage.grades') }}">
                        <div class="mini-stat clearfix bx-shadow bg-white">
                            <span class="mini-stat-icon bg-info"><i class="fa fa-book" aria-hidden="true"></i></span>
                            <div class="mini-stat-info text-right text-dark">
                                <span class="counter text-dark">{{ @$grade_count }}</span>
                                <b> Grades Management</b>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <a href="#">
                        <div class="mini-stat clearfix bx-shadow bg-white">
                            <span class="mini-stat-icon bg-warning"><i class="fas fa-hand-holding-usd" aria-hidden="true"></i></span>
                            <div class="mini-stat-info text-right text-dark">
                                <span class="counter text-dark">0</span>
                                <b> Commission Management</b>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <a href="{{ route('manage.tutors') }}">
                        <div class="mini-stat clearfix bx-shadow bg-white">
                            <span class="mini-stat-icon bg-pink"><i class="fas fa-user-tie"></i></span>
                            <div class="mini-stat-info text-right text-dark">
                                <span class="counter text-dark">{{ @$tutor_count }}</span>
                                <b>Tutor Management</b>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <a href="{{ route('manage.students') }}">
                        <div class="mini-stat clearfix bx-shadow bg-white">
                            <span class="mini-stat-icon bg-success"><i class="far fa-user"></i></span>
                            <div class="mini-stat-info text-right text-dark">
                                <span class="counter text-dark">{{ @$student_count }}</span>
                               <b>Student Management</b>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <a href="#">
                        <div class="mini-stat clearfix bx-shadow bg-white">
                            <span class="mini-stat-icon bg-info"><i class="fas fa-user"></i></span>
                            <div class="mini-stat-info text-right text-dark">
                                <span class="counter text-dark">0</span>
                                <b> Profile Manage</b>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <a href="#">
                        <div class="mini-stat clearfix bx-shadow bg-white">
                            <span class="mini-stat-icon bg-warning"><i class="fas fa-clock"></i></span>
                            <div class="mini-stat-info text-right text-dark">
                                <span class="counter text-dark">0</span>
                                <b>Manage Availabiliti</b>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <a href="#">
                        <div class="mini-stat clearfix bx-shadow bg-white">
                            <span class="mini-stat-icon bg-pink"><i class="fa fa-check-square-o" aria-hidden="true"></i></span>
                            <div class="mini-stat-info text-right text-dark">
                                <span class="counter text-dark">0</span>
                                <b>Booking Management</b>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-sm-6 col-lg-3">
                    <a href="javascript:void(0);">
                        <div class="mini-stat clearfix bx-shadow bg-white">
                            <span class="mini-stat-icon bg-success"><i class="far fa-credit-card" aria-hidden="true"></i></span>
                            <div class="mini-stat-info text-right text-dark">
                                <span class="counter text-dark">0</span>
                                <b>Rating Management System</b>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>          
    </div> 
@endsection    
@section('footer')
    @include('admin.includes.footer')
@endsection
@section('script')
    @include('admin.includes.script')
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.counter').counterUp({
            delay: 100,
            time: 1200
        });
    });
</script>

@endsection