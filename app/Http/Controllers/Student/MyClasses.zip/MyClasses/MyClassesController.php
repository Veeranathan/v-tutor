<?php

namespace App\Http\Controllers\Student\MyClasses;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Models\Subject;
use App\Models\StudentClassBooking;
use App\Models\MyAvailability;
use App\Models\TutorshipPlan;
use App\Models\UserToFavourite;
use App\Models\Tutor_calander_availability;
use App\Models\Grade;
use App\User;
use Validator;

class MyClassesController extends Controller
{
    public function studentMyClasses(Request $request){
        //$data['past_session_student_booked_classes'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade'])->get();

       $data['classes']=StudentClassBooking::where('student_id',Auth()->user()->id)->orderBy('from_time','DESC')->where('booking_date',date('Y-m-d'))->whereIn('booking_status',['B','CM','C']);
       if(@$request->status){
           if($request->status){
            $data['classes']=$data['classes']->where('booking_status',$request->status); 
          }
        $data['res']=$request->all();
        }
      
       $data['classes']= $data['classes']->get();

        return view('student.modules.my_classes.student_my_classes')->with($data);
    }




    public function studentMyClassesDatatable(Request $request){
        $columnIndex = $request->order[0]['column'];
        $columnSortOrder = $request->order[0]['dir'];
        $bookings = StudentClassBooking::whereIn('status',['B','C','CM']);
        if(@$request->columns['1']['search']['value']){
            $bookings = $bookings->where(function($query) use($request) {
                $query->where('booking_no','like','%'.$request->columns['1']['search']['value'].'%');
            });
        }
        $ps =  $bookings->count();
        $pp = $bookings;
        $pp = $pp->count();
        $limit = $request->length;
        $p = $bookings = $bookings;
        $p =  $p->count();
        if($columnIndex == 0) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('id','asc');
            } else {
                $bookings = $bookings->orderBy('id','desc');
            }
        }
        if($columnIndex == 1) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('id','asc');
            } else {
                $bookings = $bookings->orderBy('id','desc');
            }
        }
        if($columnIndex == 2) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('id','asc');
            } else {
                $bookings = $bookings->orderBy('id','desc');
            }
        }
        $bookings = $bookings->orderBy('id','desc')->skip($request->start)->take($request->length)->get();
        $data['aaData'] = $bookings;
        $data["draw"] = intval($request->draw);
        $data['iTotalRecords'] = $ps;
        $data["iTotalDisplayRecords"] = $pp;
        return response()->json($data);
    }









    public function studentMyClassesUpcomming(Request $request){

         $data['classes']=StudentClassBooking::where('student_id',Auth()->user()->id)->orderBy('from_time','DESC')->where('booking_date','>',date('Y-m-d'))->whereIn('booking_status',['B','CM','C']);

       if(@$request->from_date || @$request->to_date){
      // dd($request->all());
         @$from_date = date('Y-m-d', strtotime($request->from_date));
         @$to_prev= $request->to_date;
         @$to=date('Y-m-d', strtotime($to_prev/*. ' + 1 days'*/));
        // dd($request->all(),$from_date,$to);

        if($from_date && $to){
            $data['classes']=$data['classes']->whereBetween('booking_date',[$from_date, $to]); 
          }

           if($request->status){
            $data['classes']=$data['classes']->where('booking_status',$request->status); 
          }

        $data['res']=$request->all();
        }
         $data['classes']= $data['classes']->get();

        return view('student.modules.my_classes.student_upcomming')->with($data);

    }











    public function studentMyClassesPast(Request $request){
         $data['classes']=StudentClassBooking::where('student_id',Auth()->user()->id)->orderBy('from_time','DESC')->where('booking_date','<',date('Y-m-d'))->whereIn('booking_status',['B','CM','C']);

       if(@$request->from_date || @$request->to_date){
      // dd($request->all());
         @$from_date = date('Y-m-d', strtotime($request->from_date));
         @$to_prev= $request->to_date;
         @$to=date('Y-m-d', strtotime($to_prev/*. ' + 1 days'*/));
        // dd($request->all(),$from_date,$to);

        if($from_date && $to){
            $data['classes']=$data['classes']->whereBetween('booking_date',[$from_date, $to]); 
          }

           if($request->status){
            $data['classes']=$data['classes']->where('booking_status',$request->status); 
          }

        $data['res']=$request->all();
        }
         $data['classes']= $data['classes']->get();

        return view('student.modules.my_classes.student_past')->with($data);
        
    }











    public function studentClassExport(Request $request){
     //dd($request->all());
    //echo url('/');
        $data['data'] = StudentClassBooking::where('student_id',Auth()->user()->id)->whereIn('booking_status',['B','CM','C']);

        //dd($data['data'] );



  //--------------------------Fetch all past value---------------------------------------
      if($request->session=="past"){
        $count=StudentClassBooking::where('student_id',Auth()->user()->id)->where('booking_date','<',date('Y-m-d') )->whereIn('booking_status',['B','CM','C'])->count();
        if($count<1){
          return back()->with('error','No data.');
        }
         $data['data']= $data['data']->where('booking_date','<',date('Y-m-d') );
         if(@$request->from_date || @$request->to_date){
              // dd($request->all());
             @$from_date = date('Y-m-d', strtotime($request->from_date));
             @$to_prev= $request->to_date;
             @$to=date('Y-m-d', strtotime($to_prev/*. ' + 1 days'*/));
            // dd($request->all(),$from_date,$to);
              if($from_date && $to){
                  $data['data']=$data['data']->whereBetween('booking_date',[$from_date, $to]); 
              }
          }

             if($request->status){
              $data['data']=$data['data']->where('booking_status',$request->status); 
            }
              $zyz=$data['data']->get();
            if(count($zyz)<1){
              return back()->with('error','No data.');
            }
      }   



       //--------------------------Fetch all future value---------------------------------------
      if($request->session=="future"){
         $count=StudentClassBooking::where('student_id',Auth()->user()->id)->where('booking_date','>',date('Y-m-d') )->whereIn('booking_status',['B','CM','C'])->count();
        if($count<1){
          return back()->with('error','No data.');
        }
         $data['data']= $data['data']->where('booking_date','>',date('Y-m-d') );
         if(@$request->from_date || @$request->to_date){
              // dd($request->all());
             @$from_date = date('Y-m-d', strtotime($request->from_date));
             @$to_prev= $request->to_date;
             @$to=date('Y-m-d', strtotime($to_prev/*. ' + 1 days'*/));
            // dd($request->all(),$from_date,$to);
              if($from_date && $to){
                  $data['data']=$data['data']->whereBetween('booking_date',[$from_date, $to]); 
              }
          }

             if($request->status){
              $data['data']=$data['data']->where('booking_status',$request->status); 
            }
              $zyz=$data['data']->get();
            if(count($zyz)<1){
              return back()->with('error','No data.');
            }
      }  

        //--------------------------Fetch all present value---------------------------------------
      if($request->session=="present"){
        $count=StudentClassBooking::where('student_id',Auth()->user()->id)->where('booking_date',date('Y-m-d') )->whereIn('booking_status',['B','CM','C'])->count();
        //dd($count);
        if($count<1){
          return back()->with('error','No data.');
        }
         $data['data']= $data['data']->where('booking_date',date('Y-m-d') );
    
             if($request->status){
              $data['data']=$data['data']->where('booking_status',$request->status); 
            }
              $zyz=$data['data']->get();
            if(count($zyz)<1){
              return back()->with('error','No data.');
            }
      }  


    $abc=  $data['data']->orderBy('id','desc')->with(['getStudent','getTutor','getSubject','getStudentGrade'])->get();
     //dd($abc);
    $data = '';
    
      $data .='<table>
      <tr>
      <th style="border:1px solid black;background-color
      :lime">Booking id</th>
      <th style="border:1px solid black;background-color
      :lime">Student name</th>
      <th style="border:1px solid black;background-color
      :lime">Tutor name</th>
      <th style="border:1px solid black;background-color
      :lime">Grade</th>
      <th style="border:1px solid black;background-color
      :lime">Subject</th>
      <th style="border:1px solid black;background-color
      :lime">From time</th>
      <th style="border:1px solid black;background-color
      :lime">To time</th>
      <th style="border:1px solid black;background-color
      :lime">Booking date</th>
      <th style="border:1px solid black;background-color
      :lime">Status</th>

      <th style="border:1px solid black;background-color
      :lime">Payment</th>
      <th style="border:1px solid black;background-color
      :lime">Zoom url</th>
      
      
   
      </tr>
      ';
      foreach (@$abc as $value) {
        // booking status 
        if ($value->booking_status=="B") {
          $status = "Booked";
        }elseif ($value->booking_status=="C") {
          $status = "Cancelled";
        }elseif($value->booking_status=="I"){
           $status = "In Progress";
        }
       
        else{
           $status = "Completed";
        }

         @$value->payment_method="Online";
        

        $data .= '
        <tr>
        <td style="border:1px solid black;">'.@$value->booking_no.'</td>
        <td style="border:1px solid black;">'.@$value->getStudent->f_name." ".@$value->getStudent->l_name.'</td>
        <td style="border:1px solid black;">'.@$value->getTutor->f_name." ".@$value->getTutor->l_name.'</td>
        <td style="border:1px solid black;">'.@$value->getStudentGrade->grade_name.'</td>
        <td style="border:1px solid black;">'.@$value->getSubject->subject.'</td>
        <td style="border:1px solid black;">'.@$value->from_time.'</td>
        <td style="border:1px solid black;">'.@$value->to_time.'</td>
        <td style="border:1px solid black;">'.@$value->booking_date.'</td>

        <td style="border:1px solid black;">'.@$status.'</td>
        <td style="border:1px solid black;">'.@$value->payment_method.'</td>
        <td style="border:1px solid black;">'.@$value->join_url.'</td>
       
        
        </tr>';
      }
      $data .= '</table>';
    
      //dd($data);
    header("Content-Type: application/xls");    
    header("Content-Disposition: attachment; filename=StudentClassRecord.xls");  
    header("Pragma: no-cache"); 
    header("Expires: 0");
   // dd($data); 
    echo $data;
    // return view('admin.modules.employers.manage_employers',$data);
    }




    // public function pastSessionStudentMyClassesDataTable(){
        
    // }
}
