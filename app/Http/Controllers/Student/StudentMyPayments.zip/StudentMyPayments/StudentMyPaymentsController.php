<?php

namespace App\Http\Controllers\Student\StudentMyPayments;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Models\Subject;
use App\Models\StudentClassBooking;
use App\Models\MyAvailability;
use App\Models\TutorshipPlan;
use App\Models\UserToFavourite;
use App\Models\Tutor_calander_availability;
use App\Models\Grade;
use App\Models\Payments;
use App\User;
use Validator;

class StudentMyPaymentsController extends Controller
{
    public function studentMyPayments(Request $request){
        // $data['myPayments'] = StudentClassBooking::with(['getPaymentsInfo','getStudent','getTutor','getSubject','getStudentGrade'])->where(['student_id'=>@Auth::user()->id]);
        
        // if(@$request->from_date && @$request->to_date){
        //     $from_date = date('Y-m-d h:i:s',strtotime($request->from_date));
        //     $to_date = date('Y-m-d h:i:s',strtotime($request->to_date));
        //     $data['myPayments'] = $data['myPayments']->where(function($query) use($from_date,$to_date) {
        //         $query->whereBetween('created_at',[$from_date,$to_date]);
        //     });
        // }
        // $data['myPayments'] = $data['myPayments']->orderBy('id','desc')->get();
        $data['tot_payments'] = StudentClassBooking::with(['getPaymentsInfo'])->whereIn('booking_status',['B','C','CM'])->where(['student_id'=>@Auth::user()->id])->count();
        return view('student.modules.student_my_payments.student_my_payments')->with($data);
    }
    public function studentGMyPayments(Request $request){
        $columnIndex = $request->order[0]['column'];
        $columnSortOrder = $request->order[0]['dir'];
        $bookings = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade','getPaymentsInfo'])->whereIn('booking_status',['B','C','CM'])->where(['student_id'=>@Auth::user()->id]);
        if(@$request->columns['1']['search']['value']){
            $from_date = date('Y-m-d',strtotime($request->columns['1']['search']['value']));
            $bookings = $bookings->where(function($query) use($from_date) {
                $query->where('booking_date','>=',$from_date);
            });
        }
        if(@$request->columns['2']['search']['value']){
            $to_date = date('Y-m-d',strtotime($request->columns['2']['search']['value']));
            $bookings = $bookings->where(function($query) use($to_date) {
                $query->where('booking_date','<=',$to_date);
            });
        }
        $ps =  $bookings->count();
        $pp = $bookings;
        $pp = $pp->count();
        $limit = $request->length;
        $p = $bookings = $bookings;
        $p =  $p->count();
        if($columnIndex == 0) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('booking_no','asc');
            } else {
                $bookings = $bookings->orderBy('booking_no','desc');
            }
        }
        if($columnIndex == 1) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('tutor_id','asc');
            } else {
                $bookings = $bookings->orderBy('tutor_id','desc');
            }
        }
        if($columnIndex == 2) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('student_id','asc');
            } else {
                $bookings = $bookings->orderBy('student_id','desc');
            }
        }
        if($columnIndex ==3) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('subject_id','asc');
            } else {
                $bookings = $bookings->orderBy('subject_id','desc');
            }
        }
        if($columnIndex == 4) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('student_grade_id','asc');
            } else {
                $bookings = $bookings->orderBy('student_grade_id','desc');
            }
        }
        if($columnIndex == 5) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('booking_amount','asc');
            } else {
                $bookings = $bookings->orderBy('booking_amount','desc');
            }
        }
        if($columnIndex == 6) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('booking_date','asc');
            } else {
                $bookings = $bookings->orderBy('booking_date','desc');
            }
        }
        if($columnIndex == 7) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('booking_status','asc');
            } else {
                $bookings = $bookings->orderBy('booking_status','desc');
            }
        }
        if($columnIndex == 8) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('created_at','asc');
            } else {
                $bookings = $bookings->orderBy('created_at','desc');
            }
        }
        if($columnIndex == 9) {
            if($columnSortOrder == 'asc') {
                $bookings = $bookings->orderBy('id','asc');
            } else {
                $bookings = $bookings->orderBy('id','desc');
            }
        }
        $bookings = $bookings->orderBy('id','desc')->skip($request->start)->take($request->length)->get();
        $data['aaData'] = $bookings;
        $data["draw"] = intval($request->draw);
        $data['iTotalRecords'] = $ps;
        $data["iTotalDisplayRecords"] = $pp;
        return response()->json($data);
    }
    public function studentAMyPayments(){
        
    }
    // public function studentGAMyPayments(){
        
    // }
    public function studentGAMyPayments(Request $request){
        
        $data['bookings'] = StudentClassBooking::with(['getStudent','getTutor.languguageToTuor','getTutor.getTutorAcademic','getSubject','getStudentGrade','getPaymentsInfo'])->whereIn('booking_status',['B','C','CM'])->where('student_id',@Auth::user()->id);
        
        if(@$request->from_date){
            $from_date = date('Y-m-d',strtotime($request->from_date));
            $data['bookings'] = $data['bookings']->where(function($query) use($from_date) {
                $query->where('booking_date','>=',$from_date);
            });
        }
        if(@$request->to_date){
            $to_date = date('Y-m-d',strtotime($request->to_date));
            $data['bookings'] = $data['bookings']->where(function($query) use($to_date) {
                $query->where('booking_date','<=',$to_date);
            });
        }
        
        $data['bookings'] = $data['bookings']->orderBy('id','desc')->get();
        $t = '';
        $t .='<table>
            <tr>
                <th style="border:1px solid black;background-color
      :lime">Booking id</th>
      <th style="border:1px solid black;background-color
      :lime">Student name</th>
      <th style="border:1px solid black;background-color
      :lime">Tutor name</th>
      <th style="border:1px solid black;background-color
      :lime">Grade</th>
      <th style="border:1px solid black;background-color
      :lime">Subject</th>
      <th style="border:1px solid black;background-color
      :lime">From time</th>
      <th style="border:1px solid black;background-color
      :lime">To time</th>
      <th style="border:1px solid black;background-color
      :lime">Booking date</th>
      <th style="border:1px solid black;background-color
      :lime">Status</th>

      <th style="border:1px solid black;background-color
      :lime">Payment</th>
      <th style="border:1px solid black;background-color
      :lime">Zoom url</th>
      <th style="border:1px solid black;background-color
      :lime">Transaction Id</th>
      <th style="border:1px solid black;background-color
      :lime">Invoice Id</th>
            </tr>
            ';
        if(@$data['bookings']){
            foreach(@$data['bookings'] as $value){
                // booking status 
        if ($value->booking_status=="B") {
          $status = "Booked";
        }elseif ($value->booking_status=="C") {
          $status = "Cancelled";
        }elseif($value->booking_status=="I"){
           $status = "In Progress";
        }  
        elseif ($value->booking_status=="CM"){
           $status = "Completed";
        }else{
            $status = "";
        }
        $payment_method="Online";
        $t .= '
        <tr>
        <td style="border:1px solid black;">'.@$value->booking_no.'</td>
        <td style="border:1px solid black;">'.@$value->getStudent->f_name." ".@$value->getStudent->l_name.'</td>
        <td style="border:1px solid black;">'.@$value->getTutor->f_name." ".@$value->getTutor->l_name.'</td>
        <td style="border:1px solid black;">'.@$value->getStudentGrade->grade_name.'</td>
        <td style="border:1px solid black;">'.@$value->getSubject->subject.'</td>
        <td style="border:1px solid black;">'.date('h:i a',strtotime(@$value->from_time)).'</td>
        <td style="border:1px solid black;">'.date('h:i a',strtotime(@$value->to_time)).'</td>
        <td style="border:1px solid black;">'.@$value->booking_date.'</td>

        <td style="border:1px solid black;">'.@$status.'</td>
        <td style="border:1px solid black;">'.@$payment_method.'</td>
        <td style="border:1px solid black;">'.@$value->join_url.'</td>
        <td style="border:1px solid black;">'.@$value->getPaymentsInfo->invoice_id.'</td>
        <td style="border:1px solid black;">'.@$value->getPaymentsInfo->txn_id.'</td>
        </tr>';
            }
        }
        $t .= '</table>';
        header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");    
        header("Content-Disposition: attachment; filename=MyPayments.xls");  
        header("Pragma: no-cache"); 
        header("Expires: 0");
        echo $t;
    }
}
