@extends('layouts.app')
@section('title')
<title>V-tutor | Tutor Search  Result </title>
@endsection
@section('left_part')
@include('include.left_part')
<link href="{{ asset('public/assets/toastr/build/toastr.min.css') }}" rel="stylesheet">
<style type="text/css">
</style>
@endsection
@section('content')
<div class="top_mar"></div>
<div class="search_result_sec ">
    <div class="container">
        <div class="search_result_inr">
            <div class="search_result_left empty_inner  s_emt_cls">
                <div class="mobile_filter_as"> <i class="fa fa-bars" aria-hidden="true"></i>
                    <span>Show Filter</span>
                </div>
                <div class="search_left_inr">
                    <div class="search_left_class">
                        <h4>Grades </h4>
                        <a href="{{ route('search.result.j') }}"><span>
                        <img src="{{ asset('public/assets/images/filtar.png') }}" alt="">
                        Re-adjust
                        </span>
                        </a>
                    </div>
                    <div class="search_left_frm">
                        <form action="{{ route('search.result.j') }}" method="get" id="searchVtutorForm">
                            <div class="search_le_selt">
                                {{-- <input type="hidden" id="state" name="state" value="{{ @$state_value->slug }}"> --}}
                                <select id="grade" name="grade" class="change_apply" >
                                    <option value="">Select Grade</option>
                                    @if(@$grades)
                                    @foreach(@$grades as $key=>$grade)
                                    <option value="{{ $grade->slug }}" @if(@$grade_value == @$grade->slug) selected="" @else class="not_matched" @endif>{{ @$grade->grade_name }}</option>
                                    @endforeach
                                    @endif
                                </select>
                                <input type="hidden" name="sort_type" value="sort_type" id="sort_type" value="@if(@$sort_type_value) {{ @$sort_type_value }} @else R @endif">
                            </div>
                            <div class="search_le_check_pan">
                                <div class="search_le_check_bx">
                                    <h5>Subjects</h5>
                                    @if(@$subjects)
                                    @foreach(@$subjects as $key=>$subject)
                                    @if($key == 0)
                                    <ul>
                                    @endif
                                    @if($key == 2) 
                                    <ul class="moretext4" style="display: none;">
                                        @endif
                                        <li>
                                            <input id="chk{{ $key }}" type="checkbox" @if(@$subject_slugs) @if(in_array($subject->slug,$subject_slugs)) checked="" @endif @endif value="{{ $subject->slug }}" name="subject_id[]" class=" checkbox_ck_u" >
                                            {{-- onchange="searchResults();" --}}
                                            {{-- click_apply --}}
                                            <label for="chk{{ $key }}">{{ @$subject->subject }}</label>
                                        </li>
                                        @endforeach
                                        @endif
                                    </ul>
                                    {{-- 
                                    <ul class="moretext4" style="display: none;">
                                        @if(@$othersubjects)
                                        @foreach(@$othersubjects as $key=>$subject)
                                        <li>
                                            <input id="chkO{{ $key }}" type="checkbox" @if(@$subject_slugs) @if(in_array($subject->slug,$subject_slugs)) checked="" @endif @endif value="{{ $subject->slug }}" name="subject_id[]">
                                            <label for="chkO{{ $key }}">{{ @$subject->subject }}</label>
                                        </li>
                                        @endforeach
                                        @endif
                                    </ul>
                                    --}}
                                    <a class="moreless-button4">More +</a>
                                </div>
                                <div class="search_le_check_bx">
                                    <h5>Years of experience </h5>
                                    @if(@$experience_arr)
                                    @foreach(@$experience_arr as $key=>$exp)
                                    @if($key == 0)
                                    <ul>
                                    @endif
                                    @if($key == 2) 
                                    <ul class="moretext5" style="display: none;">
                                        @endif
                                        @if(@$experience_arr[$key+1])
                                        <li>
                                            <input id="experience{{ $key }}" type="radio" @if(@$min_experience_value) @if(@$experience_arr[$key] == @$min_experience_value || @$experience_arr[$key+1] == @$max_experience_value) checked="" @endif @endif value="{{@$experience_arr[$key]}}@if(@$experience_arr[$key+1]) {{@$experience_arr[$key+1]}}@endif" name="experience" class="click_apply">
                                            <label for="experience{{ $key }}">{{@$experience_arr[$key]}}@if(@$experience_arr[$key+1])–{{@$experience_arr[$key+1]}} years @else years and above @endif </label>
                                        </li>
                                        @endif
                                        @endforeach
                                        @endif
                                        <li>
                                            <input id="experience{{ $maxTotalExp }}" type="radio" 
                                            @if(@$maxTotalExp == @$min_experience_value || @$maxTotalExp == @$max_experience_value) 
                                            checked=""
                                            @endif value="{{@$maxTotalExp}}" name="experience" class="click_apply">
                                            <label for="experience{{ $maxTotalExp }}">
                                            {{ @$maxTotalExp }} years and above  </label>
                                        </li>
                                    </ul> 
                                    <a class="moreless-button5">More+</a>
                                </div>
                                <div class=" search_le_check_bx search_le_selt">
                                    <h5>State</h5>
                                    <select id="state" name="state" class="change_apply" >
                                        <option value="">Select State</option>
                                        @if(@$states)
                                        @foreach(@$states as $key=>$s)
                                        <option value="{{ $s->slug }}" @if(@$state_slug == @$s->slug) selected="" @endif @if(@$state_value->slug == @$s->slug) selected="" @else class="not_matched" @endif>{{ @$s->state_name }}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                                <div class="search_le_check_bx search_le_redio_bx">
                                    <h5>Average Review</h5>
                                    <ul>
                                        <li>
                                            <input id="radios4" type="radio" value="4" name="review" @if(@$review_value == 4) checked="" @endif class="click_apply" onclick="searchResults();">
                                            <label for="radios4">
                                            <span>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            </span>
                                            <strong>(4 and Above)</strong>
                                            </label>
                                        </li>
                                        <li>
                                            <input id="radios5" type="radio" value="3" name="review" @if(@$review_value == 3) checked="" @endif class="click_apply">
                                            <label for="radios5">
                                            <span>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            </span>
                                            <strong>(3 and Above)</strong>
                                            </label>
                                        </li>
                                        <li>
                                            <input id="radios6" type="radio" value="2" name="review" @if(@$review_value == 2) checked="" @endif class="click_apply">
                                            <label for="radios6">
                                            <span>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            </span>
                                            <strong>(2 and Above)</strong>
                                            </label>
                                        </li>
                                        <li>
                                            <input id="radios7" type="radio" value="1" name="review" @if(@$review_value == 1) checked="" @endif class="click_apply">
                                            <label for="radios7">
                                            <span>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            </span>
                                            <strong>(1 and Above)</strong>
                                            </label>
                                        </li>
                                        <li>
                                            <input id="radios8" type="radio" value="0" name="review" @if(@$review_value == 0) checked="" @endif class="click_apply">
                                            <label for="radios8">
                                            <span>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            <i class="fa fa-star rre_star"></i>
                                            </span>
                                            <strong>(0 and Above){{ @$review_value }}</strong>
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                                {{-- @if(@Auth::check()) --}}
                                <div class="search_le_check_bx">
                                    <h5>Rate per session (30 mins)</h5>
                                    <div class="ratea_slid">
                                        <div class="slider_rnge">
                                            <div id="slider-range" class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
                                                <div class="ui-slider-range ui-widget-header ui-corner-all" style="left: 0%; width: 100%;"></div>
                                                <span tabindex="0" class="ui-slider-handle ui-state-default ui-corner-all" style="left: 0%;"></span> <span tabindex="0" class="ui-slider-handle ui-state-default ui-corner-all" style="left: 100%;"></span> 
                                            </div>
                                            <span class="range-text">
                                            <input type="text" class="price_numb hourly_rate" readonly id="amount" value="0">
                                            <input type="hidden" class="price_numb hourly_rate click_apply" readonly id="min_hourly_rate_value" name="min_hourly_rate" value="@if(@$request_min_hourly_rate) {{ @$request_min_hourly_rate }} @else 0 @endif">
                                            <input type="hidden" class="" readonly id="max_hourly_rate_value" name="max_hourly_rate" value="@if(@$request_max_hourly_rate) {{ @$request_max_hourly_rate }} @else {{ @$max_hourly_rate_fetch }} @endif">
                                            </span> 
                                        </div>
                                    </div>
                                </div>
                                {{-- @endif --}}
                                <div class="apply_fil_sec">
                                    <ul>
                                        <li>
                                            <input type="submit" class="pg_btn" value="Apply filter">
                                            {{-- <a href="#url" class="pg_btn">Apply filter</a> --}}
                                        </li>
                                        <li><a href="{{ route('search.result.j') }}" class="pg_btn re_adja"><img src="{{ asset('public/assets/images/filtar_icon.png') }}" alt="" /> Re-adjust</a></li>
                                    </ul>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="search_result_right">
                <div class="search_right_result_inr">
                    <div class="search_right_top">
                        @if(count(@$tutors) >= 0)
                        <h1>Displaying 
                            <span>
                            @if(@$tutors->currentPage())
                            ({{ (@$tutors->currentPage()-1)*@$tutors->perPage() }}-{{ @$tutors->perPage()*@$tutors->currentPage() }})
                            @else
                            @if(@$tutors->total() <=10)
                            (1-10)
                            @else
                            (0-0)
                            @endif
                            @endif
                            </span> of {{ @$tutors->total() }}  Tutors @if(@$grade_obj->grade_name) for @endif 
                            <span>{{ @$grade_obj->grade_name }}</span>
                            @if(@$state_value->state_name)in @endif <span> {{ @$state_value->state_name }}</span>
                        </h1>
                        @else
                        <h1>No results found</h1>
                        @endif
                        <div class="stor_by">
                            <strong>
                            Sort by : 
                            <select name="sort_type_value" id="sort_type_id">
                            <option value="R" @if(@$sort_type_value == 'R') selected="" @endif>Ratings</option>
                            <option value="H" @if(@$sort_type_value == 'H') selected="" @endif>$ high to low</option>
                            <option value="L" @if(@$sort_type_value == 'L') selected="" @endif>$ low to high</option>
                            <option value="D" @if(@$sort_type_value == 'D') selected="" @endif>Date</option>
                            <option value="E" @if(@$sort_type_value == 'E') selected="" @endif>Experience</option>
                            </select>
                            </strong>
                        </div>
                    </div>
                    @if(count(@$tutors) > 0)
                    <div class="search_right_body">
                        @if(@$tutors)
                        @foreach(@$tutors as $tutor)
                        <div class="search_lop">
                            <a @if(@Auth::check()) href="javascript:void(0)" @else href="{{ route('login') }}" @endif class=" heart_cc @if(@$tutor->getuserToFavourite) heart_cc_act @endif  saveUsertoFavourite" data-saveUsertoFavourite="{{ @$tutor->id }}">
                            <i class="fas fa-heart" ></i>
                            </a>
                            <div class="search_lop_left">
                                <em>
                                @if(@$tutor->profile_pic)
                                @php
                                $image_path = 'public/assets/images/all_avatars/'.@$tutor->profile_pic;
                                @endphp
                                @if(file_exists(@$image_path))
                                    <img src="{{url('/')}}/public/assets/images/all_avatars/{{@$tutor->profile_pic}}" alt="profile_img">
                                @else
                                    <img src="{{asset('storage/app/public/teacher_profile_pic/'.@$tutor->profile_pic)}}" alt="">
                                @endif
                                {{-- <img src="{{asset('storage/app/public/teacher_profile_pic/'.@$tutor->profile_pic)}}" alt=""> --}}
                                @else
                                @if(@$tutor->avatar)
                                <img src="{{@$tutor->avatar}}" alt="">
                                @else
                                <img src="{{ asset('public/assets/images/searchimg1.jpg') }}" alt="" />
                                @endif
                                @endif
                                </em>
                                @if(@Auth::check())
                                <h4>from ${{ @$tutor->min_hourly_rate }}</h4>
                                @else
                                <h4>from $$</h4>
                                @endif
                                <ul class="sh_lis_star">
                                    <li>
                                        <span>
                                            @if($tutor->avg_review>=0 && $tutor->avg_review<=0.24)
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=0.25 && $tutor->avg_review<=0.74)
                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=0.75 && $tutor->avg_review<=1.24)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=1.25 && $tutor->avg_review<=1.74)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=1.75 && $tutor->avg_review<=2.24)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=2.25 && $tutor->avg_review<=2.74)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=2.75 && $tutor->avg_review<=3.24)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=3.25 && $tutor->avg_review<=3.74)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=3.75 && $tutor->avg_review<=4.24)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star rre_star" style="color:#b6b6b6 !important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=4.25 && $tutor->avg_review<=4.74)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fas fa-star-half-alt" style="color:#ef9a0c!important;"></i></li>
                                    @endif
                                    @if($tutor->avg_review>=4.75 && $tutor->avg_review<=5)
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    <li><i class="fa fa-star" style="color:#ef9a0c!important;"></i></li>
                                    @endif
                                    </span>
                                    </li>
                                    <li>{{ @$tutor->avg_review }} <b>({{ @$tutor->total_no_of_reviews }})</b></li>
                                </ul>
                                <h5>{{ @$tutor->total_experience }} yrs. exp.  </h5>
                            </div>
                            <div class="search_lop_right">
                                <div class="lop_name_box">
                                    <div class="search_lop_name">
                                        {{-- data-toggle="modal" data-target="#log_modal" --}}
                                        <h4>
                                            <a @if(!@Auth::check())  class="save_input_data_on_click" data-type="PP" data-id="{{ @$tutor->id }}" data-toggle="modal" data-target="#log_modal{{ @$tutor->id }}"  href="javascript:void(0);" @else href="{{ url('tutor-public-profile') }}/{{ @$tutor->slug }}"  @endif>{{ @$tutor->f_name." ".@$tutor->l_name }}</a>
                                        </h4>
                                        <ul class="search_sibj">
                                            <li><img src="{{ asset('public/assets/images/edu1.png') }}" alt="">
                                                @php 
                                                $academics = @$tutor->getTutorAcademic[0];
                                                @endphp
                                                {{-- @foreach(@$tutor->getTutorAcademic as $academics) --}}
                                                @if(@$academics->qualification == 1)
                                                Doctoral Degree 
                                                @elseif(@$academics->qualification == 2)
                                                Postgraduate
                                                @elseif(@$academics->qualification == 3)
                                                Master's Degree (Research) 
                                                @elseif(@$academics->qualification == 4)
                                                Master's Degree
                                                @elseif(@$academics->qualification == 5)
                                                Bachelor Honours Degree
                                                @elseif(@$academics->qualification == 6)
                                                Bachelor’s Degree
                                                @elseif(@$academics->qualification == 7)
                                                Associate Degree
                                                @elseif(@$academics->qualification == 8)
                                                Advanced Diploma
                                                @elseif(@$academics->qualification == 9)
                                                Diploma
                                                @endif
                                                {{-- , --}}
                                                {{-- @endforeach --}}
                                            </li>
                                            {{-- a relationship is required for this that's why this point is pending --}}
                                            <li>
                                                <img src="{{ asset('public/assets/images/edu2.png') }}" alt="">Speaks :
                                                @foreach(@$tutor->languguageToTuor as $key=>$l)
                                                {{ @$l->languageName->language }} @if(@$tutor->languguageToTuor->count()-1 != $key) , @endif
                                                @endforeach
                                            </li>
                                        </ul>
                                        <ul class="sub_list">
                                            @php 
                                            $plans = @$tutor->getTutorShipPlan->unique('subject_id')->take(3);
                                            @endphp
                                            @if(@$plans)
                                            @foreach(@$plans as $tutorshipplan)
                                            <li>
                                                {{ @$tutorshipplan->getSubject->subject }}
                                            </li>
                                            @endforeach
                                            @endif
                                            @if(@$tutor->getTutorShipPlan->unique('subject_id')->count() > 3)
                                            <li>+{{ @$tutor->getTutorShipPlan->unique('subject_id')->count()-3 }}</li>
                                            @endif
                                        </ul>
                                        <ul class="sub_list">
                                            @if(@$tutor->getMyAvailability)
                                            @foreach(@$tutor->getMyAvailability->unique('day') as $av)
                                            <li>
                                                @if(@$av->day == 1)
                                                Monday
                                                @elseif(@$av->day == 2)
                                                Tuesday
                                                @elseif(@$av->day == 3)
                                                Wednesday
                                                @elseif(@$av->day == 4)
                                                Thursday
                                                @elseif(@$av->day == 5)
                                                Friday
                                                @elseif(@$av->day == 6)
                                                Saturday
                                                @elseif(@$av->day == 7)
                                                Sunday
                                                @endif
                                                {{-- {{ date("h:i a", strtotime(@$av->from_time)) }}-{{ date("h:i a", strtotime(@$av->to_time))}}, --}}
                                            </li>
                                            @endforeach
                                            @endif
                                            {{-- 
                                            <li>Physics</li>
                                            <li>Trigonometry</li>
                                            <li>+1</li>
                                            --}}
                                        </ul>
                                    </div>
                                    <div class="search_lop_name_list">
                                        <ul>
                                            {{-- student-bookclass.html --}}
                                            {{-- 
                                            <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a href="{{ url('studentbook-class?tutor=') }}{{ @$tutor->slug }}-{{ @$tutor->id }}">Book my class</a></li>
                                            --}}

                                            @if(@$admin_disable_bookings_values->disable_booking == 'Y')
                                                <li><a class="open_popup_g" data-toggle="modal" data-target="#admin_disabled_bookings_popup" href="javascript:void(0);">Book my class1</a></li>
                                            @elseif(in_array(date('Y-m-d'),$all_disabled_booking_dates))
                                                <li><a class="open_popup_g" data-toggle="modal" data-target="#admin_disabled_bookings_popup" href="javascript:void(0);">Book my class2</a></li>
                                            @else
                                                @if(@Auth::check())
                                                    @php
                                                    $getTutorGrades = @$tutor->getTutorShipPlan->pluck('grade_id')->toArray();
                                                    $mGrade = @Auth::user()->grade;

                                                    
                                                    @endphp
                                                    @if(@Auth::user()->timezone_id == @$tutor->timezone_id && @Auth::user()->state == @$tutor->state)
                                                        @if(in_array($mGrade,$getTutorGrades))
                                                            <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a  href="{{ url('studentbook-class?search_tutor_slug_studentclass='.@$tutor->slug.'&search_tutor_id_studentclass='.@$tutor->id) }}" >Book my class</a></li>
                                                        @else
                                                            @if(@Auth::user()->timezone_id != @$tutor->timezone_id)
                                                            <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a class="open_popup_g" data-toggle="modal" data-target="#not_b_popupTimeZone" href="javascript:void(0);">Book my class</a></li> 
                                                            @elseif(@Auth::user()->state != @$tutor->state)
                                                            <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a class="open_popup_g" data-toggle="modal" data-target="#not_b_popupState" href="javascript:void(0);">Book my class</a></li>
                                                            @else       
                                                            <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a class="open_popup_g" data-toggle="modal" data-target="#not_b_popup" href="javascript:void(0);">Book my class</a></li>
                                                            @endif
                                                        @endif
                                                    @else
                                                            @if(@Auth::user()->timezone_id != @$tutor->timezone_id)
                                                            <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a class="open_popup_g" data-toggle="modal" data-target="#not_b_popupTimeZone" href="javascript:void(0);">Book my class</a></li> 
                                                            @elseif(@Auth::user()->state != @$tutor->state)
                                                            <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a class="open_popup_g" data-toggle="modal" data-target="#not_b_popupState" href="javascript:void(0);">Book my class</a></li>
                                                            @else       
                                                            <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a class="open_popup_g" data-toggle="modal" data-target="#not_b_popup" href="javascript:void(0);">Book my class</a></li>
                                                            @endif
                                                    
                                                    @endif
                                                    
                                                    {{--  --}}
                                                    {{-- <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a class="open_popup_g" data-toggle="modal" data-target="#not_b_popup" href="javascript:void(0);">Book my class</a></li> --}}
                                                @else
                                                    <li><img src="{{ asset('public/assets/images/list_ico1.png') }}" alt=""><a @if(!@Auth::check()) href="javascript:void(0);" data-id="{{ @$tutor->id }}" data-toggle="modal" data-target="#log_modal{{ @$tutor->id }}" class="save_input_data_on_click" data-type="B"   @else href="{{ url('studentbook-class?search_tutor_slug_studentclass='.@$tutor->slug.'&search_tutor_id_studentclass='.@$tutor->id) }}" @endif>Book my class</a></li>
                                                @endif
                                            @endif
                                            
                                            
                                            
                                            @if(@$tutor->video_short_url)
                                            <li><img src="{{ asset('public/assets/images/list_ico2.png') }}" alt=""><a data-toggle="modal" data-target="#videoaModal">My V-profile</a></li>
                                            @endif
                                            <div class="modal fade" id="videoaModal">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <!-- Modal Header -->
                                                        <div class="modal-header">
                                                            <h2 class="videopmodal">My V-profile</h2>
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        </div>
                                                        <!-- Modal body -->
                                                        <div class="modal-body">
                                                            <div class="profile_body">
                                                                <iframe src="https://www.youtube.com/embed/{{@$tutor->video_short_url }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                                                            </div>
                                                            {{-- 
                                                            <video width="100%" controls>
                                                                --}}
                                                                {{-- 
                                                                <source src="{{ asset('public/assets/images/profile1.mp4') }}" type="video/mp4">
                                                                --}}
                                                                {{-- 
                                                                <source id="profile_video_link" src="{{ @$tutor->profile_video }}" type="video/mp4">
                                                                --}}
                                                                {{-- 
                                                            </video>
                                                            --}}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal log_modal_bx" id="log_modal{{ @$tutor->id }}">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <!-- Modal Header -->
                                                        <div class="modal-header">
                                                            <h4 class="modal-title"> Please signup or login to continue</h4>
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        </div>
                                                        <!-- Modal body -->
                                                        <div class="modal-body">
                                                            <div class="modal_button">
                                                                <ul>
                                                                    <li><a href="{{ route('login') }}" style="color: #fff !important;" class="pg_btn">Login</a></li>
                                                                    <li><a href="{{ route('register') }}" style="color: #fff !important;" class="pg_btn">Signup</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <li><img src="{{ asset('public/assets/images/list_ico3.png') }}" alt=""><a @if(!@Auth::check()) data-toggle="modal" data-target="#log_modal{{ @$tutor->id }}"  class="save_input_data_on_click" data-type="PP" data-id="{{ @$tutor->id }}"  href="javascript:void(0);" @else href="{{ url('tutor-public-profile') }}/{{ @$tutor->slug }}"  @endif>Visit my page</a></li>

                                            @php
                                            @$countRev=DB::table('reviews')->where('student_id',@Auth::user()->id)->where('tutor_id',@$tutor->id)->count();

                                            @endphp


                                            <li><img src="{{ asset('public/assets/images/list_ico4.png') }}" alt=""><a  @if(!@Auth::check()) data-toggle="modal" data-target="#log_modal{{ @$tutor->id }}" class="save_input_data_on_click" data-id="{{ @$tutor->id }}" data-type="PR"  href="javascript::void(0);" @else  @if(@$countRev>0) data-toggle="modal" data-target="#alreadyRev" class="save_input_data_on_click" href="javascript::void(0);"  @else href="{{route('student.my.review',@$tutor->slug)}}" @endif @endif>Post a review </a></li>


                            <div class="modal fade" id="alreadyRev" role="dialog">
                                <div class="modal-dialog">
                                    
                                    <!-- Modal content-->
                                   <div class="modal-content revmodal">
                                                        <!-- Modal Header -->
                                                       
                                                       
                                                        <!-- Modal body -->
                                                        <div class="modal-body">
                                                            <button type="button" class="close" data-dismiss="modal">×</button>
                                                            <div class="modal_button">
                                                                <img src="{{ asset('public/assets/images/review_given.png') }}" width="100px">
                                                                <center><h2>You have already reviewed this tutor.</h2></center>
                                                            </div>
                                                        </div>
                                                    </div>
                                    
                                </div>
                            </div>




                                        </ul>
                                    </div>
                                </div>
                                <div class="lop_name_para">
                                    <p>
                                        @if(strlen(@$tutor->about_me) > 120)
                                        @php
                                        $len=strpos(wordwrap(@$tutor->about_me, 120),"\n");
                                        @endphp
                                        {!! nl2br(substr(@$tutor->about_me, 0, $len))!!}
                                        {{-- <span class="textLimit"> --}}
                                        {{-- {!! strip_tags(@$tutor->about_me) !!} --}}
                                        {{-- </span> --}}
                                        <span class=" text_c_more_less text_c_more_less{{ @$tutor->id }}" style="display: none;">
                                        {!! strip_tags(@$tutor->about_me) !!}
                                        </span>
                                        <a class=" button_red_cc c_c_moreless c_c_moreless{{ @$tutor->id }}" data-id="{{ @$tutor->id }}">Read more</a>
                                        @else
                                        {!! strip_tags(@$tutor->about_me) !!}
                                        @endif
                                        {{-- <span class="moretext5" style="display: none;">
                                        I completed my Bachelor of Degree in Banking and Finance. I am currently a postgrad student, doing my Masters in Philosophy. I aspire to a professional academic.
                                        </span> 
                                        <a class="moreless-button5 button_red_cc">Read more</a> --}}
                                    </p>
                                </div>
                            </div>
                        </div>
                        @endforeach
                        @endif
                        <div class="pagi_cc">
                            <nav aria-label="...">
                                <ul class="pagination">
                                    {{ @$tutors->links() }}
                                </ul>
                            </nav>
                        </div>
                    </div>
                    @else
                    <div class="search_right_body">
                        <div class="empty_box search_emt_bx">
                            <img src="{{ asset('public/assets/images/empty_img.png') }}">
                            <h2>No V-Tutor is available matching your criteria</h2>
                            <p>Try changing filters to search again</p>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal log_modal_bx" id="log_modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"> Please signup or login to continue</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="modal_button">
                    <ul>
                        <li><a href="{{ route('login') }}" class=" pg_btn">Login</a></li>
                        <li><a href="{{ route('register') }}" class="pg_btn">Signup</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal " id="not_b_popup">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title ">Message</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="">
                    <div class=" ">
                        <div class="meass-popup">
                            <ul class="">
                                <li class="">
                                    You cannot book my class outside your grade
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal " id="not_b_popupState">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title ">Message</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="">
                    <div class=" ">
                        <div class="meass-popup">
                            <ul class="">
                                <li class="">
                                    You cannot book my class outside your state
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal " id="not_b_popupTimeZone">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title ">Message</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="">
                    <div class=" ">
                        <div class="meass-popup">
                            <ul class="">
                                <li class="">
                                    Sorry, this tutor appear to be outside your time zone. You cannot book a class outside your time zone!
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal " id="admin_disabled_bookings_popup">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title bb_disabled_booking_u">Message</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="">
                    <div class=" ">
                        <div class="meass-popup">
                            <ul class="">
                                <li class="">
                                    You cannot make bookings at this time. Please contact support
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
@section('footer')
@include('include.footer')
{{-- @include('include.common_modal') --}}
@endsection
@section('script')
@include('include.script')
<script src="{{ asset('public/assets/toastr/build/toastr.min.js') }}"></script>
<script src="https://kit.fontawesome.com/446e463225.js" crossorigin="anonymous"></script>
{{-- @include('include.book_popup_data') --}}
<script type="text/javascript">
    {{-- $(".search_result_sec").hide(); --}}
    
    // $( window ).load(function() {
    
    // Run code
    
    // alert("djsj");
    
    // $(".search_result_sec").show();
    
    // });
    
    $(document).ready(function(){
    
        
    
        $('.moreless-button5').click(function() {
    
    
    
            $('.moretext5').slideToggle();
    
    
    
            if($('.moreless-button5').text() == "More+") {
    
                $(this).text("Less-")
    
            } else {
    
                $(this).text("More+")
    
            }
    
        });
    
        $(".save_input_data_on_click").click(function(){
    
            //type for which page if b booking if pp public profile if pr post review page
    
            var save_on_click_value_type = $(this).data("type"),
    
            save_search_on_click_tutor_id = $(this).data("id");
    
            $.ajax({
    
                type:"GET",
    
                url:'{{ route('save.search.on.click.value') }}',
    
                data:{
    
                   save_on_click_value:save_on_click_value_type,
    
                   save_search_on_click_tutor_id:save_search_on_click_tutor_id
    
                },
    
                success:function(resp){
    
                  // $("#log_modal").modal("show");
    
                }
    
            });
    
        });
    
        $(document).on("change",".change_apply",function(e){
    
    
    
            $("#searchVtutorForm").submit();
    
    
    
        });    
    
    
    
        $(document).on("click",".click_apply",function(e){
    
    
    
            $("#searchVtutorForm").submit();
    
    
    
        });
    
        $('.checkbox_ck_u').on('click', function() {
    
          if($(this).is(":checked")) {
    
                $("#searchVtutorForm").submit();
    
          } else {
    
            $(this).val("");
    
            $("#searchVtutorForm").submit();
    
          }
    
        });
    
    
    
        $(document).on("click",".saveUsertoFavourite",function(e){
    
    
    
            // alert("sfjhahs");
    
    
    
            var favourite_user_id = $(this).attr("data-saveUsertoFavourite"),
    
    
    
            obj = $(this),
    
    
    
            reqData = {
    
    
    
                'jsonrpc' : '2.0',                
    
    
    
                '_token'  : '{{csrf_token()}}',
    
    
    
                'data'    : {
    
    
    
                    'favourite_user_id'    : favourite_user_id
    
    
    
                }
    
    
    
            };
    
    
    
            // alert(favourite_user_id);
    
    
    
    
    
    
    
            
    
    
    
                $.ajax({
    
    
    
                    url:"{{ route('save.user.to.favourite') }}",
    
    
    
                    dataType: 'json',
    
    
    
                    data: reqData,
    
    
    
                    type: 'post',
    
    
    
                    success:function(resp){
    
    
    
                        if(resp.result.status == 'Added'){
    
    
    
                            obj.addClass("heart_cc_act");
    
    
    
                        }else{
    
    
    
                            obj.removeClass("heart_cc_act");
    
    
    
                        }
    
    
    
                        toastr.success(resp.result.message);
    
    
    
                    },
    
    
    
                    error:function(){
    
    
    
                        toastr.error("Please refresh the page!");
    
    
    
                    }
    
    
    
                });
    
    
    
            
    
    
    
        });
    
    
    
    });
    
    
    
    
    
    
    
    $("#slider-range").slider({
    
    
    
    range: true,
    
    
    
    min: 0,
    
    
    
    max: {{ @$max_hourly_rate_fetch }},
    
    
    
    values: [{{ @$request_min_hourly_rate?@$request_min_hourly_rate:0 }},{{ @$request_max_hourly_rate?@$request_max_hourly_rate:@$max_hourly_rate_fetch }}],
    
    
    
    slide: function(event, ui) {
    
    
    
    
    
    
    
     $("#amount").val("$ " + ui.values[0] + " - $ " + ui.values[1]);
    
    
    
     $("#min_hourly_rate_value").val(ui.values[0]);
    
    
    
     $("#max_hourly_rate_value").val(ui.values[1]);
    
    
    
        $("#searchVtutorForm").submit();
    
    
    
    
    
    
    
    },
    
    
    
    });
    
    
    
    @if(@$request_max_hourly_rate || @$request_min_hourly_rate)
    
    
    
    $("#amount").val("$ " + {{ @$request_min_hourly_rate }} + " - $ " + {{ @$request_max_hourly_rate }});
    
    
    
    $("#min_hourly_rate_value").val({{ @$request_min_hourly_rate  }});
    
    
    
    $("#max_hourly_rate_value").val({{ @$request_max_hourly_rate }});
    
    
    
    @else
    
    
    
    $("#amount").val("$ " + $("#slider-range").slider("values", 0) + " - $ " + $("#slider-range").slider("values", 1));
    
    
    
    $("#min_hourly_rate_value").val($("#slider-range").slider("values", 0));
    
    
    
    $("#max_hourly_rate_value").val($("#slider-range").slider("values", 1));
    
    
    
    @endif
    
    
    
    $(document).ready(function(){       
    
    
    
        $(document).on("change","#sort_type_id",function(){
    
    
    
            $("#sort_type").val($.trim($("#sort_type_id").val()));
    
    
    
            $("#searchVtutorForm").submit();
    
    
    
        });
    
    
    
    });
    
    
    
</script>
<script>
    $(document).on("click",".c_c_moreless",function(){
    
    
    
        var id = $(this).data("id");
    
    
    
        // text_c_more_less
    
    
    
        $('.text_c_more_less'+id).slideToggle();
    
    
    
          if($(this).text() == "Read more") {
    
    
    
            $(this).text("Read Less")
    
    
    
          }else{
    
    
    
            $(this).text("Read more")
    
    
    
          }
    
    
    
    });
    
    
    
    // $('.moreless-button6').click(function() {
    
    
    
    //   $('.moretext6').slideToggle();
    
    
    
    //   if ($('.moreless-button6').text() == "Read more") {
    
    
    
    //     $(this).text("Read Less")
    
    
    
    //   } else {
    
    
    
    //     $(this).text("Read more")
    
    
    
    //   }
    
    
    
    // });
    
    
    
</script>
<script>
    /* Menu Start */
    
    
    
    // $('#sm').mouseover(function() {
    
    
    
    // $(this).show();
    
    
    
    // });
    
    
    
    // $('#sm').mouseout(function() {
    
    
    
    // $(this).hide();
    
    
    
    // });
    
    
    
    // $('#m1').mouseover(function() {
    
    
    
    // $('.all_menu').show();
    
    
    
    // $('#sm').show();
    
    
    
    // });
    
    
    
    // var column = 4
    
    
    
    // var wWidth = $(window).width()
    
    
    
    // if(wWidth >= 767 && wWidth <= 991) {
    
    
    
    // column = 3
    
    
    
    // } else if(wWidth >= 575 && wWidth < 767) {
    
    
    
    // column = 2
    
    
    
    // }
    
    
    
    // $('#blog-landing').pinterest_grid({
    
    
    
    // no_columns: column,
    
    
    
    // padding_x: 0,
    
    
    
    // padding_y: 0,
    
    
    
    // margin_bottom: 0,
    
    
    
    // single_column_breakpoint: 700
    
    
    
    // });
    
    
    
    // $('#m1, #m2 ').mouseleave(function() {
    
    
    
    // $('#sm').hide();
    
    
    
    // $('#sm1, #sm2').hide();
    
    
    
    // });
    
    
    
    // /* Menu Start */
    
    
    
    // $('#paste-lan').click(function() {
    
    
    
    // $('.open-lan').toggle();
    
    
    
    // });
    
    
    
    // $('.open-lan').find('a').click(function() {
    
    
    
    // var lang = $(this).data("id");
    
    
    
    // if(lang == 'english') {
    
    
    
    //  $('#paste-lan').html('<img src="{{ asset('public/assets/images/english-flag1.png') }}" alt="">');
    
    
    
    // } else {
    
    
    
    //  $('#paste-lan').html('<img src="{{ asset('public/assets/images/arabic-flag1.png') }}" alt="">');
    
    
    
    // }
    
    
    
    // $('.open-lan').hide();
    
    
    
    // });
    
    
    
</script>
<script>
    $(".mobile_filter_as").click(function () {
    
    
    
        $(".search_left_inr").slideToggle();
    
    
    
    });
    
    
    
</script>
@endsection