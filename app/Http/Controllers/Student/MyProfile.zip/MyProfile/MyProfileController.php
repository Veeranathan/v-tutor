<?php

namespace App\Http\Controllers\Student\MyProfile;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Models\State;
use App\Models\School;
use App\Models\Suburb;
use App\Models\TimezoneLists;
use Auth;

class MyProfileController extends Controller
{
    public function my_profile_show(){
    	$data['user']=User::with('getSchool.getState','getSchool.getSuburb')->where('id',Auth()->user()->id)->first();
    	$data['state']=State::orderBy('state_name','desc')->get();
    	$data['subrubs']=Suburb::orderBy('id','desc')->get();
    	$data['schools']=School::with(['getState','getSuburb'])->get();
    	$data['timezonesLists']=TimezoneLists::get();
    	if(@Auth::user()->is_login == 1){
            session(['is_first' => 1]);
        }
    	if(@Auth()->user()->is_login=="0"){
    		session(['is_first' => 0]);
      		User::where('id',@Auth()->user()->id)->update(['is_login'=>"1"]);
       	}
    	if(!@$data['user']->grade){
    		session()->flash("success","Congrats on your login. Now fill in your profile details to access other sections. Thank you");	
    	}
    	
    	return view('student.modules.my_profile.edit_profile')->with($data);
    }



    public function update_profile(Request $request){
      //dd($request->all());
	    $request->validate([
	      'f_name' => 'required|min:3',
	      //'email' => 'required|min:3|email',
	      // 'ph' => 'required|min:10',
	      'l_name' => 'required|min:3', 
	      'dob' => 'required',
	      'gender' => 'required',
	      'full_time_student' => 'required',
	      'timezone_id' => 'required',
	      'income' => 'required',  
	      // 'suburb' => 'required',  
	      'state' => 'required',  
	      'city' => 'required',  
	      'address' => 'required',  
	     // 'about_me' => 'required|min:10',                                 
	    ]);

	    $upd=array(
          "f_name" => $request->f_name,
		  "l_name" => $request->l_name,
		  "salutation" => $request->salutation,
		  "qualification" => $request->qualification,
		  "slug" => str_slug($request->f_name." ".$request->l_name." ".Auth()->user()->id),
		  "grade" => $request->grade,
		  "timezone_id" => $request->timezone_id,
		  "is_login" => '1',
		  // "phone" => $request->ph,
		  // "school" => $request->school,
		  // "suburb" => $request->suburb,
		  "city" => $request->city,
		  "address" => $request->address,
		  "zip" => $request->zip,
		  "state" => $request->state,
		  "dob" => $request->dob,
		  "gender" => $request->gender,
		  "is_full_time" => $request->full_time_student,
		  "private_or_home" => $request->private_or_home,
		  "parent_f_name" => $request->parent_f_name,
		  "parent_l_name" => $request->parent_l_name,
		  "annual_income" => $request->income,
		  "about_me" => $request->about_me,

	    );
	    if(@$request->school_id != 0){
	    	$upd['school'] = $request->school_id;
	    }else{
	    	
	    	$crsuburb['name'] = @$request->show_school_suburb;
	    	$crsuburb = Suburb::create($crsuburb);
	    	$crs['school_name'] = @$request->other_school_name;
	    	if(@$crsuburb){
	    		$crs['suburb_id'] = $crsuburb->id;
	    	}else{
	    		$crs['suburb_id'] = 0;
	    	}
	    	
	    	$crs['state_id'] = @$request->show_school_state;
	    	$crs['postcode'] = @$request->show_school_postcode;
	    	$crs['acara_id'] = 0;
	    	$schlCr = School::create($crs);
	    	if(@$schlCr){
	    		$upd['school'] = $schlCr->id;	
	    	}else{
	    		$upd['school'] = 0;
	    	}
	    	
	    }
	    $user_update=User::where('id',Auth()->user()->id)->update($upd);

	    // $updateSchool['']
	    // if($request->img){
     //         $unlnk=User::where('id',auth()->user()->id)->first();
     //        @$prev_img = $unlnk->profile_pic;
           
     //        if(@$prev_img){               
     //            @unlink('storage/app/public/student_profile_pic/'.$prev_img);
     //        }
     //        //this is for upload image
     //        $image = $request->img;
     //        $profile = time() . '-' . rand(1000, 9999) . '.' . $image->getClientOriginalExtension();
     //        $image->move("storage/app/public/student_profile_pic",$profile);
     //        $user_pic_update=User::where('id',Auth()->user()->id)->update(['profile_pic'=>$profile]);
     //    }
        if(@$request->imgSelect){
            
            User::where('id',Auth()->user()->id)->update(['profile_pic'=>$request->imgSelect]);
        }
        
	    return back()->with('success','Congrats! Now that you have filled your profile, go ahead and explore other sections');

    }





    public function reset_password_view(){
    	return view('student.modules.my_profile.reset_password');
    }



    public function update_password(Request $request){
    		//dd($request->all());
        $request->validate([
           'old_password'        => 'required|string|min:6',
           'newPassword'=> 'required|min:6|required_with:confirm|same:confirm',
           'confirm'=>'required|min:6', 
         ]);
    	//dd(Auth::guard('admin')->id());
		$oldpassword = $request->input('old_password');
		if (!\Hash::check($oldpassword,Auth()->user()->password)) {
			return redirect()->back()->with('error','You have entered wrong old password!');
		}else{
			$updatepassword = User::where('id',Auth()->user()->id)->update([
				'password'=>\Hash::make($request->input('newPassword'))
			]);
			return redirect()->back()->with('success','Password updated successfully!');
		}
    }
}
