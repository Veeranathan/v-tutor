@extends('layouts.app')



@section('title')



<title>V-tutor | Student | View Class Details | {{ @$bookingDataInformation->booking_no }}</title>



@endsection



@section('left_part')



@include('include.student_top_common')

<style type="text/css">
    .overflowtext{
        overflow-wrap: break-word;
    }
    .breaktext{
        word-break: break-all;
    }
</style>

@endsection



@section('content')



<!-- bannersec -->



<!-- bannersec -->



   <div class="top_mar"></div>



    <!--- profile --->



    <section class="user-account">



        <div class="container">



            <div class="row">



                <div class="zin">



                    @include('include.student_left_common')



                    <div class="user-right-panel">



                        <div class="user-right-top-new ">

                            @include('include.errors')

                            <h2 class="profile-heading">Class Details</h2>



                            <p> Here have your class details</p>



                        </div>



                        <div class="class-feild mt-4">



                            <div class="row">



                                <div class="col-12">



                                    <div class="tuto-rating">



                                        <em>



                                            @if(@$bookingDataInformation->getTutor->profile_pic)


                                                @php
                                                $image_path = 'public/assets/images/all_avatars/'.@$bookingDataInformation->getTutor->profile_pic;
                                                @endphp
                                                @if(file_exists(@$image_path))
                                                    <img src="{{url('/')}}/public/assets/images/all_avatars/{{@$bookingDataInformation->getTutor->profile_pic}}" alt="profile_img">
                                                @else
                                                    <img src="{{asset('storage/app/public/teacher_profile_pic/'.@$bookingDataInformation->getTutor->profile_pic)}}" alt="">
                                                @endif
                                                {{-- <img src="{{asset('storage/app/public/teacher_profile_pic/'.@$bookingDataInformation->getTutor->profile_pic)}}" alt="" id="img2"> --}}



                                            @else



                                                @if(@$bookingDataInformation->getTutor->avatar)



                                                    <img src="{{@$bookingDataInformation->getTutor->avatar}}" alt="" id="img2">



                                                @else



                                                    <img src="{{ asset('public/assets/images/user-pro.png') }}" alt="" id="img2">



                                                @endif



                                            @endif



                                        </em>



                                        <div class="tu-info">



                                            <h2>{{ @$bookingDataInformation->getTutor->f_name }} {{ @$bookingDataInformation->getTutor->l_name }}</h2>



                                            <div class="sed">



                                                 {{-- <span><img src="{{ asset('public/assets/images/map.png') }}">  {{ @$bookingDataInformation->getTutor->getState->state_name }}</span> --}}
                                                 <span><img src="{{ asset('public/assets/images/map.png') }}">Australia,{{@$bookingDataInformation->getTutor->getState->state_name}},{{@$bookingDataInformation->getTutor->city}} </span>


                                                 <ul class="profile-rating m-0">



                                                    @if(@$bookingDataInformation->getTutor->avg_review>=0 && @$bookingDataInformation->getTutor->avg_review<=0.24)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif

                                                @if(@$bookingDataInformation->getTutor->avg_review>=0.25 && @$bookingDataInformation->getTutor->avg_review<=0.74)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/halfstar.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif


                                                @if(@$bookingDataInformation->getTutor->avg_review>=0.75 && @$bookingDataInformation->getTutor->avg_review<=1.24)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif



                                                @if(@$bookingDataInformation->getTutor->avg_review>=1.25 && @$bookingDataInformation->getTutor->avg_review<=1.74)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/halfstar.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif



                                                 @if(@$bookingDataInformation->getTutor->avg_review>=1.75 && @$bookingDataInformation->getTutor->avg_review<=2.24)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif




                                                 @if(@$bookingDataInformation->getTutor->avg_review>=2.25 && @$bookingDataInformation->getTutor->avg_review<=2.74)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/halfstar.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif




                                                @if(@$bookingDataInformation->getTutor->avg_review>=2.75 && @$bookingDataInformation->getTutor->avg_review<=3.24)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif




                                                @if(@$bookingDataInformation->getTutor->avg_review>=3.25 && @$bookingDataInformation->getTutor->avg_review<=3.74)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/halfstar.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif




                                                @if(@$bookingDataInformation->getTutor->avg_review>=3.75 && @$bookingDataInformation->getTutor->avg_review<=4.24)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star1.png" alt=""></a></li>
                                                @endif
                                                




                                                  @if(@$bookingDataInformation->getTutor->avg_review>=4.25 && @$bookingDataInformation->getTutor->avg_review<=4.74)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/halfstar.png" alt=""></a></li>
                                                @endif



                                                  @if(@$bookingDataInformation->getTutor->avg_review>=4.75 && @$bookingDataInformation->getTutor->avg_review<=5)
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                <li><a href="#"><img src="{{url('/')}}/public/assets/images/star.png" alt=""></a></li>
                                                @endif



                                                    



                                                    <li><p>{{ @$bookingDataInformation->getTutor->avg_review }} ({{ @$bookingDataInformation->getTutor->total_no_of_reviews }})</p></li>



                                                </ul> 



                                            </div>



                                            <div class="sed ">



                                                



                                            </div>



                                            <div class="sed grade_sed">



                                                <span><img src="{{ asset('public/assets/images/gra.png') }}"> {{ @$bookingDataInformation->getStudentGrade->grade_name }}</span>



                                                <span>



                                                        <img src="{{ asset('public/assets/images/world.png') }}"> 



                                                        



                                                        @if(@$t_my_av_show)



                                                            @foreach(@$t_my_av_show as $t)



                                                                @if(@$t->day == 1)



                                                                Monday



                                                                @elseif(@$t->day == 2)



                                                                Tuesday



                                                                @elseif(@$t->day == 3)



                                                                Wednesday



                                                                @elseif(@$t->day == 4)



                                                                Thursday



                                                                @elseif(@$t->day == 5)



                                                                Friday



                                                                @elseif(@$t->day == 6)



                                                                Saturday



                                                                @elseif(@$t->day == 7)



                                                                Sunday



                                                                @endif


                                                                {{ date("h:i a", strtotime(@$t->from_time)) }}-{{ date("h:i a", strtotime(@$t->to_time)) }},


                                                            @endforeach



                                                        @endif



                                                    </span>



                                            </div>







                                        </div>



                                    </div>



                                </div>



                            </div>



                        </div>







                        <div class="user-right-top-new marb90 text-center">



                            <img src="{{ asset('public/assets/images/confr.png') }}">



                            <h2 class="profile-headingnew">Class Details </h2>



                            <p>Here have your class details</p>



                            



                            <!-- <div class="booking-stat">



                                <span>Booking Number: <p> {{ @$bookingDataInformation->booking_no }} </p></span>



                                <span>Subject: <p> {{ @$bookingDataInformation->getSubject->subject }} </p></span>



                                <span>Date: <p> {{ @$bookingDataInformation->booking_date }} </p></span>



                                <span>Time: <p> {{ date("h:i a", strtotime(@$bookingDataInformation->from_time)) }} to {{ date("h:i a", strtotime(@$bookingDataInformation->to_time)) }} </p></span>



                            </div> -->  

                            <div class="booking-stat table_book">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Booking Number </th>
                                                <th>Subject</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                                {{-- <th>Transaction Id</th> --}}
                                                @if(@$bookingDataInformation->status != 'C')
                                                {{-- <th>Join Url</th> --}}
                                                @endif
                                            </tr>
                                          </thead>
                                            <tr>
                                                <td>{{ @$bookingDataInformation->booking_no }}</td>
                                                <td>{{ @$bookingDataInformation->getSubject->subject }} </td>
                                                <td>{{ @$bookingDataInformation->booking_date }}</td>
                                                <td>{{ date("h:i a", strtotime(@$bookingDataInformation->from_time)) }} to {{ date("h:i a", strtotime(@$bookingDataInformation->to_time)) }}</td>
                                                <td>${{ @$bookingDataInformation->booking_amount }}</td>
                                                <td>
                                                    @if(@$bookingDataInformation->booking_status == 'IC')
                                                    Incomplete
                                                    @elseif(@$bookingDataInformation->booking_status == 'B')
                                                    Booked
                                                    @elseif(@$bookingDataInformation->booking_status == 'CM')
                                                    Completed
                                                    @elseif(@$bookingDataInformation->booking_status == 'C')
                                                    Cancelled
                                                    @elseif(@$bookingDataInformation->booking_status == 'F')
                                                    Failed
                                                    @endif
                                                </td>
                                                {{-- <td class="overflowtext breaktext">{{ @$bookingDataInformation->getPaymentsInfo->txn_id }}</td> --}}
                                                @if(@$bookingDataInformation->status != 'C')
                                                {{-- <td class="overflowtext breaktext">{{ @$bookingDataInformation->start_url }}</td> --}}
                                                @endif
                                            </tr>
                                    </table>
                                </div>
                                <div class="btn_3_cc">
                                        @php
                                        $getTutorGrades = @$bookingDataInformation->getTutor->getTutorShipPlan->pluck('grade_id')->toArray();
                                        $mGrade = @Auth::user()->grade;

                                        
                                        @endphp
                                            {{-- <a class="open_popup_g" data-toggle="modal" data-target="#admin_disabled_bookings_popup" href="javascript:void(0);">Book my class</a> --}}
                                        @if(@$admin_disable_bookings_values->disable_booking == 'Y')
                                        <li><a class="open_popup_g sub_btn new-subbtn" data-toggle="modal" data-target="#admin_disabled_bookings_popup" href="javascript:void(0);">Book again</a></li>
                                        @elseif(in_array(date('Y-m-d'),$all_disabled_booking_dates))
                                        <li><a class="open_popup_g sub_btn new-subbtn" data-toggle="modal" data-target="#admin_disabled_bookings_popup" href="javascript:void(0);">Book again</a></li>
                                        @elseif(@Auth::user()->timezone_id != @$bookingDataInformation->getTutor->timezone_id)
                                        <li><a class="open_popup_g sub_btn new-subbtn" data-toggle="modal" data-target="#not_b_popupTimeZone" href="javascript:void(0);">Book Again </a></li> 
                                        @elseif(@Auth::user()->state != @$bookingDataInformation->getTutor->state)
                                        <li><a class="open_popup_g sub_btn new-subbtn" data-toggle="modal" data-target="#not_b_popupState" href="javascript:void(0);">Book Again </a></li>
                                        @elseif(!in_array($mGrade,$getTutorGrades))       
                                        <li><a class="open_popup_g sub_btn new-subbtn" data-toggle="modal" data-target="#not_b_popup" href="javascript:void(0);">Book Again </a></li>
                                        @elseif(@Auth::user()->timezone_id == @$bookingDataInformation->getTutor->timezone_id && @Auth::user()->state == @$bookingDataInformation->getTutor->state && in_array($mGrade,$getTutorGrades))
                                        <a href="{{ url('studentbook-class?search_tutor_nm_studentclass='.$bookingDataInformation->getTutor->f_name." ".$bookingDataInformation->getTutor->l_name.'&search_tutor_id_studentclass='.$bookingDataInformation->getTutor->id.'&search_tutor_selected_name_studentclass='.$bookingDataInformation->getTutor->f_name." ".$bookingDataInformation->getTutor->l_name.'&search_tutor_slug_studentclass='.$bookingDataInformation->getTutor->slug.'&book_subject='.$bookingDataInformation->getSubject->slug) }}" class="sub_btn new-subbtn">Book Again </a>
                                        {{-- @else
                                        <a class="open_popup_g sub_btn new-subbtn" data-toggle="modal" data-target="#not_b_popupState" href="javascript:void(0);">Book my class</a> --}}
                                        @endif
                                        

                                        @if($bookingDataInformation->booking_status == 'B')
                                        <a onclick="return confirm('Are you sure want to cancel ?')" href="{{ route('student.cancel.class.booking',@$bookingDataInformation->booking_no) }}" class="sub_btn new-subbtn">Cancel Booking</a>
                                        @endif
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection



@section('footer')



@include('include.footer')
    <div class="modal " id="not_b_popup">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title ">Message</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="">
                        <div class=" ">
                            <div class="meass-popup">
                                <ul class="">
                                    <li class="">
                                        You cannot book my class outside your grade
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal " id="not_b_popupState">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title ">Message</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="">
                        <div class=" ">
                            <div class="meass-popup">
                                <ul class="">
                                    <li class="">
                                        You cannot book my class outside your state
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal " id="not_b_popupTimeZone">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title ">Message</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="">
                        <div class=" ">
                            <div class="meass-popup">
                                <ul class="">
                                    <li class="">
                                        Please choose carefully as this would impact booking of classes!You cannot book my class outside your timezone!
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal " id="admin_disabled_bookings_popup">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title bb_disabled_booking_u">Message</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="">
                        <div class=" ">
                            <div class="meass-popup">
                                <ul class="">
                                    <li class="">
                                        You cannot make bookings at this time. Please contact support
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


@endsection



@section('script')



@include('include.script')







@endsection