@extends('layouts.app')



@section('title')
<title>V-tutor | Contact Us</title>
@endsection

@section('left_part')
@include('include.left_part')
@endsection

@section('content')
<!-- bannersec -->
<!-- bannersec -->
	<div class="top_mar"></div>
<section class="terms-sec">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="page_hed">
					<h3>Privacy Policy</h3>
				</div>

				<div class="privacy-content mb-60">
		            <h3><span> 1. </span> Welcome to company Privacy Policy</h3>
		            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
		            <h3><span> 2.</span>Information You Provide</h3>
		            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ipsum.</p>
		            <h3><span> 3.</span> Information We Receive from Other Sources</h3>
		            <p> It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem </p>
		            <h3><span> 4.</span> Use of Your Information</h3>
		            <ol>
		              <li>Responding to your questions and concerns;</li>
		              <li>Sending you administrative messages and information, including messages from instructors and teaching assistants, notifications about changes to our Service, and updates to our agreements;</li>
		              <li>Sending push notifications to your wireless device to provide updates and other relevant messages (which you can manage from the “options” or “settings” page of the mobile app);</li>
		            </ol>
		            <h3><span> 5.</span> Disclosure and Sharing of Your Information</h3>
		            <p> It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
		            <ul>
		              <li> It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem </li>
		              <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ipsum.</li>
		              <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ipsum.</li>
		              <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ipsum.</li>
		            </ul>
		            <h3><span> 6. </span>Security</h3>
		            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Ipsum.</p>
		          </div>



			</div>
		</div> 
	</div>
</section>
@endsection

@section('footer')
    @include('include.footer')
@endsection

@section('script')
    @include('include.script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js" integrity="sha512-UdIMMlVx0HEynClOIFSyOrPggomfhBKJE28LKl8yR3ghkgugPnG6iLfRfHwushZl1MOPSY6TsuBDGPK2X4zYKg==" crossorigin="anonymous"></script> 
   <script type="text/javascript">
   	$("#contactForm").validate();
   </script>
@endsection

