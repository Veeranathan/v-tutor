<div class="user-left sticky_left">
    <div class="dasbordLeftsec"> <a href="#" class="showmeu"><i class="fa fa-bars"></i>Show Menus</a>
    <div class="dasbordLeft">
        <div class="user-left-info">
            <div class="user-left-top"><em>
                @if(Auth::user()->profile_pic)
                <img src="{{url('/')}}/storage/app/public/teacher_profile_pic/{{@Auth::user()->profile_pic}}" alt="profile_img" style="width: 100%;height: 100%">
                @elseif(!@Auth::user()->profile_pic && @Auth::user()->avatar)
                 <img src="{{@Auth::user()->avatar}}" alt="profile_img" style="width: 100%">
                @else
                <img src="{{url('/')}}/public/assets/images/user-pro.png" alt="profile_img" style="width: 100%">
                @endif
                </em>
                <h2>{{@Auth::user()->f_name." ".@Auth::user()->l_name}}</h2> <p>40 classes</p> </div>
                <div class="new-lft-bottom">

                    @if(@Auth::user()->status=="A")
                    <div class="user-left-menu">
                        <ul>
                            <li class="{{request()->segment(2)=='home'?'active':''}}"><a href="{{route('teacher.home')}}"><span><img src="{{url('/')}}/public/assets/images/ac1.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac1-h.png" class="hovera"></span> Dashboard</a></li>
                            <li class="{{request()->segment(2)=='my-profile'?'active':''}}">
                                <a href="{{route('teacher.profile')}}"> <span><img src="{{url('/')}}/public/assets/images/ac2.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac2-h.png" class="hovera"></span> My Profile</a>
                            </li>
                            <li class="{{request()->segment(2)=='my-availablity'?'active':''}}">
                                <a href="{{route('tutor.availability')}}"> <span><img src="{{url('/')}}/public/assets/images/man1.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/man1-h.png" class="hovera"></span> My Availability </a>
                            </li>
                            <li class="{{request()->segment(2)=='my-class'?'active':''}}">
                                <a href="{{route('tutor.myclass')}}"> <span><img src="{{url('/')}}/public/assets/images/ac4.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac4-h.png" class="hovera"></span> My Classes </a>
                            </li>
                            <li class="{{request()->segment(2)=='payment-history'?'active':''}}">
                                <a href="{{route('tutor.payment')}}"> <span><img src="{{url('/')}}/public/assets/images/ac5.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac5-h.png" class="hovera"></span> Payment History </a>
                            </li>
                            <li><a href="tutor-rating&review.html"><span><img src="{{url('/')}}/public/assets/images/rat1.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/rat1-h.png" class="hovera"></span> Rating & Review </a></li>
                        </ul>
                    </div>
                    @else
                      <div class="user-left-menu">
                        <ul>
                            <li class="disable-left"><a href="javascript:void(0);"><span><img src="{{url('/')}}/public/assets/images/ac1.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac1-h.png" class="hovera"></span> Dashboard</a></li>
                          <li class="{{request()->segment(2)=='my-profile'?'active':''}}">
                                <a href="{{route('teacher.profile')}}"> <span><img src="{{url('/')}}/public/assets/images/ac2.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac2-h.png" class="hovera"></span> My Profile</a>
                            </li>
                            <li class="disable-left">
                                <a href="javascript:void(0);"> <span><img src="{{url('/')}}/public/assets/images/man1.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/man1-h.png" class="hovera"></span> My Availability </a>
                            </li>
                            <li class="disable-left">
                                <a href="javascript:void(0);"> <span><img src="{{url('/')}}/public/assets/images/ac4.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac4-h.png" class="hovera"></span> My Classes </a>
                            </li>
                            <li class="disable-left">
                                <a href="javascript:void(0);"> <span><img src="{{url('/')}}/public/assets/images/ac5.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac5-h.png" class="hovera"></span> Payment History </a>
                            </li>
                            <li class="disable-left">
                                <a href="javascript:void(0);"><span><img src="{{url('/')}}/public/assets/images/rat1.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/rat1-h.png" class="hovera"></span> Rating & Review </a>
                            </li>
                        </ul>
                    </div>

                    @endif
                    <div class="log-menu">
                        <ul>
                              <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();"> <span><img src="{{url('/')}}/public/assets/images/ac-7.png" class="hovern"> <img src="{{url('/')}}/public/assets/images/ac7-h.png" class="hovera"></span> Logout</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                        
                                    </form>
                                </li>
                        </ul>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>